# Round32 isolated normal-tail experiment

Candidate outcome: **NO-GO**.
Scientific status: **NO-GO unchanged**. Production remains unchanged; this experiment cannot activate B.

## Fixed evidence

- Scalar inputs: 3173; domain specials: 8; actual native rank cases: 165.
- Candidate scalar failures: 170; rank failures: 0.
- Threshold B/reference-policy mismatches: 5 of 365.
- A/B changed decisions: 174; every change is retained in changed-decisions.json.
- Policy/mathematical rounding discrepancies: 1.
- Premature zeros: A=2108, B=0.
- Candidate monotonicity violations: 0.

## Candidate criteria

- FAIL: all_candidate_numeric_gates
- PASS: candidate_monotone_nonincreasing
- PASS: special_domain_and_underflow
- PASS: max_absolute_error_improved_at_least_10x
- PASS: all_A_premature_zeros_eliminated
- FAIL: all_threshold_B_decisions_match_policy
- PASS: native rank regression, strict end-to-end accuracy, declared policies, KW bitwise control and deterministic transformations.

## Central absolute error

- Maximum A error: 0.000000146296271663472992284573108908129162791222879855072589315781087201352448299060563484957652
- Maximum B error: 0.000000000000000102340420418716282624936025314113401127264455197646722542847103020336974966574240154900035
- Improvement factor: 1429506260.23339991188788833533613963752453285947726604205232079267142433179055111321000682

## Cost

Status: FAIL.
- PASS: publish_increment_lte_10MiB
- PASS: startup_median_budget
- PASS: startup_p95_budget
- FAIL: throughput_median_ratio_lte_1_25
- Publish increment: 1601241 bytes.
- Startup median A/B: 94.010421/98.078239 ms.
- Startup nearest-rank p95 A/B: 109.925479/108.619653 ms.
- Throughput median B / median A: 4.454184951.

Startup uses 30 fresh paired launches in alternating AB/BA order; first pair retained and excluded from n=29 summaries. Each of the separate 30 throughput pairs uses fresh processes, 100,000 warmup and 100,000 measured total calls. p95 uses nearest rank. These are warm-file-cache repeated launches, not a cold-start claim.

## Interpretation and retained failures

A invokes the actual private NormalCdf; native MW is called in both variants. B changes one final return expression in an external source copy. Native internal z is not observed. Exact-rank mathematical z and rounded independent z are distinct reference diagnostics; discrepancies never justify wider tolerances.

SciPy ordinary p and separate logsf diagnostics are retained independently. Direct logsf is not substituted for the strict log of returned p gate. High precision is independently saved at 100 and 200 decimal digits, with explicit nearest-even binary64 conversion. Maximum finite and +infinity are separate domain/underflow checks.

Signed zeros remain separate. Actual A zero values are preserved; exact-at-zero is a B acceptance criterion. Every threshold-neighborhood candidate decision is checked against the actual unchanged DecisionPolicy fed rounded H, including unchanged but incorrect A/B decisions.

Windows compatibility is UNVERIFIED. Publication measurements are for the isolated framework-dependent Release linux-x64 harness, not the Windows application. Numerical failure is an informative terminal outcome; no tuning, threshold changes or selective retries are authorized.

## Artifacts

- scalar-results.json and scalar-results.csv: every point, bits, H/S/native errors and failures.
- rank-results.json: every native MW/KW case, frozen regression and transformations.
- decisions.json and changed-decisions.json: raw/adjusted values, actual policies, mathematical decisions and classifications.
- cost-processes.json, cost-results.json and raw/: retained stdout/stderr, exits, timeouts, wall time and batch checksums.
- frozen-config.json: exact bindings, algorithms, versions and workload settings.
