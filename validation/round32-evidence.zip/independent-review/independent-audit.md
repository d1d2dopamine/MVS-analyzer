# Independent Round32 retained-evidence audit

**Evidence review passed; direct replacement remains NO-GO.** This document records checks completed before packaging. No candidate runs were repeated to prepare it.

## Verified evidence
- All 359 frozen file bindings verified, including the configuration, reference, native-build and driver hashes recorded in independent-audit.json.
- All 126 processes (6 correctness, 120 cost) exited successfully without timeout or launch failure. Their retained stdout/stderr hashes were verified.
- Independently recomputed numerical gates using Decimal precision 250 and checked reference rounding through exact Fraction conversion: 170 candidate failures, comprising 118 subnormal errors exceeding eight minimum-subnormal quanta (maximum 1,015 quanta) and 52 minimum-subnormal outputs where the reference rounds to zero.
- B has zero premature zeros, versus 2,108 for A. Central maximum absolute error improves from approximately 1.463e-7 to 1.023e-16.
- All 165 rank cases pass. All 26 KW rows (24 SciPy fixtures and two declared policies) are bitwise unchanged.

## Five threshold mismatches
All five are unchanged decisions from A; none is a newly worsened A-to-B decision. The complete bits and directions are in the JSON.
- At alpha .10, .05, and .001 (two points), A and B do not reject; both the rounded-policy and mathematical references reject.
- At alpha .20 and z=2.3939797998185095, A and B reject. The mathematical reference also rejects, but the rounded-policy reference does not: adjusted rounded H equals alpha. This is specifically a policy-rounding disagreement.
- All 174 changed A-to-B decisions improve against the rounded-policy reference. The five unchanged incorrect decisions still fail the preregistered all-point gate.

## Independently checked cost arithmetic
- Startup medians: 94.010421 to 98.078239 ms, an increase of 4.067818 ms. Nearest-rank p95: 109.925479 to 108.619653 ms. Both budgets pass; summaries exclude the retained first pair and contain 29 observations per variant.
- Scalar throughput medians: 2.701776 to 12.034210 ms per 100,000 measured calls, ratio 4.454184950935978 versus limit 1.25. All 30 batches per variant are retained.
- Published harness size: 859,369 to 2,460,610 bytes, increase 1,601,241 bytes, within budget.

## Interpretation
Math.NET substantially improves ordinary tail accuracy and removes premature zeros, but the direct substitution fails the frozen extreme-tail, threshold-policy and primitive-throughput gates. This does not establish general library unreliability or scientific superiority of current MVS. The throughput ratio is for the fixed scalar workload, not the complete application. Warm-cache Linux harness results do not establish cold-start or Windows behavior. Native internal z was not observed. No failed points were filtered, criteria relaxed or candidate retuned. Production remains unchanged; scientific NO-GO remains.
