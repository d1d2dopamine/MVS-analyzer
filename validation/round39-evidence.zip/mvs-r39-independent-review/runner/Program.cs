using System.Reflection;
using System.Runtime.Loader;
using System.Runtime.InteropServices;

string assemblyPath = args.Single();
string directory = Path.GetDirectoryName(assemblyPath)!;
AssemblyLoadContext.Default.Resolving += (context, name) => {
    string candidate = Path.Combine(directory, name.Name + ".dll");
    return File.Exists(candidate) ? context.LoadFromAssemblyPath(candidate) : null;
};
var assembly = AssemblyLoadContext.Default.LoadFromAssemblyPath(assemblyPath);
Console.WriteLine($"Independent targeted reflection run: {RuntimeInformation.OSDescription}; {RuntimeInformation.FrameworkDescription}");
Console.WriteLine($"Target: {assemblyPath}");
Environment.SetEnvironmentVariable("MVS_DISABLE_BACKUPS", "1");
string root = Path.Combine(Path.GetTempPath(), "mvs-r39-independent-" + Guid.NewGuid().ToString("N"));
Directory.CreateDirectory(root);
Environment.SetEnvironmentVariable("MVS_APPDATA_ROOT", root);
int count = 0, failures = 0;
try {
    foreach (string className in new[] { "BackupRetryChecks", "BackupProvenanceChecks" }) {
        var type = assembly.GetType(className, true)!;
        var all = type.GetProperty("All", BindingFlags.NonPublic | BindingFlags.Static)!;
        var tests = (IEnumerable<(string Name, Action Run)>)all.GetValue(null)!;
        foreach (var test in tests) {
            count++;
            try { test.Run(); Console.WriteLine($"PASS {className}: {test.Name}"); }
            catch (Exception error) { failures++; Console.WriteLine($"FAIL {className}: {test.Name}: {error}"); }
        }
    }
    var helper = assembly.GetType("BackupPublicationFault", true)!.GetMethod("ExpectDirectoryCollision", BindingFlags.Static | BindingFlags.NonPublic)!;
    string obstruction = Path.Combine(root, "MVS_Backups.zip");
    Directory.CreateDirectory(obstruction);
    var unauthorized = new UnauthorizedAccessException("independent synthetic Windows fault");
    Exception? seen = null;
    try { OldIOExceptionCatch(() => throw unauthorized); } catch (Exception error) { seen = error; }
    Check(ReferenceEquals(seen, unauthorized), "old IOException-only catch rejects synthetic UnauthorizedAccessException");
    helper.Invoke(null, new object[] { (Action)(() => throw unauthorized), obstruction });
    Check(Directory.Exists(obstruction), "new helper accepts synthetic UnauthorizedAccessException with owned directory");
    var unrelated = new InvalidOperationException("independent unrelated failure");
    seen = null;
    try { helper.Invoke(null, new object[] { (Action)(() => throw unrelated), obstruction }); }
    catch (TargetInvocationException wrapped) { seen = wrapped.InnerException; }
    Check(ReferenceEquals(seen, unrelated), "new helper preserves original unrelated exception identity");
    var invalidData = new InvalidDataException("independent corrupt-data failure");
    seen = null;
    try { helper.Invoke(null, new object[] { (Action)(() => throw invalidData), obstruction }); }
    catch (TargetInvocationException wrapped) { seen = wrapped.InnerException; }
    Check(ReferenceEquals(seen, invalidData), "new helper rejects InvalidDataException with original identity");
    var missingDirectory = new DirectoryNotFoundException("independent IOException subclass failure");
    seen = null;
    try { helper.Invoke(null, new object[] { (Action)(() => throw missingDirectory), obstruction }); }
    catch (TargetInvocationException wrapped) { seen = wrapped.InnerException; }
    Check(missingDirectory is IOException && ReferenceEquals(seen, missingDirectory), "new helper rejects IOException-derived DirectoryNotFoundException with original identity");
} finally { Directory.Delete(root, true); }
Console.WriteLine($"RESULT {count - failures}/{count} targeted checks passed");
Console.WriteLine("No actual Windows runtime was used. Synthetic exception checks are not a Windows CI rerun.");
return failures == 0 ? 0 : 1;

static void OldIOExceptionCatch(Action action) { try { action(); } catch (IOException) { return; } throw new Exception("No exception"); }
void Check(bool condition, string name) { count++; if (condition) Console.WriteLine($"PASS independent: {name}"); else { failures++; Console.WriteLine($"FAIL independent: {name}"); } }
