# Round39 independent review

Verdict: no blocking findings in the bounded test-only correction.

## Confirmed evidence

Both owner-supplied logs report 181/188 tests passed and the same seven access-denied failures: one late backup retry test and all six late provenance/reload cases. The logs report exception messages only; they do not establish the actual exception type or stack.

The source creates an owned directory named `MVS_Backups.zip`. Publication reaches `BackupSession.Begin -> Flush -> Store -> ExportAll -> File.Move(temporary, destination, true)`. `Store` installs an individual checkpoint before publishing the archive. The old late-failure expectations catch only `IOException`, so a Windows `UnauthorizedAccessException` escapes before the state assertions run.

The .NET 8 Windows implementation forwards a failed native MoveFile call to Win32Marshal; ERROR_ACCESS_DENIED maps to exact UnauthorizedAccessException:
- https://github.com/dotnet/runtime/blob/v8.0.0/src/libraries/System.Private.CoreLib/src/System/IO/FileSystem.Windows.cs#L181-L187
- https://github.com/dotnet/runtime/blob/v8.0.0/src/libraries/Common/src/System/IO/Win32Marshal.cs#L35-L37
- https://learn.microsoft.com/en-us/dotnet/api/system.io.file.move?view=net-8.0

This is source-supported diagnosis, not an observed Windows rerun.

## Patch review

Only three code files differ from Round38: BackupPublicationFault.cs (new), BackupRetryChecks.cs, and BackupProvenanceChecks.cs. The two original test files change only the late-failure expectation and registration of five helper checks. All existing pending-restore, serialized state, partial checkpoint, identity, retained-unit, environment, repeated-reload, cancellation, objective-call, and exact numerical-result assertions remain. The original early file-obstruction helper still catches IOException only.

The test-only helper accepts exact IOException or exact UnauthorizedAccessException exclusively. It requires the owned directory before invoking publication and after an accepted failure, and rejects success. Unexpected exceptions propagate unchanged. DirectoryNotFoundException is an IOException subtype that is explicitly rejected; InvalidDataException is also rejected but derives from SystemException, not IOException.

The source snapshot had 539 unchanged common files and only the three test source changes plus newly added Round39 documentation. Production sources, existing payloads, source pins, and workflow files were byte-identical. See source-and-log-review.json for file hashes and owner-log evidence. The new documentation correctly distinguishes source-supported diagnosis and synthetic checks from actual Windows acceptance; external CI-run metadata reported in it was not independently rechecked in this narrowly scoped review.

## Independent execution

A separate external reflection runner executed on Debian GNU/Linux 13, .NET 8.0.31:
- 11 BackupRetryChecks tests, including the five new helper tests: passed.
- 25 BackupProvenanceChecks tests: passed.
- 5 independent checks: passed.
- Total: 41/41 targeted checks passed; exit code 0.

Independent checks proved that the old IOException-only catch propagates a synthetic UnauthorizedAccessException, the new helper accepts that same exception with an existing directory, and unrelated InvalidOperationException, InvalidDataException, and IOException-derived DirectoryNotFoundException preserve their original exception identities.

Evidence: targeted-checks.log; runner/Program.cs; runner/ReviewRunner.csproj. The candidate test assembly SHA-256 is recorded in source-and-log-review.json. No duplicate full suite was run by this reviewer.

## Remaining acceptance

No Windows runtime was used. A native Windows rerun is still required to establish that the seven previously failing real filesystem cases now pass and to reach downstream Windows-only acceptance checks. Synthetic exception injection establishes classifier behavior only.
