#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
SDK="${MVS_TEST_DOTNET:-/workspace/scratch/8105054a3211/mvs_r22_baseline/sdk/dotnet}"
if [[ $# -ne 1 ]]; then echo "Usage: $0 NEW_EVIDENCE_DIRECTORY" >&2; exit 2; fi
export DOTNET_CLI_HOME="$ROOT/dotnet-home" DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1 DOTNET_CLI_TELEMETRY_OPTOUT=1
"$SDK" build "$ROOT/source-snapshot/MvsAnalyzer.Cli/MvsAnalyzer.Cli.csproj" -c Release -o "$ROOT/baseline-cli" --nologo
"$SDK" build "$ROOT/harness/ResumeRepro.csproj" -c Release --nologo
"$SDK" "$ROOT/harness/bin/Release/net8.0/MvsAnalyzer.Core.Tests.dll" "$1"
