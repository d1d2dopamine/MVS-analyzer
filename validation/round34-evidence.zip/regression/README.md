# Round 34 baseline: resumed exports disappear from machine failure metadata

This is a deterministic synthetic engineering counterexample, not a numerical validation experiment. It preserves the existing release-readiness `no_go` boundary.

## Verified result

The unchanged round-33 `BackupRunner.Run` resumed a genuine incomplete calibration checkpoint, then failed at `calibration_tracks.csv` because a synchronous progress callback had created a directory at that exact file destination. Earlier complete writes remained on disk:

- `calibration_state.json`: 17,692 bytes, successfully read and validated by `CalibrationPersistence`.
- `calibration.csv`: 4,800 bytes.

The unchanged `CliMachineProtocol.Write` encoded that failure with `status:error`, `exitCode:1`, `execution.completed:false`, `outputDirectory:null`, `artifacts:[]`, and no `partialOutput`. No `backup_resume.json` or completion manifest was written.

## Exact boundary and injection

The failure case executes the actual unmodified `BackupRunner.Run` and the actual unmodified machine serializer used by the CLI catch boundary. It does **not** invoke `CliProgram.Main`. The latter forces progress quiet in JSON mode, so no deterministic external progress injection is available through that route. This limitation is explicit rather than relying on a filesystem-watcher race or claiming stronger coverage.

Injection happens synchronously on final calibration progress (`Fraction == 1`), after the restored folder exists and before any exported file is written. It creates only the directory collision at `calibration_tracks.csv`. There is no production source edit, binary patch, polling, sleep, or filesystem watcher. The runner itself writes state, reads it back, writes the first CSV, then encounters the expected `IOException` on the next atomic move.

The harness assembly uses the already-authorized test friend assembly name solely to access internal core APIs. Machine context reset and machine serialization use reflection. Runtime observation of the existing active session is read-only.

## Real checkpoint and isolation

- Fixture observations: 2 independent groups, 6 entities per group, 6 measurements per entity, using a fixed formula.
- Calibration: 100 repetitions, seed 54, existing default tracks. This small budget is only a software fixture.
- Checkpoint is produced by the real `AnalysisEngine.Calibrate`, cancelling on its first synchronous progress callback; normal disposal durably saves `simulation/0`.
- The copied `fixture-input.mvsbackup` is checksum-validated by normal `ReadArchive`/`Validate` and remains byte-for-byte unchanged.
- Automatic backups remain **enabled**. Resume writes go to a separate private backup folder. App-data and XDG folders are isolated.
- During resumed progress the active session has `WasRestored == true`, holds the same decoded checkpoint document, and exposes the original cached unit. That unit is preserved unchanged.

## Evidence

- `baseline-run/result.json`: assertions, retained files and hashes, restored-session observations, failure destination, immutable checkpoint hash.
- `baseline-run/machine-output.json`: actual machine failure payload.
- `baseline-run/error.txt`: actual exception and stack.
- `baseline-run/fixture-manifest.json`: genuine incomplete checkpoint metadata.
- `baseline-run/fixture-input.mvsbackup`: frozen input bytes.
- `baseline-run/fixture-observations.json`: exact input observations.
- `baseline-run/binary-provenance.json`: actual loaded CLI/core/harness paths and SHA-256 values.
- `baseline-source-before.json`, `baseline-source-after.json`, `baseline-attestation.json`: all 47 compiled-source/project inputs copied unchanged from round 33, plus production-source immutability and actual-loaded-binary checks.
- `logs/baseline-build.log`, `logs/harness-build.log`, `logs/baseline-console.json`: build and execution logs.
- `source-snapshot/`: frozen unmodified build input. `baseline-cli/`: fresh build from that input.

## Replay

Run `./run-repro.sh /absolute/path/to/a/new/evidence-directory`. Existing evidence directories are refused. Set `MVS_TEST_DOTNET` if using a different .NET 8 SDK. The script rebuilds only the external frozen source snapshot and external harness; it does not edit the production source tree.

The captured run used .NET SDK 8.0.425 and runtime .NET 8.0.31 on Linux. Both baseline and harness builds completed with zero warnings and errors.

## Candidate regression suite added after the frozen baseline proof

The historical `baseline-run/` proof above remains unchanged. The candidate regression suite is committed under Round34 `validation/resume_output_harness/`, with five bounded completed-result fixtures bundled in `validation/resume-output-fixtures-v1.zip` and saved-evidence validation in `validation/test_resume_output_contract.py`.

- Final baseline + candidate: `regression-baseline-candidate/report.json`, 27/27 passed.
- Final standalone candidate-only CI path: `regression-candidate-only/report.json`, 26/26 passed.
- Saved candidate-only validation: 55 discovered, 54 passed and one expected baseline-only skip; 45 of these are pure corruption guards.
- Initial pre-refinement full run remains in `regression-initial/` (27/27 passed).

Coverage includes first/second/late/state-reread/provenance failures, actual analyze and scientific manifest failures for all four other kinds, start/before/after observer exceptions with successful retry, cancellation before and after export, empty/foreign/current environment histories, immutable input bytes, legacy-vs-observer-disabled artifact parity across five kinds, and real `CliProgram.Main` success in human and JSON modes. Late calibration uses the original proof's exact synchronous final-progress directory collision.

Completed-result fixtures test cache/export parity only. The genuine incomplete calibration fixture tests actual restoration. Full benchmark behavior is deliberately outside the new observer seam; the harness verifies only missing-profile rejection without observer calls.

`regression-summary.json` records final source hashes, report hashes, exact counts, and these limits.
