// Synthetic engineering fixture only. This is not a numerical validation experiment.
// Executes unmodified BackupRunner.Run and CliMachineProtocol.Write; does NOT claim to invoke CliProgram.Main for the faulting case.
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using MvsAnalyzer;

string root = Path.GetFullPath(args.Single());
if (Directory.Exists(root) || File.Exists(root)) throw new IOException("Use a fresh evidence directory.");
Directory.CreateDirectory(root);
var json = new JsonSerializerOptions { WriteIndented = true };
void Save(string name, object value) => File.WriteAllText(Path.Combine(root, name), JsonSerializer.Serialize(value, json), new UTF8Encoding(false));
string Hash(string path) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path))).ToLowerInvariant();
void Require(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
foreach (string name in new[] { "MVS_APPDATA_ROOT", "XDG_DATA_HOME", "XDG_CONFIG_HOME" }) Environment.SetEnvironmentVariable(name, Path.Combine(root, "isolated", name));
Environment.SetEnvironmentVariable("MVS_DISABLE_BACKUPS", null);
string generation = Path.Combine(root, "checkpoint-generation"); Environment.SetEnvironmentVariable("MVS_BACKUP_DIR", generation);
var data = AnalysisEngine.Build(Enumerable.Range(0, 2).SelectMany(g => Enumerable.Range(0, 6).SelectMany(e => Enumerable.Range(0, 6).Select(i => new Observation("G" + g + "E" + e, "G" + g, 100 + g * 3 + e * .7 + Math.Sin(i + e), i)))).ToList());
File.WriteAllText(Path.Combine(root, "fixture-observations.json"), ScientificJson.Serialize(data.Observations));
using var stop = new CancellationTokenSource();
bool cancelled = false;
try { AnalysisEngine.Calibrate(data, 100, 1.15, 54, new Reporter(p => stop.Cancel()), stop.Token, tracks: AnalysisEngine.DefaultTracks); }
catch (OperationCanceledException) { cancelled = true; }
Require(cancelled, "Fixture generation did not stop at first synchronous progress callback.");
string generated = Directory.GetFiles(generation, "*.mvsbackup").Single(p => !p.Contains(".previous."));
string checkpointPath = Path.Combine(root, "fixture-input.mvsbackup"); File.Copy(generated, checkpointPath);
string beforeHash = Hash(checkpointPath);
var fixture = BackupSession.ReadArchive(checkpointPath).Single(); BackupSession.Validate(fixture);
Require(!fixture.CalculationComplete && fixture.Units.Count == 1 && fixture.Units.ContainsKey("simulation/0"), "Fixture is not an unfinished genuine single-unit checkpoint.");
Save("fixture-manifest.json", new { purpose = "Synthetic engineering regression fixture only; no scientific claim.", checkpointPath, sha256 = beforeHash, bytes = new FileInfo(checkpointPath).Length, fixture.Id, fixture.Request.Kind, fixture.CalculationComplete, savedUnits = fixture.Units.Keys.OrderBy(x => x).ToArray(), fixture.RequestHash, fixture.Environments, observations = data.Observations.Count, entities = data.Entities.Count, groups = data.GroupNames.Length, repetitions = 100, seed = 54, tracks = AnalysisEngine.DefaultTracks, generation = "AnalysisEngine.Calibrate cancelled by first synchronous IProgress report; automatic checkpoint flushed on disposal." });
Environment.SetEnvironmentVariable("MVS_BACKUP_DIR", Path.Combine(root, "resume-backups"));
string parent = Path.Combine(root, "resume-output"); Directory.CreateDirectory(parent);
Assembly cli = Assembly.Load("mvs");
Type context = cli.GetType("MvsAnalyzer.Cli.CliMachineContext", true)!;
Type protocol = cli.GetType("MvsAnalyzer.Cli.CliMachineProtocol", true)!;
context.GetMethod("Reset", BindingFlags.Static | BindingFlags.Public)!.Invoke(null, new object[] { true, true });
string cachedUnitBefore = fixture.Units["simulation/0"].GetRawText();
bool restoredSessionObserved = false, originalDocumentObserved = false, cachedUnitObserved = false;
string? restoredFolder = null, collision = null; bool injected = false; int progressReports = 0; double injectedAtFraction = -1;
Exception? error = null;
try
{
    BackupRunner.Run(fixture, parent, new Reporter(p => {
        progressReports++;
        var active = (AsyncLocal<BackupSession?>)typeof(BackupSession).GetField("active", BindingFlags.Static | BindingFlags.NonPublic)!.GetValue(null)!;
        var session = active.Value;
        restoredSessionObserved |= session?.WasRestored == true;
        originalDocumentObserved |= ReferenceEquals(typeof(BackupSession).GetField("document", BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(session), fixture);
        cachedUnitObserved |= session != null && session.Try<AnalysisEngine.CalibrationStep>("simulation/0", out _);
        if (p.Fraction < 1 || injected) return;
        restoredFolder = Directory.GetDirectories(parent, "MVS_restored_*").Single();
        collision = Path.Combine(restoredFolder, "calibration_tracks.csv");
        Directory.CreateDirectory(collision); injected = true; injectedAtFraction = p.Fraction;
    }), default);
}
catch (Exception e) { error = e; }
Require(restoredSessionObserved && originalDocumentObserved && cachedUnitObserved && fixture.Units["simulation/0"].GetRawText() == cachedUnitBefore, "Actual pending restore or preserved cached unit was not observed.");
Require(injected && error is IOException, "Expected a deterministic late export IOException.");
Require(restoredFolder != null && File.Exists(Path.Combine(restoredFolder, "calibration.csv")) && File.Exists(Path.Combine(restoredFolder, "calibration_state.json")), "Earlier complete exports were not retained.");
Require(!File.Exists(Path.Combine(restoredFolder!, "backup_resume.json")), "Expected failure before resume provenance.");
CalibrationPersistence.Validate(CalibrationPersistence.Read(Path.Combine(restoredFolder!, "calibration_state.json")));
var writer = new StringWriter();
protocol.GetMethod("Write", BindingFlags.Static | BindingFlags.Public)!.Invoke(null, new object?[] { writer, "resume", 1, error });
File.WriteAllText(Path.Combine(root, "machine-output.json"), writer.ToString(), new UTF8Encoding(false));
File.WriteAllText(Path.Combine(root, "error.txt"), error!.ToString(), new UTF8Encoding(false));
JsonObject payload = JsonNode.Parse(writer.ToString())!.AsObject();
Require(payload["status"]!.GetValue<string>() == "error" && payload["exitCode"]!.GetValue<int>() == 1 && !payload["execution"]!["completed"]!.GetValue<bool>(), "Machine execution failure contract differs.");
Require(payload["outputDirectory"] == null && payload["artifacts"]!.AsArray().Count == 0 && !payload.ContainsKey("partialOutput"), "Baseline did not reproduce lost partial-output metadata.");
string afterHash = Hash(checkpointPath); Require(beforeHash == afterHash, "Frozen checkpoint bytes changed.");
object[] retained = Directory.GetFiles(restoredFolder!).Select(p => (object)new { name = Path.GetFileName(p), path = p, sizeBytes = new FileInfo(p).Length, sha256 = Hash(p) }).ToArray();
Save("result.json", new { reproduced = true, boundary = "Unmodified BackupRunner.Run + unmodified CliMachineProtocol.Write, not CliProgram.Main for this injected failure", design = "No timing, polling, watcher, production-source or production-binary patch: synchronous final calibration progress callback creates a directory at the later calibration_tracks.csv destination.", injected, injectedAtFraction, progressReports, restoredSessionObserved, originalDocumentObserved, cachedUnitObserved, cachedUnitBefore, cachedUnitAfter = fixture.Units["simulation/0"].GetRawText(), failure = error.GetType().Name, failedPath = collision, restoredFolder, retained, checkpointPath, checkpointBeforeSha256 = beforeHash, checkpointAfterSha256 = afterHash, machineOutputDirectory = (string?)payload["outputDirectory"], machineArtifactCount = payload["artifacts"]!.AsArray().Count, machineHasPartialOutput = payload.ContainsKey("partialOutput"), scientificReadiness = payload["scientificReadiness"], completedUtc = DateTimeOffset.UtcNow });
Save("binary-provenance.json", new { harness = new { path = Assembly.GetExecutingAssembly().Location, sha256 = Hash(Assembly.GetExecutingAssembly().Location) }, core = new { path = typeof(AnalysisData).Assembly.Location, sha256 = Hash(typeof(AnalysisData).Assembly.Location) }, cli = new { path = cli.Location, sha256 = Hash(cli.Location) }, runtime = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription, os = System.Runtime.InteropServices.RuntimeInformation.OSDescription, backupsDisabled = Environment.GetEnvironmentVariable("MVS_DISABLE_BACKUPS") == "1" });
Console.WriteLine(File.ReadAllText(Path.Combine(root, "result.json")));
return 0;

sealed class Reporter(Action<ProgressInfo> action) : IProgress<ProgressInfo> { public void Report(ProgressInfo value) => action(value); }
