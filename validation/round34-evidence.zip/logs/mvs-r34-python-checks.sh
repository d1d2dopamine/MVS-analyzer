set -eu
source /workspace/scratch/8105054a3211/mvs_r22_baseline/env.sh
cd /workspace/scratch/8105054a3211/mvs_round34/MVS-analyzer-main
export PYTHONPATH="$PWD/python/src"
PY=/workspace/scratch/8105054a3211/mvs_mcp_venv/bin/python
$PY tools/test_backups.py
$PY tools/test_paper_benchmark.py
$PY tools/test_paper_benchmark_runner.py
$PY tools/test_release_bundle.py
