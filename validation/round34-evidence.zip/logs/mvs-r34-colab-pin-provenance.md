# Pre-existing historical source-pin failure

An additional Round34 check ran `python tools/test_colab_connection.py` against both unmodified Round33 and candidate Round34. Both yielded 47/48 passing tests; the same historical-byte-pin test fails first on Benchmark/BenchmarkDatasets.cs. Neither this test nor its pin files is modified by Round34.

Read-only comparison shows that first file matches Round25, Round33 and Round34 byte-for-byte. Its exact Round23→25 change replaces CsvImporter.Read plus a subsequent pathname hash with CsvImporter.Import and its captured SourceSha256. This is the documented Round25 input-provenance fix, not unexplained Round34 drift. Historical expected hash: eb4a320c9c52221f1792f668f02cd6930a885a4cc10d2a8a5e932a779ad0cc96. Actual reviewed hash: 51600284f4612df7f27106901d882beb8d2b63349df0d082125af99bd96d0ea6.

A read-only scan of all30 pins finds17 mismatches, listed in colab-pin-provenance.json. The test stops at its first mismatch. Other historical changes require individual provenance reconciliation before any pin refresh. This stage does not silently accept or rewrite them. Earlier reported successful aggregate Python suites did not include this additional Colab connection test.

An attempted invocation of tools/test_windows_workflow.py without its required --artifacts argument exited during argument parsing. No Windows integration test ran in that invocation. It is retained in tools-tests.log and excluded from test counts.
