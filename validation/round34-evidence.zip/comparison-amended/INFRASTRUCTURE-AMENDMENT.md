# Round34 infrastructure amendment 1

The original 30 planned attempts all failed in the driver: strict JSON parsing produced Decimal for the watchdog interval, and threading.Event.wait rejected that type. Each watchdog recorded its error, killed/reaped its process, and retained the capture/resource record. All original files, driver, plan, binding and read-only-verified failure report remain unchanged in ../mvs-r34-comparison. Those attempts do not establish model/output parity or useful completed-process cost.

The authorized correction converts only timeout and polling interval to float at the execute boundary, before the timer starts. Scientific JSON stays Decimal/exact-token based. Two regressions use the actual parsed plan and Decimal timeout/interval values. No native source, binary, science setting, fixture, workload/order, normalization or measurement endpoint changes.

This directory receives a separately frozen binding and, only after renewed exclusive GO, all 30 new attempts in the original AB/BA/AB order. No selective reruns or deletion of failures. Original and amended results must both be disclosed. The normative amendment is in round34-plan.json.
