# Round34 TEST-only resume/export comparison

## Frozen question and scope

Does the Round34 resume output-observer change preserve successful resume output, scientific status, cache contents and environment history relative to Round33? What is the descriptive whole-process cost of this narrow completed-cache resume/export path?

This comparison does not test new model calculations, unfinished-work traversal, statistical correctness, or scientific release readiness. Existing scientific **NO-GO remains**. The independent genuine unfinished calibration export-failure regression is a separate deliverable.

The normative machine-readable protocol is `round34-plan.json`; five fixture identities, expected exits/artifacts and construction provenance are in `fixtures/manifest.json`. All original checkpoints are frozen completed-result engineering fixtures: `CalculationComplete=true`, only `Units.result`, zero unfinished units. They originate from already-retained Round33 results, reconstructed using baseline deserialization/serialization and explicitly authorized deterministic input aggregation. No model run was required to prepare them. Native constructor/request, typed result and checksum validations plus independent Python checks and identical-byte regeneration have passed. `fixture-preparation/README.md` explains the procedure and limitations.

## Measurement design

- Five checkpoint kinds, in order: calibrate, analyze, variance, estimation, MELSM.
- Three matched fresh-process A/B pairs per kind: AB, BA, AB. Thirty attempts total; zero warmups or replacement runs.
- A = baseline Round33; B = candidate Round34. Both consume exact immutable checkpoint bytes.
- CLI command is `resume --in <frozen fixture> --out <fresh output parent> --json --quiet`.
- Backups remain **enabled**. `MVS_DISABLE_BACKUPS=1` is forbidden because it bypasses restore/cache. Every invocation has isolated empty backup/appdata/home/tmp directories. Input archives are separate from generated archives.
- Calibrate/analyze/variance/estimation require exit 0; the retained MELSM `not_converged` report requires diagnostic exit 2. This expected diagnostic is not a failure or a scientific success claim.
- Bind sources, binary directories, runtime host/CoreCLR, two allowed CPUs, environment, driver, plan and fixture identities before any execution. Recheck before and after every attempt. No actual CLI/model comparison launches until the lead explicitly gives an exclusive measurement-window GO after other CPU work finishes.

## Blocking-wait timing and bounded lifecycle

The driver opens stdout/stderr captures first, then starts its monotonic nanosecond clock immediately before Popen. The main thread uses `wait4(exact_pid, 0)` and captures its clock endpoint as the first operation after wait returns. That wait supplies the exact child's user/system CPU and Linux kernel peak RSS. It owns the single reap; Popen is marked with the obtained return code.

An independent watchdog checks timeout, allowed affinity and sampled RSS, and kills the owned child process group on violation. The watchdog interval does **not** poll child completion. Timeout enforcement is sampling-based, not a hard real-time guarantee if process creation or a system observation stalls. Event notification and bounded watchdog join occur after the wall endpoint, so a delayed watchdog cannot add the old 50 ms completion-detection bias to wall time. CPU/RSS/wall are descriptive observations, with no speed pass threshold or significance claim.

Launch failures, nonzero exits, timeouts, partial stdout/stderr and resource records are retained. Remaining planned attempts continue unless a frozen binding becomes invalid, child cleanup is unresolved, or the user stops execution. A failed or incomplete comparison cannot pass, and no failed attempt is replaced.

## Exactness and cache checks

Raw scientific CSV/JSON bytes remain exact. Only listed timestamp, generated path, run-ID, and derived integrity pointers are token-replaced; numeric spelling, formatting, field order and scientific data are never generally reserialized. Every raw artifact, manifest association, size/hash and calibration payload checksum is independently validated first. All six normalized runs per kind must match the first baseline; three explicit paired A/B comparisons are also recorded.

Each invocation must produce its real newly published primary backup. It must preserve the exact Request bytes, request hash, result-unit bytes, unit keys, completion marker, identity and original environment-history prefix. Only one current-environment append is permitted. Full decoded resumed checkpoint bytes must agree across pairs after replacing its newly published SavedUtc. Frozen input SavedUtc and `backup_resume.json` receive **no** normalization. Together with the bound core's immediate completed-result cache-return branch, these checks establish this is genuine completed-cache resume/export, not fresh model calculation with backup disabled.

## Commands and retained evidence

Run pure/lifecycle regressions first:

`python test_resume_comparison.py`

These execute only harmless Python subprocess fixtures, not MVS/native models. They test the deterministic 13.123456 ms unquantized endpoint and call ordering, watchdog-join exclusion, timeout/kill/reap, RSS kill, interruption, launch/nonzero failures, exact bytes/checksums, cache/history guards, 30-attempt failure retention, and fully read-only verification.

Bind only final builds (the baseline binary may be an isolated exact-source build):

`python run_resume_comparison.py --root <evidence-root> freeze --baseline-binary <baseline-mvs.dll> --candidate-binary <candidate-mvs.dll>`

After explicit lead GO only:

`python run_resume_comparison.py --root <evidence-root> run --approved-exclusive-window`

Recompute retained results without any writes or native/model rerun:

`python run_resume_comparison.py --root <evidence-root> verify`

`run` publishes raw captures, invocation/resource records, generated backup/output artifacts, normalized comparison bytes, full raw metrics and ratio summaries, and an evidence inventory under `execution/`. `verify` only reads; missing evidence is an error and cannot be silently generated or repaired. The driver and tests can be copied unchanged into a durable validation directory and use `--root` for this external evidence root.
