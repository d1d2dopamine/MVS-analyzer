#!/usr/bin/env python3
"""Read-only verification; never runs native scientific or resume commands."""
import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parent.parent
fixtures = root / 'fixtures'
manifest = json.loads((fixtures / 'manifest.json').read_text())
checks = []
for fixture in manifest['fixtures']:
    path = fixtures / fixture['file']
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == fixture['sha256']
    assert len(raw) == fixture['sizeBytes']
    with zipfile.ZipFile(path) as archive:
        assert archive.namelist() == ['backup.json', 'SHA256SUMS.txt']
        body = archive.read('backup.json')
        assert archive.read('SHA256SUMS.txt').decode() == hashlib.sha256(body).hexdigest() + '  backup.json\n'
        assert all(entry.date_time == (2026, 10, 16, 0, 0, 0) for entry in archive.infolist())
    document = json.loads(body)
    assert document['CalculationComplete'] is True and list(document['Units']) == ['result']
    request_bytes = (fixtures / (fixture['id'] + '-request.json')).read_bytes()
    assert json.loads(request_bytes) == document['Request']
    assert hashlib.sha256(request_bytes).hexdigest() == document['RequestHash'] == fixture['requestHash']
    assert document['Id'] == fixture['backupId'] and document['Environments'] == fixture['environmentHistory']
    for source in fixture['sourceFiles']:
        source_bytes = Path(source['path']).read_bytes()
        assert len(source_bytes) == source['sizeBytes']
        assert hashlib.sha256(source_bytes).hexdigest() == source['sha256']
    checks.append({'id': fixture['id'], 'archive': True, 'request': True, 'allSources': True,
                   'counts': fixture['counts'], 'expectedExit': fixture['expectedExit'], 'artifacts': fixture['artifacts']})
print(json.dumps({'schema': 1, 'status': 'pass', 'checks': checks}, indent=2))
