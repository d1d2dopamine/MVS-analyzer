#!/usr/bin/env bash
set -euo pipefail
here=/workspace/scratch/8105054a3211/mvs-r34-comparison/fixture-preparation
export DOTNET_ROOT=/workspace/scratch/8105054a3211/mvs_r22_baseline/sdk
export DOTNET_CLI_HOME="$here/home" HOME="$here/home" TMPDIR="$here/tmp"
export DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1 DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_GENERATE_ASPNET_CERTIFICATE=false
export MVS_APPDATA_ROOT="$here/appdata"
mkdir -p "$HOME" "$TMPDIR"
"$DOTNET_ROOT/dotnet" build "$here/FixturePrep.csproj" -c Release --nologo --no-restore > "$here/build.log" 2>&1
"$DOTNET_ROOT/dotnet" "$here/bin/Release/net8.0/MvsAnalyzer.Core.Tests.dll" > "$here/preparation.log" 2>&1
