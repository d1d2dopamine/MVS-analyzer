using System.Globalization;
using System.IO.Compression;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using MvsAnalyzer;

// Fixture preparation only. Deliberately no BackupRunner.Run, scientific Run,
// Calibrate, Results, recording factory, Begin, optimizer or simulation call.
// AnalysisEngine.Build is deterministic input aggregation, explicitly authorized.
string root = "/workspace/scratch/8105054a3211";
string baseline = Path.Combine(root, "mvs_round33/MVS-analyzer-main");
string r33 = Path.Combine(root, "mvs-r33-comparison");
string destination = Path.Combine(root, "mvs-r34-comparison/fixtures");
string preparation = Path.Combine(root, "mvs-r34-comparison/fixture-preparation");
Directory.CreateDirectory(destination);
DateTime saved = new(2026, 10, 16, 0, 0, 0, DateTimeKind.Utc);
string Output(string kind) {
    string folder = Path.Combine(r33, "execution", kind + "-pair1-2-B", "output");
    return Directory.GetFiles(folder, "*.json").Length > 0 ? folder : Directory.GetDirectories(folder).Single();
}
string Input(string name) => Path.Combine(r33, "inputs", name);
void Assert(bool condition, string message) { if (!condition) throw new InvalidDataException(message); }
void EqualJson(string sourceJson, string actualJson, string context) => Assert(JsonNode.DeepEquals(JsonNode.Parse(sourceJson), JsonNode.Parse(actualJson)), context + " typed reconstruction differs from source.");
object Source(string path) => new { path = Path.GetFullPath(path), sha256 = OutputExporter.HashFile(path), sizeBytes = new FileInfo(path).Length };
string[] commonSources = {
    Path.Combine(baseline, "MvsAnalyzer.Core/bin/Release/net8.0/MvsAnalyzer.Core.dll"),
    Path.Combine(baseline, "Infrastructure/PortableBackup.cs"),
    Path.Combine(baseline, "Infrastructure/BackupRunner.cs"),
    Path.Combine(baseline, "Core/AnalysisEngine.cs"),
    Path.Combine(baseline, "Infrastructure/CsvImporter.cs"),
    Path.Combine(preparation, "Program.cs"), Path.Combine(preparation, "FixturePrep.csproj")
};
var manifest = new List<object>();
void Save<T>(string kind, BackupRequest request, T result, int exitCode, string[] artifacts, IEnumerable<string> sources, object counts, string construction, string environment) {
    string packedRequest = BackupSession.Pack(request);
    string requestHash = ScientificMath.Hash(packedRequest);
    var doc = new BackupDocument {
        Id = ScientificMath.Hash("mvs-r34-completed-engineering-fixture-v1:" + kind)[..32],
        SavedUtc = saved, OriginJob = "", Request = request, RequestHash = requestHash,
        Environments = new List<string> { environment }, CalculationComplete = true,
        Units = new Dictionary<string, JsonElement>(StringComparer.Ordinal) { ["result"] = JsonSerializer.SerializeToElement(result, BackupSession.Json) }
    };
    // Match the exact request constructor in the native cache consumer, without executing it.
    BackupRequest reconstructed = kind switch {
        "calibrate" => new BackupRequest { Kind = kind, Data = request.Data, Repetitions = request.Repetitions, Effect = request.Effect, Seed = request.Seed, Scenario = request.Scenario, Outliers = request.Outliers, Missing = request.Missing, Alpha = request.Alpha, Tracks = request.Tracks },
        "analyze" => new BackupRequest { Kind = kind, Data = request.Data, Calibration = request.Calibration, Alpha = request.Alpha, Margin = request.Margin, Seed = request.Seed },
        "variance" => new BackupRequest { Kind = kind, Data = request.Data, Repetitions = request.Repetitions, ReferenceReplications = request.ReferenceReplications, Effect = request.Effect, SecondEffect = request.SecondEffect, Seed = request.Seed, Alpha = request.Alpha },
        "estimation" => new BackupRequest { Kind = kind, Estimation = request.Estimation },
        "melsm" => new BackupRequest { Kind = kind, Observations = request.Observations, Melsm = request.Melsm },
        _ => throw new InvalidOperationException()
    };
    reconstructed = reconstructed with { Context = request.Context };
    Assert(BackupSession.Pack(reconstructed) == packedRequest, kind + " request does not match native consumer constructor.");
    BackupSession.Validate(doc);
    byte[] encoded = BackupSession.Encode(doc);
    // ZIP-entry timestamps are metadata only; freeze them along with SavedUtc and Id.
    using (var buffer = new MemoryStream()) {
        buffer.Write(encoded); buffer.Position = 0;
        using (var zip = new ZipArchive(buffer, ZipArchiveMode.Update, true))
            foreach (var entry in zip.Entries) entry.LastWriteTime = new DateTimeOffset(saved);
        encoded = buffer.ToArray();
    }
    BackupDocument decoded = BackupSession.Decode(encoded);
    Assert(decoded.CalculationComplete && decoded.Units.Keys.SequenceEqual(new[] { "result" }), kind + " missing completed result.");
    Assert(BackupSession.Pack(decoded.Request) == packedRequest && decoded.RequestHash == requestHash, kind + " request roundtrip differs.");
    T typedResult = decoded.Units["result"].Deserialize<T>(BackupSession.Json) ?? throw new InvalidDataException("Missing typed result.");
    Assert(BackupSession.Pack(typedResult) == BackupSession.Pack(result), kind + " result roundtrip differs.");
    string filename = kind + "-completed.mvsbackup", path = Path.Combine(destination, filename);
    if (File.Exists(path)) Assert(File.ReadAllBytes(path).SequenceEqual(encoded), "Frozen original may not be replaced with different bytes: " + path);
    else File.WriteAllBytes(path, encoded);
    File.WriteAllText(Path.Combine(destination, kind + "-request.json"), packedRequest, new UTF8Encoding(false));
    manifest.Add(new {
        id = kind, file = filename, sha256 = OutputExporter.HashFile(path), sizeBytes = encoded.Length,
        expectedExit = new[] { exitCode }, artifacts = artifacts.OrderBy(x => x, StringComparer.Ordinal).ToArray(),
        calculationComplete = true, unitKeys = new[] { "result" }, completedCachedResults = 1, unfinishedUnits = 0,
        construction, sourceFiles = sources.Concat(commonSources).Distinct().Select(Source).ToArray(), counts,
        requestHash, requestSha256 = ScientificMath.Hash(packedRequest), resultSha256 = ScientificMath.Hash(decoded.Units["result"].GetRawText()),
        backupId = doc.Id, savedUtc = saved.ToString("O", CultureInfo.InvariantCulture), environmentHistory = doc.Environments,
        validation = new { nativeArchiveDecode = true, nativeRequestRoundTrip = true, nativeTypedResultRoundTrip = true, matchesNativeRequestConstructor = true, nativeResumeExecuted = false }
    });
    Console.WriteLine($"{kind}: {filename}; sha256={OutputExporter.HashFile(path)}; bytes={encoded.Length}; expectedExit={exitCode}");
}

string summaryInput = Input("summary_fixture.csv");
string analyzeFolder = Output("analyze");
string qualityPath = Path.Combine(analyzeFolder, "data_quality.csv");
string analyzeManifestPath = Path.Combine(analyzeFolder, "run_manifest.json");
var imported = CsvImporter.Import(summaryInput, -1000000, 1000000);
AnalysisData summary = AnalysisEngine.Build(imported.Observations, -1000000, 1000000, 6);
summary.ImportSummary = imported.Summary;
using var csvParser = new Microsoft.VisualBasic.FileIO.TextFieldParser(qualityPath);
csvParser.SetDelimiters(","); csvParser.HasFieldsEnclosedInQuotes = true;
var quality = new List<string[]>();
while (!csvParser.EndOfData) quality.Add(csvParser.ReadFields()!);
Assert(quality[0].Skip(3).SequenceEqual(AnalysisEngine.MetricKeys), "Retained metric registry differs.");
Assert(quality.Count == summary.Entities.Count + 1, "Retained entity count differs.");
for (int i = 0; i < summary.Entities.Count; i++) {
    var entity = summary.Entities[i]; var row = quality[i + 1];
    Assert(row[0] == "P_" + ScientificMath.Hash(AnalysisEngine.Key(entity.Group, entity.Entity))[..10] && row[1] == entity.Group && int.Parse(row[2], CultureInfo.InvariantCulture) == entity.Measurements, "Entity identity/count mismatch.");
    for (int j = 0; j < entity.Metrics.Length; j++) {
        double retained = row[j+3].Length == 0 ? double.NaN : double.Parse(row[j+3], CultureInfo.InvariantCulture);
        Assert(BitConverter.DoubleToInt64Bits(retained) == BitConverter.DoubleToInt64Bits(entity.Metrics[j]), "Summary metric differs from retained output.");
    }
}
using var analyzedManifest = JsonDocument.Parse(File.ReadAllText(analyzeManifestPath));
var retainedData = analyzedManifest.RootElement.GetProperty("data");
Assert(retainedData.GetProperty("importSummary").GetString() == summary.ImportSummary, "Import summary differs.");
Assert(retainedData.GetProperty("entities").GetInt32() == summary.Entities.Count && retainedData.GetProperty("validRows").GetInt32() == summary.ValidRows, "Source counts differ.");
Assert(analyzedManifest.RootElement.GetProperty("warnings").EnumerateArray().Select(x => x.GetString()).SequenceEqual(summary.Warnings), "Source warnings differ.");

string calStatePath = Path.Combine(Output("calibrate"), "calibration_state.json");
CalibrationState calibrated = ScientificJson.Read<CalibrationState>(calStatePath);
EqualJson(File.ReadAllText(calStatePath), ScientificJson.Serialize(calibrated), "calibrate state");
var calRequest = new BackupRequest { Kind = "calibrate", Data = summary, Repetitions = calibrated.Repetitions, Effect = calibrated.Effect, Seed = calibrated.Seed,
    Scenario = calibrated.Scenario, Outliers = calibrated.OutlierRate, Missing = calibrated.MissingRate, Alpha = calibrated.Alpha, Tracks = calibrated.Tracks,
    Context = new BackupContext(summary, DatasetName: calibrated.Dataset, DatasetHash: imported.SourceSha256, Project: "Headless analysis", Processing: calibrated.Processing, Split: calibrated.SplitCalibration, Margin: calibrated.EquivalenceMargin) };
Save("calibrate", calRequest, calibrated.Rows, 0,
    new[] { "backup_resume.json", "calibration_state.json", "calibration.csv", "calibration_tracks.csv" },
    new[] { summaryInput, calStatePath, qualityPath, analyzeManifestPath, Path.Combine(r33,"execution/calibrate-pair1-2-B/invocation.json") },
    new { observations = summary.Observations.Count, entities = summary.Entities.Count, groups = summary.GroupNames.Length, calibrationRows = calibrated.Rows.Count, repetitions = calibrated.Repetitions, tracks = calibrated.Tracks.Length },
    "Completed engineering checkpoint constructed from Round33 B calibration rows. Deterministic AnalysisEngine.Build input aggregation only; every entity metric checked bitwise against retained analyze/data_quality.csv. No new calibration or scientific run.", calibrated.EnvironmentHash);

string analysisStatePath = Path.Combine(r33, "frozen-calibration/calibration_state.json");
CalibrationState analysisState = ScientificJson.Read<CalibrationState>(analysisStatePath);
EqualJson(File.ReadAllText(analysisStatePath), ScientificJson.Serialize(analysisState), "analyze calibration state");
string resultsPath = Path.Combine(analyzeFolder, "results.json");
using var exportedResults = JsonDocument.Parse(File.ReadAllText(resultsPath));
var results = exportedResults.RootElement.GetProperty("rows").Deserialize<List<ResultRow>>(ScientificJson.Options)!;
EqualJson(exportedResults.RootElement.GetProperty("rows").GetRawText(), ScientificJson.Serialize(results), "analyze rows");
var analysisRequest = new BackupRequest { Kind = "analyze", Data = summary, Calibration = analysisState.Rows, Alpha = analysisState.Alpha, Margin = analysisState.EquivalenceMargin, Seed = analysisState.Seed,
    Context = new BackupContext(summary, analysisState, analysisState.Dataset, imported.SourceSha256, "Round33 frozen comparison", "Deterministic engineering output parity only", analysisState.Processing, analysisState.SplitCalibration, analysisState.EquivalenceMargin) };
Save("analyze", analysisRequest, results, 0,
    new[] { "backup_resume.json", "calibration_state.json", "calibration.csv", "calibration_tracks.csv", "calibration_recommendations.csv", "data_quality.csv", "metric_availability.csv", "results.csv", "results.json", "run_manifest.json" },
    new[] { summaryInput, analysisStatePath, resultsPath, qualityPath, analyzeManifestPath, Path.Combine(r33,"execution/analyze-pair1-2-B/invocation.json") },
    new { observations = summary.Observations.Count, entities = summary.Entities.Count, groups = summary.GroupNames.Length, calibrationRows = analysisState.Rows.Count, resultRows = results.Count },
    "Completed engineering checkpoint constructed from full typed Round33 B results.json rows and frozen calibration. Deterministic input aggregation only; summary entity metrics checked bitwise against retained data_quality.csv. No analysis/resampling run.", analysisState.EnvironmentHash);

string varianceInput = Input("variance_demo.csv");
var varianceImported = CsvImporter.Import(varianceInput, int.MinValue, int.MaxValue);
AnalysisData varianceData = AnalysisEngine.Build(varianceImported.Observations, int.MinValue, int.MaxValue, 3);
// ScientificCommands.Variance does not set ImportSummary; retain Build's exact default.
string variancePath = Path.Combine(Output("variance"), "variance_report.json");
var variance = ScientificJson.Read<VarianceReport>(variancePath);
EqualJson(File.ReadAllText(variancePath), ScientificJson.Serialize(variance), "variance report");
Assert(variance.Groups.Sum(x => x.Entities) == varianceData.Entities.Count && variance.Groups.Sum(x => x.Measurements) == varianceData.ValidRows, "Variance source counts differ.");
var varianceRequest = new BackupRequest { Kind = "variance", Data = varianceData, Repetitions = 100, ReferenceReplications = 99, Effect = 1.3, SecondEffect = 1.3, Seed = variance.Seed, Alpha = variance.Alpha };
int varianceExit = variance.Groups.Any(g => g.Status == "not_converged_or_degenerate") || variance.Tracks.Any(t => t.Status is "bootstrap_or_fit_failure" or "excess_simulation_failures") ? 2 : 0;
Save("variance", varianceRequest, variance, varianceExit,
    new[] { "backup_resume.json", "variance_report.json", "variance_components.csv", "variance_tests.csv", "run_manifest.json" },
    new[] { varianceInput, variancePath, Path.Combine(Output("variance"), "run_manifest.json"), Path.Combine(r33,"execution/variance-pair1-2-B/invocation.json") },
    new { observations = varianceData.Observations.Count, entities = varianceData.Entities.Count, groups = varianceData.GroupNames.Length, resultGroups = variance.Groups.Length, resultTracks = variance.Tracks.Length, repetitions = 100, referenceReplications = 99 },
    "Completed engineering checkpoint from retained Round33 B VarianceReport; deterministic AnalysisEngine.Build aggregation of original input only, not serialization-only. No variance fit, bootstrap or simulation executed.", calibrated.EnvironmentHash);

string estimationPath = Path.Combine(Output("estimation"), "estimation_report.json");
var estimation = ScientificJson.Read<EstimationReport>(estimationPath);
EqualJson(File.ReadAllText(estimationPath), ScientificJson.Serialize(estimation), "estimation report");
Save("estimation", new BackupRequest { Kind = "estimation", Estimation = estimation.Options }, estimation, estimation.Performance.Any(p => p.Status == "excess_failures") ? 2 : 0,
    new[] { "backup_resume.json", "estimation_report.json", "estimation_performance.csv", "estimation_draws.csv", "run_manifest.json" },
    new[] { estimationPath, Path.Combine(Output("estimation"), "run_manifest.json"), Path.Combine(r33,"execution/estimation-pair1-2-B/invocation.json") },
    new { requestEntities = estimation.Options.Entities, requestMeasurements = estimation.Options.Measurements, repetitions = estimation.Options.Repetitions, bootstrapReplications = estimation.Options.BootstrapReplications, performanceRows = estimation.Performance.Length, drawRows = estimation.Draws.Length },
    "Completed engineering checkpoint from native typed deserialization of Round33 B EstimationReport and its Options. No estimation or simulation executed.", calibrated.EnvironmentHash);

string melsmInput = Input("repeated_conditions_8_subjects.csv");
var melsmImported = CsvImporter.Import(melsmInput, int.MinValue, int.MaxValue, allowSingleGroup: true);
string melsmPath = Path.Combine(Output("melsm"), "melsm_report.json");
var melsmExported = ScientificJson.Read<MelsmReport>(melsmPath);
var subjectMap = melsmImported.Observations.Select(x => x.Entity).Distinct().ToDictionary(x => "P_" + ScientificMath.Hash(x)[..12], x => x);
Assert(subjectMap.Count == melsmExported.Subjects && melsmImported.Observations.Count == melsmExported.Observations, "MELSM source counts differ.");
Assert(melsmExported.RandomEffects.Select(x => x.Entity).Distinct().Count() == melsmExported.RandomEffects.Length && melsmExported.RandomEffects.All(x => subjectMap.ContainsKey(x.Entity)), "MELSM hash mapping is not unique/complete.");
var melsm = melsmExported with { RandomEffects = melsmExported.RandomEffects.Select(x => x with { Entity = subjectMap[x.Entity] }).ToArray() };
var reexported = melsm with { RandomEffects = melsm.RandomEffects.Select(x => x with { Entity = "P_" + ScientificMath.Hash(x.Entity)[..12] }).ToArray() };
EqualJson(File.ReadAllText(melsmPath), ScientificJson.Serialize(reexported), "MELSM restored/re-anonymized report");
Save("melsm", new BackupRequest { Kind = "melsm", Observations = melsmImported.Observations, Melsm = melsm.Options }, melsm, melsm.Status == "converged_experimental" ? 0 : 2,
    new[] { "backup_resume.json", "melsm_report.json", "melsm_parameters.csv", "melsm_random_effects.csv", "run_manifest.json" },
    new[] { melsmInput, melsmPath, Path.Combine(Output("melsm"), "run_manifest.json"), Path.Combine(r33,"execution/melsm-pair1-2-B/invocation.json") },
    new { observations = melsmImported.Observations.Count, subjects = subjectMap.Count, parameterRows = melsm.Parameters.Length, randomEffectRows = melsm.RandomEffects.Length, status = melsm.Status, iterations = melsm.Iterations },
    "Completed engineering checkpoint from Round33 B MelsmReport. Retained not_converged report has zero random-effect rows, so zero IDs required inversion. Exact exporter SHA256 prefix mapping is checked against unique input subject IDs and re-export matches retained report. No optimizer, quadrature, model fit or scientific run.", calibrated.EnvironmentHash);

File.WriteAllText(Path.Combine(destination, "manifest.json"), JsonSerializer.Serialize(new {
    schema = 1,
    scope = "Frozen completed-result engineering cache/export parity fixtures; not unfinished checkpoint traversal, scientific recomputation, model validation, or interrupted-work evidence.",
    baselineProject = baseline, sourceComparison = r33,
    preparation = "Native baseline deserialization/serialization plus explicitly authorized deterministic AnalysisEngine.Build input aggregation. No native/model/CLI resume executed during preparation.",
    requiredResumeEnvironment = new { MVS_DISABLE_BACKUPS = "must be unset or 0; never 1", MVS_BACKUP_DIR = "fresh isolated directory per invocation" },
    metadata = new { savedUtc = saved.ToString("O", CultureInfo.InvariantCulture), zipEntryTimestamps = saved.ToString("O", CultureInfo.InvariantCulture), backupIds = "first 32 hex of SHA256(mvs-r34-completed-engineering-fixture-v1:<kind>)" },
    fixtures = manifest
}, new JsonSerializerOptions { WriteIndented = true }) + "\n", new UTF8Encoding(false));
Console.WriteLine("Completed five frozen fixture documents. No resume or scientific model command was executed.");
