"""Read-only retained comparison audit; never launches native/model processes."""
from pathlib import Path
import datetime, hashlib, json, statistics, zipfile
BASE=Path('/workspace/scratch/8105054a3211')
ROOT=BASE/'mvs-r34-comparison-amended'; EX=ROOT/'execution'
read=lambda p:json.loads(p.read_text())
hash_bytes=lambda b:hashlib.sha256(b).hexdigest()
sha=lambda p:hash_bytes(p.read_bytes())
def identity(p):return {'sizeBytes':p.stat().st_size,'sha256':sha(p)}
def spans(raw):
    text=raw.decode('utf-8');decoder=json.JSONDecoder();found={}
    def whitespace(pos):
        while pos<len(text) and text[pos].isspace():pos+=1
        return pos
    def value(pos,path):
        pos=whitespace(pos);start=pos
        if text[pos]=='{':
            pos=whitespace(pos+1)
            while text[pos]!='}':
                key,pos=decoder.raw_decode(text,pos);pos=whitespace(pos);assert text[pos]==':'
                pos=value(pos+1,path+'/'+key.replace('~','~0').replace('/','~1'));pos=whitespace(pos)
                if text[pos]=='}':break
                assert text[pos]==',';pos=whitespace(pos+1)
            pos+=1
        elif text[pos]=='[':
            pos=whitespace(pos+1);i=0
            while text[pos]!=']':
                pos=value(pos,path+'/'+str(i));i+=1;pos=whitespace(pos)
                if text[pos]==']':break
                assert text[pos]==',';pos=whitespace(pos+1)
            pos+=1
        else:_,pos=decoder.raw_decode(text,pos)
        found[path]=(start,pos);return pos
    assert whitespace(value(0,''))==len(text)
    return text,found

def token(raw,pointer):
    text,found=spans(raw);a,b=found[pointer];return text[a:b].encode()
def replace(raw,changes):
    text,found=spans(raw)
    edits=[(*found[p],json.dumps(v,ensure_ascii=True,allow_nan=False,separators=(',',':'))) for p,v in changes.items()]
    for a,b,v in sorted(edits,reverse=True):text=text[:a]+v+text[b:]
    return text.encode()
def checkpoint(path):
    with zipfile.ZipFile(path) as z:
        assert sorted(z.namelist())==['SHA256SUMS.txt','backup.json'];raw=z.read('backup.json')
        assert z.read('SHA256SUMS.txt').decode().strip()==hash_bytes(raw)+'  backup.json'
    return raw,json.loads(raw)
def normalize_state(raw):
    doc=json.loads(raw);assert hash_bytes(replace(raw,{'/PayloadHash':''}))==doc['PayloadHash']
    raw=replace(raw,{'/CreatedUtc':'<timestamp>','/PayloadHash':''})
    return replace(raw,{'/PayloadHash':hash_bytes(raw)})
def summary(values):return {'values':values,'available':len(values),'median':statistics.median(values),'min':min(values),'max':max(values)}
report=read(EX/'comparison-results.json');plan=read(ROOT/'round34-plan.json');binding=read(ROOT/'binding.json');fixtures=read(ROOT/'fixtures/manifest.json')['fixtures']
assert report['passed'] is True and not report['errors'] and report['invocationCount']==30
assert report['bindingSha256']==sha(ROOT/'binding.json') and report['planSha256']==sha(ROOT/'round34-plan.json') and report['driverSha256']==sha(ROOT/'run_resume_comparison.py')
expected=[(f,p,n,label) for f in fixtures for p,order in enumerate(['AB','BA','AB'],1) for n,label in enumerate(order,1)]
raw_records=report['allRawMeasurements'];assert len(raw_records)==30
assert len({r['id'] for r in raw_records})==30
journal=[json.loads(line) for line in (EX/'invocations.jsonl').read_text().splitlines()];assert journal==raw_records
normalized_by_kind={};records_by_kind={};artifact_count=0;normal_count=0;checkpoint_count=0
for supplied,(fixture,pair,position,label) in zip(raw_records,expected):
    ident=f'{fixture["id"]}-pair{pair}-{position}-{label}';folder=EX/ident;record=read(folder/'record.json');assert record==supplied
    assert (record['id'],record['workload'],record['pair'],record['position'],record['build'])==(ident,fixture['id'],pair,position,label)
    assert record['cpuAffinity']==binding['cpuAffinity'] and record['returncode'] in fixture['expectedExit']
    assert record['reaped'] is True and record['forcedKill'] is False and not record['events'] and record['runnerError'] is None and not record['cleanupErrors'] and not record['interrupted']
    assert record['command'][0]==binding['dotnetHost']['path'] and record['command'][1]==binding['builds'][label]['entrypoint']
    assert record['environment']['MVS_BACKUP_DIR']==str(folder/'backups') and 'MVS_DISABLE_BACKUPS' not in record['environment']
    for key,v in binding['baseEnvironment'].items():assert record['environment'][key]==v
    for filename,key in [('stdout.json','stdout'),('stderr.log','stderr')]:assert identity(folder/filename)==record[key]
    raw=(folder/'stdout.json').read_bytes();payload=json.loads(raw);assert payload['exitCode']==record['returncode'];assert payload['status']==('diagnostic' if record['returncode']==2 else 'completed');assert payload['command']=='resume' and payload['execution']['completed'] and payload['error'] is None and 'partialOutput' not in payload
    assert payload['scientificReadiness']['status']=='no_go';output=Path(payload['outputDirectory']);assert output.is_relative_to(folder/'output') and output.is_dir()
    files={p.name:p for p in output.iterdir()};assert set(files)==set(fixture['artifacts'])
    artifacts=payload['artifacts'];assert len({a['name'] for a in artifacts})==len(artifacts)==len(files)
    normalized={}
    for item in artifacts:
        path=Path(item['path']);assert path==files[item['name']] and path.is_file() and not path.is_symlink();assert identity(path)=={'sizeBytes':item['sizeBytes'],'sha256':item['sha256']};artifact_count+=1
        if item['name']!='run_manifest.json':normalized[item['name']]=normalize_state(path.read_bytes()) if item['name']=='calibration_state.json' else path.read_bytes()
    if 'run_manifest.json' in files:
        mr=files['run_manifest.json'].read_bytes();md=json.loads(mr);assert payload['manifestPath']==str(files['run_manifest.json']) and payload['runId']==md['runId'];assert {x['FileName'] for x in md['files']}==set(files)-{'run_manifest.json'}
        changes={'/created':'<timestamp>','/runId':'<run-id>'}
        for i,item in enumerate(md['files']):
            name=item['FileName'];assert identity(files[name])=={'sizeBytes':item['SizeBytes'],'sha256':item['sha256']};changes[f'/files/{i}/sha256']=hash_bytes(normalized[name]);changes[f'/files/{i}/SizeBytes']=len(normalized[name])
        normalized['run_manifest.json']=replace(mr,changes)
    else:assert payload['manifestPath'] is None and payload['runId'] is None
    changes={'/outputDirectory':'<output>','/manifestPath':'<output>/run_manifest.json' if payload['manifestPath'] else None,'/runId':'<run-id>' if payload['runId'] else None}
    for i,item in enumerate(artifacts):
        name=item['name'];changes[f'/artifacts/{i}/path']='<output>/'+name;changes[f'/artifacts/{i}/sha256']=hash_bytes(normalized[name]);changes[f'/artifacts/{i}/sizeBytes']=len(normalized[name])
    normalized['stdout.json']=replace(raw,changes)
    source=ROOT/'fixtures'/fixture['file'];assert identity(source)=={'sizeBytes':fixture['sizeBytes'],'sha256':fixture['sha256']};sr,sd=checkpoint(source)
    saved=[p for p in (folder/'backups').glob('*.mvsbackup') if not p.name.endswith('.previous.mvsbackup')];assert len(saved)==1;cr,cd=checkpoint(saved[0]);checkpoint_count+=1
    assert cd['CalculationComplete'] is True and set(cd['Units'])=={'result'} and cd['Id']==sd['Id'] and cd['RequestHash']==sd['RequestHash'];assert token(cr,'/Request')==token(sr,'/Request') and token(cr,'/Units/result')==token(sr,'/Units/result')
    assert cd['SavedUtc']!=sd['SavedUtc'] and cd['Environments'][:len(sd['Environments'])]==sd['Environments']
    normalized['resumed_checkpoint.json']=replace(cr,{'/SavedUtc':'<session-save-timestamp>'})
    actual={p.name:p.read_bytes() for p in (folder/'normalized').iterdir()};assert actual==normalized;normal_count+=len(normalized)
    normalized_by_kind.setdefault(fixture['id'],[]).append(normalized);records_by_kind.setdefault(fixture['id'],[]).append(record)
for kind,items in normalized_by_kind.items():assert all(item==items[0] for item in items)
medians={}
for w in report['workloads']:
    kind=w['workload'];assert w['passed'] and w['invocations']==6 and not w['errors'];records=records_by_kind[kind]
    for metric,data in w['performance'].items():
        values={label:[next(r[metric] for r in records if r['pair']==pair and r['build']==label) for pair in (1,2,3)] for label in ('A','B')}
        assert data['A']==summary(values['A']) and data['B']==summary(values['B'])
        ratios=[bb/aa for aa,bb in zip(values['A'],values['B'])];assert data['pairedBOverA']==summary(ratios);assert data['medianBOverMedianA']==statistics.median(values['B'])/statistics.median(values['A'])
    medians[kind]={metric:{'baselineMedian':v['A']['median'],'candidateMedian':v['B']['median'],'medianBOverMedianA':v['medianBOverMedianA'],'pairedRatioMedian':v['pairedBOverA']['median']} for metric,v in w['performance'].items() if metric in ('wallSeconds','cpuTotalSeconds','peakRssKiB')}
inv=read(EX/'evidence-sha256.json');assert {str(p.relative_to(EX)) for p in EX.rglob('*') if p.is_file() and p.name!='evidence-sha256.json' and '__pycache__' not in p.parts}==set(inv)
for path,entry in inv.items():assert identity(EX/path)==entry
result={'schema':'mvs-round34-final-comparison-independent-audit/v1','reviewedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':True,'scope':'Bounded read-only audit of completed retained amendment comparison; no reruns/native/model processes. Original failed30 untouched.','resultSha256':sha(EX/'comparison-results.json'),'bindingSha256':sha(ROOT/'binding.json'),'attempts':30,'order':'Five fixtures, each AB/BA/AB; exact raw record/JSONL order verified.','expectedExitCounts':{'0':24,'2':6},'allReapedWithoutWatchdogOrCleanupErrors':True,'actualOutputArtifactsIndependentlyRehashed':artifact_count,'normalizedFilesIndependentlyReconstructedAndCompared':normal_count,'savedResumeArchivesVerified':checkpoint_count,'retainedInventoryFilesIndependentlyRehashed':len(inv),'allSixOutputsPerWorkloadExactAfterEnumeratedMetadataNormalization':True,'allMetricValuesMediansRangesAndPairRatiosRecomputed':True,'descriptiveMedians':medians,'limitations':['Completed-result cached resume/export engineering fixtures; no unfinished model recomputation.','Three matched pairs only; descriptive process cost, no speed/significance claim.','Original30 infrastructure failures remain separately retained and disclosed.','Scientific NO-GO unchanged.']}
print(json.dumps(result,indent=2))
