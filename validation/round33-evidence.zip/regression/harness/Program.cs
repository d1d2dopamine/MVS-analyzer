using System.Globalization;
using System.Reflection;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

if (args.Length != 2) throw new ArgumentException("Usage: Repro <absolute-cli-assembly> <new-run-directory>");
string cliAssemblyPath = Path.GetFullPath(args[0]);
string runDirectory = Path.GetFullPath(args[1]);
if (Directory.Exists(runDirectory)) throw new IOException("A fresh run directory is required; refusing to overwrite prior evidence.");
Directory.CreateDirectory(runDirectory);
string outputDirectory = Path.Combine(runDirectory, "output");
string inputPath = Path.Combine(runDirectory, "input.csv");
var fixture = new StringBuilder("entity,group,value,sequence\n");
// Fixed, synthetic engineering fixture. This is not a numerical experiment.
for (int group = 0; group < 2; group++)
for (int entity = 1; entity <= 6; entity++)
for (int measurement = 1; measurement <= 6; measurement++)
{
    double value = 100 + 3 * group + 0.7 * entity + 0.6 * measurement + ((entity * measurement) % 5) * 0.11;
    fixture.AppendLine($"{(group == 0 ? "A" : "B")}{entity},{(group == 0 ? "A" : "B")},{value.ToString("R", CultureInfo.InvariantCulture)},{measurement}");
}
File.WriteAllText(inputPath, fixture.ToString(), new UTF8Encoding(false));
string[] cliArguments = { "calibrate", "--in", inputPath, "--out", outputDirectory, "--repetitions", "100", "--seed", "20260719", "--json", "--quiet" };
var settings = new Dictionary<string, string>
{
    ["MVS_DISABLE_BACKUPS"] = "1",
    ["MVS_BACKUP_DIR"] = Path.Combine(runDirectory, "isolated-backups"),
    ["MVS_APPDATA_ROOT"] = Path.Combine(runDirectory, "isolated-appdata"),
    ["XDG_DATA_HOME"] = Path.Combine(runDirectory, "isolated-data"),
    ["XDG_CONFIG_HOME"] = Path.Combine(runDirectory, "isolated-config"),
    ["MVS_DEBUG"] = "1"
};
foreach (var setting in settings) Environment.SetEnvironmentVariable(setting.Key, setting.Value);
var jsonOptions = new JsonSerializerOptions { WriteIndented = true };
string Hash(string path) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path))).ToLowerInvariant();
var provenance = new
{
    harness = "deterministic-post-preflight-calibration-export-collision/v1",
    fixturePurpose = "Synthetic fixture engineering only; no numerical experiment or scientific validation.",
    invocation = "Reflection invocation of actual MvsAnalyzer.Cli.CliProgram.Main(string[]) from CLI assembly, without modified production sources.",
    trigger = "Exact Console line 'MVS calibration', emitted after OutputSafety.Preflight; create output/calibration_tracks.csv as an owned directory.",
    cliAssemblyPath,
    cliAssemblySha256 = Hash(cliAssemblyPath),
    coreAssemblySha256 = Hash(Path.Combine(Path.GetDirectoryName(cliAssemblyPath)!, "MvsAnalyzer.Core.dll")),
    inputPath,
    inputSha256 = Hash(inputPath),
    cliArguments,
    environment = settings,
    startedUtc = DateTimeOffset.UtcNow,
    framework = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,
    os = System.Runtime.InteropServices.RuntimeInformation.OSDescription
};
File.WriteAllText(Path.Combine(runDirectory, "provenance.json"), JsonSerializer.Serialize(provenance, jsonOptions));
var oldOut = Console.Out;
var oldError = Console.Error;
var stdout = new StringWriter(CultureInfo.InvariantCulture);
var stderr = new StringWriter(CultureInfo.InvariantCulture);
bool intercepted = false;
int triggerCount = 0;
void Intercept(string line)
{
    if (line != "MVS calibration") return;
    triggerCount++;
    if (intercepted) throw new InvalidOperationException("Trigger unexpectedly repeated.");
    bool outputExistedBeforeTrigger = Directory.Exists(outputDirectory);
    string conflict = Path.Combine(outputDirectory, "calibration_tracks.csv");
    Directory.CreateDirectory(conflict);
    intercepted = true;
    File.WriteAllText(Path.Combine(runDirectory, "trigger.json"), JsonSerializer.Serialize(new
    {
        line,
        triggeredUtc = DateTimeOffset.UtcNow,
        outputExistedBeforeTrigger,
        createdOwnedDirectory = conflict,
        outputEntriesAtTrigger = Directory.GetFileSystemEntries(outputDirectory).Select(Path.GetFileName).ToArray()
    }, jsonOptions));
}
var errorWriter = new LineInterceptWriter(stderr, Intercept);
var outWriter = new LineInterceptWriter(stdout, Intercept);
string assemblyDirectory = Path.GetDirectoryName(cliAssemblyPath)!;
AssemblyLoadContext.Default.Resolving += (context, name) =>
{
    string path = Path.Combine(assemblyDirectory, name.Name + ".dll");
    return File.Exists(path) ? context.LoadFromAssemblyPath(path) : null;
};
int exitCode;
Exception? harnessError = null;
try
{
    Console.SetOut(outWriter);
    Console.SetError(errorWriter);
    Assembly assembly = AssemblyLoadContext.Default.LoadFromAssemblyPath(cliAssemblyPath);
    Type program = assembly.GetType("MvsAnalyzer.Cli.CliProgram", throwOnError: true)!;
    MethodInfo main = program.GetMethod("Main", BindingFlags.NonPublic | BindingFlags.Static)!;
    exitCode = (int)main.Invoke(null, new object[] { cliArguments })!;
}
catch (Exception error)
{
    harnessError = error;
    exitCode = -1;
}
finally
{
    Console.SetOut(oldOut);
    Console.SetError(oldError);
    File.WriteAllText(Path.Combine(runDirectory, "stdout.json"), stdout.ToString(), new UTF8Encoding(false));
    File.WriteAllText(Path.Combine(runDirectory, "stderr.log"), stderr.ToString(), new UTF8Encoding(false));
}
JsonElement? payload = null;
string? payloadParseError = null;
try { using var document = JsonDocument.Parse(stdout.ToString()); payload = document.RootElement.Clone(); }
catch (Exception error) { payloadParseError = error.Message; }
var retainedFiles = Directory.Exists(outputDirectory)
    ? Directory.GetFiles(outputDirectory, "*", SearchOption.AllDirectories).OrderBy(x => x, StringComparer.Ordinal).Select(path => new { path, relativePath = Path.GetRelativePath(outputDirectory, path), sizeBytes = new FileInfo(path).Length, sha256 = Hash(path) }).ToArray()
    : Array.Empty<object>();
bool observedBug = exitCode == 1 && intercepted && File.Exists(Path.Combine(outputDirectory, "calibration.csv")) && payload.HasValue &&
    payload.Value.GetProperty("outputDirectory").ValueKind == JsonValueKind.Null && payload.Value.GetProperty("artifacts").GetArrayLength() == 0;
var result = new
{
    cliExitCode = exitCode,
    intercepted,
    triggerCount,
    observedBug,
    actualOutputDirectory = outputDirectory,
    retainedFiles,
    retainedDirectories = Directory.Exists(outputDirectory) ? Directory.GetDirectories(outputDirectory) : Array.Empty<string>(),
    machinePayload = payload,
    payloadParseError,
    harnessError = harnessError?.ToString(),
    finishedUtc = DateTimeOffset.UtcNow
};
string resultJson = JsonSerializer.Serialize(result, jsonOptions);
File.WriteAllText(Path.Combine(runDirectory, "result.json"), resultJson, new UTF8Encoding(false));
Console.WriteLine(resultJson);
return harnessError == null && intercepted && payload.HasValue ? 0 : 1;

sealed class LineInterceptWriter(TextWriter target, Action<string> callback) : TextWriter
{
    private readonly StringBuilder pending = new();
    public override Encoding Encoding => Encoding.UTF8;
    public override void Write(char value)
    {
        target.Write(value);
        if (value == '\n') { callback(pending.ToString().TrimEnd('\r')); pending.Clear(); }
        else pending.Append(value);
    }
    public override void Write(string? value) { if (value != null) foreach (char character in value) Write(character); }
    public override void WriteLine(string? value) { Write(value); Write(NewLine); }
    public override void Flush() => target.Flush();
}
