# Round33 deterministic partial-export error repro

This external harness calls the actual baseline CLI's private `CliProgram.Main(string[])` via reflection. No production file was edited. The baseline CLI was freshly built from `mvs_round32/MVS-analyzer-main` into `baseline-cli/`; build and runtime information are in `logs/`.

The trigger intercepts exactly `MVS calibration`, which HeadlessRun emits immediately after OutputSafety.Preflight. Before that trigger the output folder does not exist. The trigger creates the owned directory `output/calibration_tracks.csv`. The actual CLI imports the fixed synthetic engineering fixture, executes its required minimum 100-repetition calibration, writes `calibration.csv`, then throws IOException while committing the second export. This is fixture engineering, not a numerical experiment or a science sample. `MVS_DISABLE_BACKUPS=1` disables automatic checkpoints; other environment paths are also isolated inside the run directory.

## Observed baseline bug

- Exit code: 1; machine status: error; execution.completed: false.
- Actual error: IOException, target `output/calibration_tracks.csv` is a directory.
- Retained artifact: `output/calibration.csv`, 4,770 bytes.
- Retained artifact SHA-256: `25e685ad5f16421dabbfb37eaaf200ebf503f0e5940f39b59c62378cef8911d0`.
- Actual machine JSON incorrectly has `outputDirectory: null` and `artifacts: []`.
- No manifest/state indicates completion.

Read `baseline-run/stdout.json` for raw actual CLI machine output, `baseline-run/stderr.log` for the actual diagnostics/stack trace, `baseline-run/trigger.json` for deterministic injection evidence, `baseline-run/provenance.json` for invocation/environment/binary hashes, and `baseline-run/result.json` for the retained filesystem evidence. Input bytes are saved as `baseline-run/input.csv`.

`baseline-attestation.json` verifies every repro assertion and source equality across 463 production-tree files, excluding generated bin/obj, .git, and Python caches. Its exact file count is authoritative if this sentence becomes stale. All initial evidence hashes are in `evidence-sha256.json`.

## Reuse against a fixed build

Run `./run-repro.sh /absolute/path/to/fixed/mvs.dll /absolute/path/to/new-fixed-run` from this folder. Supply a new run directory; the harness refuses to replace existing evidence. It does not require that the bug remain present. A fixed run can be checked for the same exit 1 and retained calibration.csv while the machine result correctly includes its output directory and artifact hash. Compare the retained artifact hashes to preserve the pre-failure bytes.

The harness itself returns 0 when invocation/interception/JSON capture worked, regardless of the actual CLI exit code. Inspect `cliExitCode` and `machinePayload` in result.json for command results. `observedBug` is a baseline-signature indicator, not the harness process exit status.
