#!/usr/bin/env bash
set -euo pipefail
source /workspace/scratch/8105054a3211/mvs_r22_baseline/env.sh
# Usage: run-repro.sh /absolute/path/to/mvs.dll /absolute/path/to/new-run-directory
# The harness refuses to overwrite a pre-existing run directory.
dotnet /workspace/scratch/8105054a3211/mvs-r33-repro/harness/bin/Release/net8.0/Repro.dll "$@"
