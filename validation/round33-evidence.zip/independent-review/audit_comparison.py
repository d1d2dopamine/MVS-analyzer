from pathlib import Path
from datetime import datetime
import json, hashlib, statistics, re, importlib.util
R=Path('/workspace/scratch/8105054a3211/mvs-r33-comparison')
OUT=Path('/workspace/scratch/8105054a3211/mvs-r33-independent-review/comparison-audit.json')
def load(p): return json.loads(Path(p).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def meta(p): return {'sizeBytes':Path(p).stat().st_size,'sha256':sha(p)}
def check(c,m):
 if not c: raise AssertionError(m)
def time(s): return datetime.fromisoformat(s)
plan=load(R/'round33-plan.json'); binding=load(R/'binding.json'); report=load(R/'execution/comparison-results.json')
started=load(R/'execution/started.json'); finished=load(R/'execution/finished.json')
for key, file in [('planSha256','round33-plan.json'),('bindingSha256','binding.json'),('driverSha256','run_comparison.py')]:
 check(report[key]==sha(R/file),key)
 if key in started: check(started[key]==report[key],'start '+key)
check((R/'execution/plan.json').read_bytes()==(R/'round33-plan.json').read_bytes(),'plan copy')
check((R/'execution/binding.json').read_bytes()==(R/'binding.json').read_bytes(),'binding copy')
check((R/'round33-plan.sha256').read_text().split()[0]==report['planSha256'],'plan hash file')
check(time(plan['frozenUtc'])<time(binding['boundUtc'])<time(started['startedUtc']),'freeze chronology')
amend=load(R/'binding-path-amendment.json'); old=load(R/amend['priorBinding'])
check(sha(R/amend['priorBinding'])==amend['priorSha256'],'prior binding hash')
check(sha(R/amend['currentBinding'])==amend['currentSha256'],'current binding hash')
check(time(amend['changedUtc'])<time(started['startedUtc']),'amendment before measurements')
check(old['builds']['A']['sourceFiles']==binding['builds']['A']['sourceFiles'],'baseline source path amendment')
check(old['builds']['B']==binding['builds']['B'],'candidate invariant across amendment')
for name in ['mvs.dll','MvsAnalyzer.Core.dll']:
 check(old['builds']['A']['binaryFiles'][name]==binding['builds']['A']['binaryFiles'][name],'baseline binary unchanged '+name)
source_counts={}; binary_counts={}
for label,b in binding['builds'].items():
 root=Path(b['sourceRoot'])
 actual={str(p.relative_to(root)):meta(p) for p in root.rglob('*') if p.is_file() and p.suffix.lower() in {'.cs','.csproj','.props','.targets'} and not any(x in {'bin','obj','.git','__pycache__','validation','benchmark_history'} or x.endswith('.Tests') for x in p.relative_to(root).parts)}
 check(actual==b['sourceFiles'],'current native source binding '+label);source_counts[label]=len(actual)
 binary=Path(b['binaryDirectory']); files={str(p.relative_to(binary)):meta(p) for p in binary.rglob('*') if p.is_file()}
 check(files==b['binaryFiles'],'current binary binding '+label);binary_counts[label]=len(files)
for item in plan['inputs']: check(meta(R/'inputs'/item['name'])=={k:item[k] for k in ['sizeBytes','sha256']},'input '+item['name'])
check(meta(binding['dotnetHost']['path'])=={k:binding['dotnetHost'][k] for k in ['sizeBytes','sha256']},'dotnet host')
for p,m in binding['coreclrFiles'].items():check(meta(p)==m,'CoreCLR')
inv=load(R/'frozen-calibration/identity.json'); frozen=R/'frozen-calibration/calibration_state.json'
check(meta(frozen)==inv['file'],'frozen state')
inventory=load(R/'evidence-sha256.json')
for path,expected in inventory.items():check(meta(R/path)==expected,'evidence hash '+path)
# Import only reviewed parsing/normalization helpers. Never call run, freeze, execute, or verify.
spec=importlib.util.spec_from_file_location('reviewed_driver',R/'run_comparison.py'); mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
records=[]; output_stats=[]; normalization_count=0; artifact_count=0; previous=None
for workload in plan['workloads']:
 runs=[]; normalized=[]
 for pair,order in enumerate(plan['execution']['pairOrder'],1):
  for pos,label in enumerate(order,1):
   ident=f'{workload["id"]}-pair{pair}-{pos}-{label}'; folder=R/'execution'/ident
   rec=load(folder/'record.json'); context=load(folder/'invocation.json')
   check(all(rec[k]==v for k,v in context.items()),'invocation binding '+ident)
   check((rec['id'],rec['workload'],rec['pair'],rec['position'],rec['build'])==(ident,workload['id'],pair,pos,label),'run identity')
   args=[x.replace('{inputs}',str(R/'inputs')).replace('{output}',str(folder/'output')).replace('{frozen_calibration}',str(frozen)) for x in workload['arguments']]
   check(rec['command']==[binding['dotnetHost']['path'],binding['builds'][label]['entrypoint'],*args],'frozen command '+ident)
   env=binding['baseEnvironment']|{k:str(folder/sub) for k,sub in [('HOME','home'),('TMPDIR','tmp'),('MVS_APPDATA_ROOT','appdata')]}
   check(rec['environment']==env and rec['cpuAffinity']==binding['cpuAffinity'],'environment/affinity '+ident)
   check(rec['coreclrPaths'] and set(rec['coreclrPaths'])==set(binding['coreclrFiles']),'observed runtime '+ident)
   check(rec['returncode'] in workload['expectedExit'] and not rec['events'] and not rec['forcedKill'],'successful return '+ident)
   check(time(rec['startedUtc'])<time(rec['finishedUtc']),'run chronology')
   if previous: check(time(previous['finishedUtc'])<time(rec['startedUtc']),'nonoverlap')
   previous=rec
   for fn,k in [('stdout.json','stdout'),('stderr.log','stderr')]:check(meta(folder/fn)==rec[k],'capture hash '+ident)
   check(abs(rec['cpuTotalSeconds']-rec['cpuUserSeconds']-rec['cpuSystemSeconds'])<1e-12,'CPU accounting')
   checked=mod.inspect_run(folder,workload,frozen)
   norm={p.name:p.read_bytes() for p in (folder/'normalized').iterdir()}
   check(norm==checked['normalized'],'retained normalization '+ident)
   normalization_count+=len(norm);artifact_count+=len(checked['artifacts'])
   expected_report=next(w for w in report['workloads'] if w['workload']==workload['id'])
   evidence=next(a for a in expected_report['artifacts'] if a['invocation']==ident)
   check(evidence['actual']==checked['artifacts'],'report artifacts '+ident)
   check(evidence['normalized']=={n:{'sha256':hashlib.sha256(raw).hexdigest(),'sizeBytes':len(raw)} for n,raw in norm.items()},'report normalized '+ident)
   normalized.append(norm);runs.append(rec);records.append(rec)
 for n in normalized[1:]:check(n==normalized[0],'exact normalized parity '+workload['id'])
 expected_report=next(w for w in report['workloads'] if w['workload']==workload['id'])
 check(expected_report['passed'] and expected_report['invocations']==6 and not expected_report['errors'],'workload status')
 check(len(expected_report['comparisons'])==5 and all(c['exactNormalizedBytesEqual'] and c['statusExitEqual'] and not c['differentFiles'] for c in expected_report['comparisons']),'comparisons')
 stat={}
 for metric in plan['performance']['metrics']:
  values={label:[r[metric] for r in runs if r['build']==label] for label in ['A','B']}
  ratios=[next(r[metric] for r in runs if r['pair']==pair and r['build']=='B')/next(r[metric] for r in runs if r['pair']==pair and r['build']=='A') for pair in range(1,4)]
  calc={label:{'values':v,'median':statistics.median(v),'min':min(v),'max':max(v)} for label,v in values.items()}
  calc['pairedBOverA']={'values':ratios,'median':statistics.median(ratios),'min':min(ratios),'max':max(ratios)}
  calc['medianBOverMedianA']=statistics.median(values['B'])/statistics.median(values['A'])
  check(calc==expected_report['performance'][metric],'independent metrics '+workload['id']+'/'+metric)
  stat[metric]=calc
 output_stats.append({'workload':workload['id'],'exitCodes':sorted({r['returncode'] for r in runs}),'performance':stat})
check(len(records)==report['invocationCount']==finished['invocations']==plan['execution']['measuredProcesses']==30,'total counts')
check(records==report['allRawMeasurements'],'all raw measurements')
check(records==[json.loads(line) for line in (R/'execution/invocations.jsonl').read_text().splitlines()],'jsonl record agreement')
check(report['passed'] and not report['errors'] and finished['bindingUnchanged'],'terminal pass')
check(time(started['startedUtc'])<time(records[0]['startedUtc'])<time(records[-1]['finishedUtc'])<time(finished['finishedUtc']),'window chronology')
check(frozen.read_bytes()==(R/'execution/calibrate-pair1-1-A/output/calibration_state.json').read_bytes(),'baseline calibration copy')
result={'passed':True,'nativeReruns':0,'invocations':len(records),'sourceFiles':source_counts,'binaryFiles':binary_counts,'evidenceFilesHashed':len(inventory),'rawArtifactsVerified':artifact_count,'normalizedFilesVerified':normalization_count,'planSha256':sha(R/'round33-plan.json'),'bindingSha256':sha(R/'binding.json'),'driverSha256':sha(R/'run_comparison.py'),'baselinePathAmendmentBeforeMeasurements':True,'metrics':output_stats,'limitations':['Three pairs only; descriptive performance, no speed/significance inference.','wallSeconds includes up to one 50 ms polling interval plus sampler/scheduling delay before observing process exit.','wait4 CPU and kernel maximum RSS are exact-child measurements; elapsed polling wall time must not be presented as precise exit timing.','Native .cs/.csproj/.props/.targets are source-bound; Python and docs are outside this actual-CLI source binding.','Exact same-engine output parity is engineering evidence, not scientific validation.']}
OUT.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='metrics'},indent=2))
print('Audit:',OUT)
