#!/usr/bin/env python3
"""Pure saved-file verifier tests; never launches CLI, dotnet, or a model."""
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('comparison',ROOT/'run_comparison.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

class DriverTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='pure-',dir=ROOT)
        self.folder=Path(self.temp.name)
        self.work=next(w for w in m.read_json(m.PLAN)['workloads'] if w['id']=='calibrate')
        output=self.folder/'output';output.mkdir()
        state=b'{\n  "CreatedUtc": "2026-10-16T00:00:00Z",\n  "Rows": [{"Metric":"Mean","value":1.000000000000001}],\n  "PayloadHash": ""\n}'
        state=m.replace_tokens(state,{'/PayloadHash':m.digest(state)})
        for name in self.work['artifacts']:
            (output/name).write_bytes(state if name.endswith('.json') else b'metric,value\nMean,1.000000000000001\n')
        artifacts=[{'name':p.name,'path':str(p.resolve()),**m.record_file(p)} for p in sorted(output.iterdir())]
        payload={'schemaVersion':'mvs-cli-result/v1','command':'calibrate','exitCode':0,'status':'completed','execution':{'completed':True,'outcome':'completed'},'error':None,'engineVersion':'1.6.2','scientificReadiness':{'status':'no_go'},'outputDirectory':str(output),'runId':None,'manifestPath':None,'artifacts':artifacts}
        (self.folder/'stdout.json').write_text(json.dumps(payload,indent=2))
        (self.folder/'record.json').write_text(json.dumps({'returncode':0,'forcedKill':False,'events':[]}))
        self.payload=payload
    def tearDown(self): self.temp.cleanup()
    def inspect(self): return m.inspect_run(self.folder,self.work)
    def update(self): (self.folder/'stdout.json').write_text(json.dumps(self.payload,indent=2))
    def test_valid_artifacts(self):
        result=self.inspect();self.assertEqual(len(result['artifacts']),4)
    def test_actual_checksum_required(self):
        (self.folder/'output/calibration.csv').write_bytes(b'changed')
        with self.assertRaisesRegex(AssertionError,'size mismatch|checksum mismatch'): self.inspect()
    def test_payload_hash_required(self):
        p=self.folder/'output/calibration_state.json'
        p.write_bytes(p.read_bytes().replace(b'1.000000000000001',b'1.000000000000002'))
        for a in self.payload['artifacts']:
            if a['name']==p.name:a.update(m.record_file(p))
        self.update()
        with self.assertRaisesRegex(AssertionError,'payload checksum mismatch'): self.inspect()
    def test_duplicate_artifacts_rejected(self):
        self.payload['artifacts'][1]=self.payload['artifacts'][0];self.update()
        with self.assertRaisesRegex(AssertionError,'identity differs'): self.inspect()
    def test_wrong_path_rejected(self):
        self.payload['artifacts'][0]['path']=str(self.folder/'different.csv');self.update()
        with self.assertRaisesRegex(AssertionError,'path differs'): self.inspect()
    def test_unexpected_artifact_rejected(self):
        (self.folder/'output/unplanned.csv').write_bytes(b'x')
        with self.assertRaisesRegex(AssertionError,'file set differs'): self.inspect()
    def test_status_exit_required(self):
        self.payload['status']='diagnostic';self.update()
        with self.assertRaisesRegex(AssertionError,'status differs'): self.inspect()
    def test_calibration_cannot_claim_manifest(self):
        self.payload['runId']='invented';self.update()
        with self.assertRaisesRegex(AssertionError,'invented manifest/runId'): self.inspect()
    def test_exact_lexeme(self):
        before=b'{"data":1.00,"date":"old"}'
        after=m.replace_tokens(before,{'/date':'new'})
        self.assertEqual(after,b'{"data":1.00,"date":"new"}')
    def test_pointer_escaping_and_nested_arrays(self):
        before=b'{"a/b":{"~x":[1,2,3]},"keep":2e-20}'
        after=m.replace_tokens(before,{'/a~1b/~0x/1':'two'})
        self.assertEqual(after,b'{"a/b":{"~x":[1,"two",3]},"keep":2e-20}')
    def configure_estimation(self):
        self.work=next(w for w in m.read_json(m.PLAN)['workloads'] if w['id']=='estimation')
        output=self.folder/'output'
        for p in output.iterdir():p.unlink()
        for name in self.work['artifacts']:
            if name!='run_manifest.json':
                (output/name).write_bytes(b'{"Truth":1.00,"Status":"ok"}' if name.endswith('.json') else b'x,y\n1,2\n')
        files=[{'FileName':p.name,'SizeBytes':p.stat().st_size,'sha256':m.sha(p)} for p in sorted(output.iterdir())]
        manifest={'created':'2026-10-16T00:00:00Z','runId':'known-truth-estimation_20261016_000000','files':files}
        (output/'run_manifest.json').write_text(json.dumps(manifest,indent=2))
        self.payload.update(command='estimation',runId=manifest['runId'],manifestPath=str(output/'run_manifest.json'))
        self.refresh_artifacts();self.update()
    def refresh_artifacts(self):
        self.payload['artifacts']=[{'name':p.name,'path':str(p.resolve()),**m.record_file(p)} for p in sorted((self.folder/'output').iterdir())]
    def test_manifest_checks_and_normalization(self):
        self.configure_estimation()
        first=self.inspect()
        path=self.folder/'output/run_manifest.json'
        manifest=json.loads(path.read_text());manifest['created']='2026-10-17T00:00:00Z';manifest['runId']='known-truth-estimation_20261017_000000'
        path.write_text(json.dumps(manifest,indent=2));self.payload['runId']=manifest['runId'];self.refresh_artifacts();self.update()
        second=self.inspect()
        self.assertEqual(first['normalized'],second['normalized'])
    def test_manifest_bad_hash_rejected(self):
        self.configure_estimation()
        path=self.folder/'output/run_manifest.json'
        manifest=json.loads(path.read_text());manifest['files'][0]['sha256']='0'*64
        path.write_text(json.dumps(manifest,indent=2));self.refresh_artifacts();self.update()
        with self.assertRaisesRegex(AssertionError,'checksum mismatch'):self.inspect()
    def test_manifest_runid_association_rejected(self):
        self.configure_estimation();self.payload['runId']='wrong';self.update()
        with self.assertRaisesRegex(AssertionError,'runIds differ'):self.inspect()
    def test_manifest_missing_member_rejected(self):
        self.configure_estimation()
        path=self.folder/'output/run_manifest.json'
        manifest=json.loads(path.read_text());manifest['files'].pop()
        path.write_text(json.dumps(manifest,indent=2));self.refresh_artifacts();self.update()
        with self.assertRaisesRegex(AssertionError,'association differs'):self.inspect()
    def test_decimal_report_serialization(self):
        path=self.folder/'decimal.json'
        m.dump_new(path,{'value':m.decimal.Decimal('1.2345')})
        self.assertEqual(m.read_json(path)['value'],m.decimal.Decimal('1.2345'))
    def test_no_generic_timestamp_exclusion(self):
        raw=b'{"CreatedUtc":"2026-10-16T00:00:00Z","Rows":[{"created":"scientific column"}],"PayloadHash":""}'
        signed=m.replace_tokens(raw,{'/PayloadHash':m.digest(raw)})
        self.assertIn(b'"created":"scientific column"',m.canonical_state(signed))

if __name__=='__main__':unittest.main(verbosity=2)
