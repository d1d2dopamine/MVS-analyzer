# Round33 frozen matched actual-CLI output comparison

The authoritative pre-execution plan is `round33-plan.json`; its SHA-256 is in `round33-plan.sha256`. All files in this directory are external to both application trees. The driver does not build or modify the application.

## Fixed scope

Five actual CLI workloads: calibration (100 repetitions, retained 72-row deterministic error-repro fixture); analysis reusing one exact frozen baseline calibration; variance (100/99, baseline variance demo); estimation (100/99, normal mean, 8 entities × 6 measurements); and experimental MELSM (8 original example subjects, quadrature 7, maximum 100 iterations). Every option, expected artifact set, seed, timeout and accepted exit is fixed in the JSON plan.

Each workload has three matched fresh-process pairs in AB/BA/AB order, for 30 measured invocations in total. A is Round32, B is Round33. No warmup run is removed or hidden. All six calibration invocations precede analysis; the first baseline calibration state is copied once and its unchanged bytes are consumed by every analysis invocation. No extra model run is needed to prepare it.

The shared runtime, two-CPU affinity and minimal environment are bound before execution. Backups are disabled. Every invocation starts with empty private appdata (there are no installed plugins or saved local settings). Raw stdout, stderr, command, environment, process exit, monotonic wall, exact-child wait4 CPU and kernel maximum RSS are retained. Explicit watchdog limits retain failures; replacement or convergence-based reruns are prohibited.

## Exactness and integrity

All scientific CSV and JSON bytes must match. A JSON token-span normalizer changes only the enumerated timestamp/run-ID/path fields and their derived integrity fields; all scientific numeric spellings, formatting, field/array/row order, methods, statuses, nulls and values remain byte-exact. This does not use a floating tolerance or generic ignored-key filter.

The calibration payload hash is independently recomputed from its exact raw serialized bytes with only PayloadHash blanked. Only after this check is its timestamp normalized and its derived hash recomputed. Every machine/manifest artifact hash and size is independently checked against its associated regular file; names, complete file set, paths, manifest link and run ID must agree. Metadata hashes/sizes are then derived from normalized artifact bytes, preserving the association rather than discarding the file list. No unknown extra outputs are silently accepted. Analysis must copy the identical frozen calibration bytes.

All six runs of each workload are compared to its first baseline run, which also establishes every matched-pair comparison. Exit and status parity are exact, including accepted numerical diagnostics. Native engine identity, registry size and NO-GO status are checked. Exact same-engine export agreement is not independent scientific correctness or model validation.

## Commands and gate

Run pure tests without invoking a CLI:

    python run_comparison.py self-test

After final source/build stability is confirmed, bind sources, all binary-folder files, dotnet host, CoreCLR libraries, input bytes, plan and driver:

    python run_comparison.py freeze --baseline-binary /absolute/path/to/mvs.dll --candidate-binary /absolute/path/to/mvs.dll

The optional binary flags default to each source tree's Release/net8.0/mvs.dll. Binding is exclusive-create and cannot silently change. Source manifests include all production .cs/.csproj/.props/.targets outside generated/test/history directories. The driver rechecks binding before and after each invocation.

Only after the parent approves the exclusive measurement window:

    python run_comparison.py run --approved-exclusive-window

Execution refuses to reuse an existing evidence directory. Verification never starts a model:

    python run_comparison.py verify

## Reporting and interpretation

The report includes all 30 measurements, every build's median/minimum/maximum, every paired B/A ratio and ratio median/minimum/maximum for wall, user/system/total CPU and peak RSS. There is no speed threshold, cherry-picking, significance claim, or conclusion based on a best run. Three pairs are descriptive only. Failures and incomplete evidence cannot be reported as completed parity.

The separate before/after export-error reproducer is intentionally outside this timing comparison. Existing scientific NO-GO remains in force.
