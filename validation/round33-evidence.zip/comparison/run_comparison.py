#!/usr/bin/env python3
"""Frozen Round33 actual-CLI matched comparison; no model runs on import.

freeze: bind a finished driver, sources, binaries, runtime and inputs.
run: execute exactly 30 prescribed processes, retaining every attempt.
verify: recompute output parity/report from retained runs, no model rerun.
self-test: pure normalization/accounting helper tests, no CLI execution.
"""
from __future__ import annotations
import argparse
import csv
import decimal
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import platform
import re
import shutil
import signal
import statistics
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
PLAN = HERE / 'round33-plan.json'
BINDING = HERE / 'binding.json'
METRICS = ('wallSeconds', 'cpuUserSeconds', 'cpuSystemSeconds', 'cpuTotalSeconds', 'peakRssKiB')


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def sha(path):
    return digest(Path(path).read_bytes())


def dump_new(path, data):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(data, stream, indent=2, allow_nan=False, default=lambda x: float(x) if isinstance(x, decimal.Decimal) else (_ for _ in ()).throw(TypeError(type(x).__name__)))
        stream.write('\n')


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def strict_json(raw):
    if isinstance(raw, bytes):
        raw = raw.decode('utf-8-sig')
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, f'Duplicate JSON key: {key}')
            result[key] = value
        return result
    def invalid(value):
        raise ValueError(f'Nonfinite JSON token: {value}')
    return json.loads(raw, object_pairs_hook=pairs, parse_float=decimal.Decimal, parse_constant=invalid)


def read_json(path):
    return strict_json(Path(path).read_bytes())


def token_spans(raw):
    """JSON pointer -> (start,end,value) without rewriting number/string tokens."""
    text = raw.decode('utf-8')
    prefix = 1 if text.startswith('\ufeff') else 0
    strict_json(raw)
    decoder = json.JSONDecoder(parse_float=decimal.Decimal)
    spans = {}
    def ws(pos):
        while pos < len(text) and text[pos] in ' \r\n\t':
            pos += 1
        return pos
    def pointer(parent, child):
        return parent + '/' + str(child).replace('~', '~0').replace('/', '~1')
    def parse(pos, path):
        pos = ws(pos)
        start = pos
        if text[pos] == '{':
            value = {}
            pos = ws(pos + 1)
            if text[pos] != '}':
                while True:
                    key, pos = decoder.raw_decode(text, pos)
                    require(isinstance(key, str), 'Non-string JSON key')
                    pos = ws(pos)
                    require(text[pos] == ':', 'Expected JSON colon')
                    child, pos = parse(pos + 1, pointer(path, key))
                    value[key] = child
                    pos = ws(pos)
                    if text[pos] == '}':
                        break
                    require(text[pos] == ',', 'Expected JSON comma')
                    pos = ws(pos + 1)
            pos += 1
        elif text[pos] == '[':
            value = []
            pos = ws(pos + 1)
            if text[pos] != ']':
                while True:
                    child, pos = parse(pos, pointer(path, len(value)))
                    value.append(child)
                    pos = ws(pos)
                    if text[pos] == ']':
                        break
                    require(text[pos] == ',', 'Expected JSON array comma')
                    pos = ws(pos + 1)
            pos += 1
        else:
            value, pos = decoder.raw_decode(text, pos)
        spans[path] = (start, pos, value)
        return value, pos
    _, end = parse(prefix, '')
    require(ws(end) == len(text), 'Trailing JSON data')
    return text, spans


def replace_tokens(raw, replacements):
    text, spans = token_spans(raw)
    edits = []
    for path, value in replacements.items():
        require(path in spans, f'Missing normalized metadata pointer: {path}')
        start, end, old = spans[path]
        edits.append((start, end, json.dumps(value, ensure_ascii=True, allow_nan=False, separators=(',', ':'))))
    edits.sort(reverse=True)
    previous = len(text) + 1
    for start, end, value in edits:
        require(end <= previous, 'Overlapping token replacements')
        text = text[:start] + value + text[end:]
        previous = start
    return text.encode('utf-8')


def date_value(value, location):
    require(isinstance(value, str) and bool(value), f'Missing timestamp: {location}')
    stamp = datetime.fromisoformat(value.replace('Z', '+00:00'))
    require(stamp.tzinfo is not None, f'Naive timestamp: {location}')


def record_file(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), f'Not regular file: {path}')
    return {'sizeBytes': path.stat().st_size, 'sha256': sha(path)}


def source_manifest(root):
    """Bind exact production project/source files, excluding generated builds/tests."""
    root = Path(root)
    paths = set()
    for path in root.rglob('*'):
        relative = path.relative_to(root)
        if any(x in {'bin', 'obj', '.git', '__pycache__', 'validation', 'benchmark_history'} or x.endswith('.Tests') for x in relative.parts):
            continue
        if path.is_file() and path.suffix.lower() in {'.cs', '.csproj', '.props', '.targets'}:
            paths.add(path)
    require(paths, 'No production sources found')
    return {str(p.relative_to(root)): record_file(p) for p in sorted(paths)}


def binary_manifest(directory):
    directory = Path(directory)
    return {str(p.relative_to(directory)): record_file(p) for p in sorted(directory.rglob('*')) if p.is_file()}


def allowed_environment(dotnet):
    return {'PATH': str(Path(dotnet).parent) + ':/usr/bin:/bin', 'DOTNET_ROOT': str(Path(dotnet).parent),
            **read_json(PLAN)['execution']['environment']}


def check_inputs(plan):
    for item in plan['inputs']:
        path = HERE / 'inputs' / item['name']
        require(record_file(path) == {k: item[k] for k in ('sizeBytes', 'sha256')}, 'Input identity changed: ' + item['name'])
        rows = list(csv.DictReader(io.StringIO(path.read_text())))
        require(len(rows) == item['rows'] and len({x['entity'] for x in rows}) == item['entities'], 'Input shape differs')


def freeze(args):
    require(sys.platform == 'linux' and hasattr(os, 'wait4'), 'Linux wait4 is required')
    plan = read_json(PLAN)
    check_inputs(plan)
    dotnet = Path(args.dotnet).resolve()
    require(dotnet.is_file(), 'Missing dotnet host')
    cpus = sorted(os.sched_getaffinity(0))[:2]
    require(len(cpus) == 2, 'Two CPUs are required')
    runtime = dotnet.parent / 'shared/Microsoft.NETCore.App'
    libraries = sorted(runtime.glob('*/libcoreclr.so'))
    require(libraries, 'Missing installed CoreCLR')
    builds = {}
    for label, source, supplied in [('A', plan['baselineSource'], args.baseline_binary), ('B', plan['candidateSource'], args.candidate_binary)]:
        binary = Path(supplied).resolve() if supplied else Path(source) / 'MvsAnalyzer.Cli/bin/Release/net8.0/mvs.dll'
        require(binary.name == 'mvs.dll' and binary.is_file(), f'Missing CLI binary {label}')
        builds[label] = {'sourceRoot': source, 'sourceFiles': source_manifest(source),
                         'binaryDirectory': str(binary.parent), 'binaryFiles': binary_manifest(binary.parent), 'entrypoint': str(binary)}
    binding = {'schema':'mvs-round33-binding/v1', 'boundUtc': now(), 'planSha256': sha(PLAN),
               'driverSha256': sha(__file__), 'inputFiles': {i['name']: record_file(HERE/'inputs'/i['name']) for i in plan['inputs']},
               'builds': builds, 'dotnetHost': {'path': str(dotnet), **record_file(dotnet)},
               'coreclrFiles': {str(p): record_file(p) for p in libraries}, 'cpuAffinity': cpus,
               'baseEnvironment': allowed_environment(dotnet), 'platform': platform.platform(),
               'python': sys.version, 'pythonExecutable': sys.executable,
               'sourceSelection':'All production .cs/.csproj/.props/.targets excluding bin, obj, .git, __pycache__, validation, benchmark_history and .Tests directories.'}
    dump_new(BINDING, binding)
    print('Frozen binding:', BINDING, sha(BINDING), flush=True)


def check_binding(binding):
    require(sha(PLAN) == binding['planSha256'], 'Frozen plan changed')
    require(sha(__file__) == binding['driverSha256'], 'Frozen driver changed')
    check_inputs(read_json(PLAN))
    require(set(binding['cpuAffinity']).issubset(os.sched_getaffinity(0)), 'Frozen CPUs unavailable')
    host = binding['dotnetHost']
    require(record_file(host['path']) == {k: host[k] for k in ('sizeBytes','sha256')}, 'dotnet host changed')
    for path, item in binding['coreclrFiles'].items():
        require(record_file(path) == item, 'CoreCLR changed')
    for label, build in binding['builds'].items():
        require(source_manifest(build['sourceRoot']) == build['sourceFiles'], f'Sources changed: {label}')
        require(binary_manifest(build['binaryDirectory']) == build['binaryFiles'], f'Binary changed: {label}')


def environment(binding, folder):
    env = dict(binding['baseEnvironment'])
    for key, sub in [('HOME','home'), ('TMPDIR','tmp'), ('MVS_APPDATA_ROOT','appdata')]:
        directory = folder / sub
        directory.mkdir()
        env[key] = str(directory)
    return env


def execute(command, directory, env, cpus, timeout, rss_limit):
    start = time.perf_counter()
    events = []
    sampled_rss = 0
    runtime_paths = set()
    forced = False
    def setup():
        os.sched_setaffinity(0, set(cpus))
    with (directory/'stdout.json').open('xb') as stdout, (directory/'stderr.log').open('xb') as stderr:
        process = subprocess.Popen(command, stdout=stdout, stderr=stderr, cwd=directory, env=env,
                                   start_new_session=True, preexec_fn=setup)
        while True:
            pid, status, usage = os.wait4(process.pid, os.WNOHANG)
            elapsed = time.perf_counter() - start
            if pid:
                code = os.waitstatus_to_exitcode(status)
                process.returncode = code  # wait4 owns the reap; avoid Popen's second wait.
                break
            violation = None
            try:
                affinity = sorted(os.sched_getaffinity(process.pid))
                if affinity != cpus:
                    violation = 'affinity_changed'
                status_text = Path(f'/proc/{process.pid}/status').read_text()
                found = re.search(r'^VmRSS:\s+(\d+) kB', status_text, re.M)
                rss = int(found.group(1)) if found else 0
                sampled_rss = max(sampled_rss, rss)
                if rss > rss_limit * 1024:
                    violation = 'rss_limit'
                for line in Path(f'/proc/{process.pid}/maps').read_text().splitlines():
                    if line.endswith('/libcoreclr.so'):
                        runtime_paths.add(line.split()[-1])
            except (FileNotFoundError, ProcessLookupError):
                pass
            if elapsed >= timeout:
                violation = 'timeout'
            if violation and not forced:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                    forced = True
                    events.append({'type':violation,'elapsedSeconds':elapsed,'signal':'SIGKILL'})
                except ProcessLookupError:
                    pass
            time.sleep(0.05)
    return {'pid':process.pid, 'returncode':code, 'wallSeconds':elapsed,
            'cpuUserSeconds':usage.ru_utime, 'cpuSystemSeconds':usage.ru_stime,
            'cpuTotalSeconds':usage.ru_utime + usage.ru_stime, 'peakRssKiB':usage.ru_maxrss,
            'sampledPeakRssKiB':sampled_rss, 'minorFaults':usage.ru_minflt,'majorFaults':usage.ru_majflt,
            'coreclrPaths':sorted(runtime_paths), 'events':events, 'forcedKill':forced}


def verify_artifact(path, size, checksum):
    actual = record_file(path)
    require(actual['sizeBytes'] == size, f'Artifact size mismatch: {path}')
    require(isinstance(checksum, str) and re.fullmatch('[0-9a-f]{64}', checksum) is not None, f'Malformed hash: {path}')
    require(actual['sha256'] == checksum, f'Artifact checksum mismatch: {path}')
    return actual


def canonical_state(raw):
    state = strict_json(raw)
    date_value(state['CreatedUtc'], 'calibration.CreatedUtc')
    unsigned = replace_tokens(raw, {'/PayloadHash':''})
    require(digest(unsigned) == state['PayloadHash'], 'Calibration raw payload checksum mismatch')
    normalized_unsigned = replace_tokens(raw, {'/CreatedUtc':'<timestamp>', '/PayloadHash':''})
    return replace_tokens(normalized_unsigned, {'/PayloadHash':digest(normalized_unsigned)})


def inspect_run(folder, workload, frozen_state=None):
    record = read_json(folder/'record.json')
    require(record['returncode'] in workload['expectedExit'], f'Unexpected process exit: {record["returncode"]}')
    require(not record['forcedKill'] and not record['events'], 'Watchdog violation')
    raw = (folder/'stdout.json').read_bytes()
    payload = strict_json(raw)
    require(payload['schemaVersion'] == 'mvs-cli-result/v1', 'Machine schema differs')
    require(payload['command'] == workload['id'], 'Machine command differs')
    require(payload['exitCode'] == record['returncode'], 'Machine/process exits differ')
    require(payload['status'] == {0:'completed',2:'diagnostic'}[record['returncode']], 'Machine status differs')
    require(payload['execution']['completed'] is True and payload['error'] is None, 'Run not complete')
    require(payload['engineVersion'] == '1.6.2' and payload['scientificReadiness']['status'] == 'no_go', 'Scientific identity/readiness differs')
    output = Path(payload['outputDirectory']).resolve()
    requested = (folder/'output').resolve()
    require(output == requested or output.is_relative_to(requested), 'Output escaped its invocation')
    require(output.is_dir() and not output.is_symlink(), 'Output directory missing')
    actual_files = {p.name:p for p in output.iterdir() if p.is_file()}
    require(len(actual_files) == len(list(output.iterdir())), 'Unexpected non-file output')
    require(set(actual_files) == set(workload['artifacts']), f'Output file set differs: {sorted(actual_files)}')
    artifacts = payload['artifacts']
    require(len(artifacts) == len(actual_files), 'Machine artifact count differs')
    names = [a['name'] for a in artifacts]
    require(len(set(names)) == len(names) and set(names) == set(actual_files), 'Machine artifact identity differs')
    identities = {}
    for artifact in artifacts:
        name = artifact['name']
        path = Path(artifact['path'])
        require(path.is_absolute() and path.resolve() == actual_files[name].resolve(), 'Machine artifact path differs')
        identities[name] = verify_artifact(path, artifact['sizeBytes'], artifact['sha256'])
    normalized = {}
    for name, path in actual_files.items():
        if name == 'run_manifest.json':
            continue
        content = path.read_bytes()
        if name == 'calibration_state.json':
            if workload['id'] == 'analyze':
                require(content == frozen_state.read_bytes(), 'Analysis did not copy frozen baseline calibration exactly')
            content = canonical_state(content)
        elif name.endswith('.json'):
            strict_json(content)
        elif name.endswith('.csv'):
            list(csv.reader(io.StringIO(content.decode('utf-8-sig'))))
        normalized[name] = content
    if 'run_manifest.json' in actual_files:
        manifest_path = actual_files['run_manifest.json']
        require(Path(payload['manifestPath']).resolve() == manifest_path.resolve(), 'Machine manifest association differs')
        manifest_raw = manifest_path.read_bytes()
        manifest = strict_json(manifest_raw)
        date_value(manifest['created'], 'manifest.created')
        require(isinstance(manifest['runId'], str) and manifest['runId'], 'Missing manifest runId')
        require(payload['runId'] == manifest['runId'], 'Manifest/machine runIds differ')
        files = manifest['files']
        file_names = [f['FileName'] for f in files]
        require(len(set(file_names)) == len(files) and set(file_names) == set(actual_files)-{'run_manifest.json'}, 'Manifest artifact association differs')
        changes = {'/created':'<timestamp>', '/runId':'<run-id>'}
        for index, item in enumerate(files):
            name = item['FileName']
            verify_artifact(actual_files[name], item['SizeBytes'], item['sha256'])
            changes[f'/files/{index}/sha256'] = digest(normalized[name])
            changes[f'/files/{index}/SizeBytes'] = len(normalized[name])
        normalized['run_manifest.json'] = replace_tokens(manifest_raw, changes)
        if workload['id'] != 'estimation':
            input_arg = workload['arguments'][workload['arguments'].index('--in')+1]
            input_file = HERE/'inputs'/Path(input_arg).name
            require(manifest['inputData']['sha256'] == sha(input_file), 'Manifest input hash differs')
        if workload['id'] == 'analyze':
            require(manifest['decision']['familySize'] == 12, 'Full metric registry size differs')
            require(manifest['calibrationInput']['sha256'] == sha(HERE/'inputs/summary_fixture.csv'), 'Calibration input identity differs')
    else:
        require(payload['manifestPath'] is None and payload['runId'] is None, 'Calibration invented manifest/runId')
    changes = {'/outputDirectory':'<output>', '/manifestPath':'<output>/run_manifest.json' if payload['manifestPath'] else None,
               '/runId':'<run-id>' if payload['runId'] else None}
    for index, artifact in enumerate(artifacts):
        name = artifact['name']
        changes[f'/artifacts/{index}/path'] = '<output>/' + name
        changes[f'/artifacts/{index}/sha256'] = digest(normalized[name])
        changes[f'/artifacts/{index}/sizeBytes'] = len(normalized[name])
    normalized['stdout.json'] = replace_tokens(raw, changes)
    return {'record':record, 'artifacts':identities, 'normalized':normalized, 'output':str(output), 'status':payload['status']}


def execute_all(args):
    require(args.approved_exclusive_window, 'Explicit --approved-exclusive-window required after parent approval')
    binding = read_json(BINDING)
    check_binding(binding)
    plan = read_json(PLAN)
    destination = HERE/'execution'
    destination.mkdir(exist_ok=False)
    shutil.copyfile(BINDING, destination/'binding.json')
    shutil.copyfile(PLAN, destination/'plan.json')
    (destination/'host-before.txt').write_text(platform.platform()+'\n'+Path('/proc/loadavg').read_text()+Path('/proc/cpuinfo').read_text())
    dump_new(destination/'started.json', {'startedUtc':now(), 'bindingSha256':sha(BINDING), 'driverSha256':sha(__file__)})
    frozen_dir = HERE/'frozen-calibration'
    frozen_dir.mkdir(exist_ok=False)
    state = frozen_dir/'calibration_state.json'
    records=[]
    for workload in plan['workloads']:
        for pair, order in enumerate(plan['execution']['pairOrder'], start=1):
            for position, label in enumerate(order, start=1):
                check_binding(binding)
                if workload['id'] == 'analyze':
                    require(state.is_file(), 'Frozen baseline calibration unavailable; analysis blocked')
                    require(record_file(state) == read_json(frozen_dir/'identity.json')['file'], 'Frozen baseline calibration changed')
                name = f'{workload["id"]}-pair{pair}-{position}-{label}'
                folder = destination/name
                folder.mkdir()
                env = environment(binding, folder)
                args_ = [x.replace('{inputs}',str(HERE/'inputs')).replace('{output}',str(folder/'output')).replace('{frozen_calibration}',str(state)) for x in workload['arguments']]
                command=[binding['dotnetHost']['path'],binding['builds'][label]['entrypoint'],*args_]
                context={'id':name,'workload':workload['id'],'pair':pair,'position':position,'build':label,
                         'command':command,'environment':env,'cpuAffinity':binding['cpuAffinity'],'startedUtc':now()}
                dump_new(folder/'invocation.json',context)
                print('RUN',name,flush=True)
                result=execute(command,folder,env,binding['cpuAffinity'],workload['timeoutSeconds'],plan['execution']['rssLimitMiB'])
                result={**context,**result,'finishedUtc':now(),'stdout':record_file(folder/'stdout.json'),'stderr':record_file(folder/'stderr.log')}
                require(set(result['coreclrPaths']).issubset(binding['coreclrFiles']), 'Unexpected runtime loaded')
                dump_new(folder/'record.json',result)
                records.append(result)
                with (destination/'invocations.jsonl').open('a') as stream:
                    stream.write(json.dumps(result,allow_nan=False)+'\n')
                if workload['id']=='calibrate' and pair==1 and label=='A':
                    checked=inspect_run(folder,workload)
                    shutil.copyfile(Path(checked['output'])/'calibration_state.json',state)
                    dump_new(frozen_dir/'identity.json',{'copiedFrom':name,'frozenUtc':now(),'file':record_file(state)})
                check_binding(binding)
    dump_new(destination/'finished.json',{'finishedUtc':now(),'invocations':len(records),'bindingUnchanged':True})
    (destination/'host-after.txt').write_text(platform.platform()+'\n'+Path('/proc/loadavg').read_text())
    return verify(args)


def summary(values):
    return {'values':values,'median':statistics.median(values),'min':min(values),'max':max(values)}


def verify(args):
    plan=read_json(PLAN)
    binding=read_json(BINDING)
    check_binding(binding)
    destination=HERE/'execution'
    require((destination/'finished.json').exists(),'Execution incomplete; retained evidence is not a completed 30-run comparison')
    state=HERE/'frozen-calibration/calibration_state.json'
    require(record_file(state)==read_json(state.parent/'identity.json')['file'],'Frozen calibration identity differs')
    reports=[]
    errors=[]
    all_records=[]
    for workload in plan['workloads']:
        inspected=[]
        workload_errors=[]
        for pair,order in enumerate(plan['execution']['pairOrder'],start=1):
            for position,label in enumerate(order,start=1):
                name=f'{workload["id"]}-pair{pair}-{position}-{label}'
                folder=destination/name
                try:
                    result=inspect_run(folder,workload,state)
                    for filename,key in [('stdout.json','stdout'),('stderr.log','stderr')]:
                        require(record_file(folder/filename)==result['record'][key],f'Raw capture changed: {name}/{filename}')
                    normalized_dir=folder/'normalized'
                    if not normalized_dir.exists():
                        normalized_dir.mkdir()
                        for filename,content in result['normalized'].items():
                            (normalized_dir/filename).write_bytes(content)
                    else:
                        require({p.name:p.read_bytes() for p in normalized_dir.iterdir()}==result['normalized'],'Saved normalization differs')
                    inspected.append(result)
                except Exception as exc:
                    workload_errors.append({'invocation':name,'error':str(exc)})
                all_records.append(read_json(folder/'record.json'))
        comparisons=[]
        if len(inspected)==6:
            first=inspected[0]
            for item in inspected[1:]:
                differences=[name for name in first['normalized'] if first['normalized'][name]!=item['normalized'][name]]
                same_exit=first['record']['returncode']==item['record']['returncode']
                comparisons.append({'reference':first['record']['id'],'actual':item['record']['id'],'exactNormalizedBytesEqual':not differences,'differentFiles':differences,'statusExitEqual':same_exit and first['status']==item['status']})
                if differences or not same_exit:
                    workload_errors.append({'invocation':item['record']['id'],'error':'Exact parity mismatch','differentFiles':differences})
        runs=[r for r in all_records if r['workload']==workload['id']]
        performance={}
        for metric in METRICS:
            a=[float(r[metric]) for r in runs if r['build']=='A']
            b=[float(r[metric]) for r in runs if r['build']=='B']
            ratios=[bb/aa if aa else None for aa,bb in zip(a,b)]
            performance[metric]={'A':summary(a),'B':summary(b),'pairedBOverA':summary(ratios) if all(r is not None for r in ratios) else {'values':ratios,'note':'Ratio undefined for zero baseline'},'medianBOverMedianA':statistics.median(b)/statistics.median(a) if statistics.median(a) else None}
        reports.append({'workload':workload['id'],'passed':not workload_errors and len(inspected)==6,'invocations':len(runs),'comparisons':comparisons,'errors':workload_errors,'performance':performance,'artifacts':[{'invocation':r['record']['id'],'actual':r['artifacts'],'normalized':{name:{'sha256':digest(content),'sizeBytes':len(content)} for name,content in r['normalized'].items()}} for r in inspected]})
        errors.extend(workload_errors)
    require(len(all_records)==30,'Run count differs')
    report={'schema':'mvs-round33-output-comparison/v1','verifiedUtc':now(),'planSha256':sha(PLAN),'bindingSha256':sha(BINDING),'driverSha256':sha(__file__),'scientificReleaseDecision':'NO-GO retained','scope':plan['scope'],'invocationCount':len(all_records),'passed':not errors and all(r['passed'] for r in reports),'workloads':reports,'allRawMeasurements':all_records,'errors':errors,'limitations':plan['performance']['limitations']}
    target=destination/'comparison-results.json'
    if target.exists():
        original=read_json(target)
        original.pop('verifiedUtc',None)
        current=strict_json(json.dumps(report,default=float))
        current.pop('verifiedUtc',None)
        require(original==current,'Recomputed comparison differs from saved report')
    else:
        dump_new(target,report)
    lines=['Round33 matched CLI export comparison',f'Exact output/status parity: {report["passed"]}; retained invocations: {len(all_records)}/30.','Three matched pairs per workload, AB/BA/AB; ratios are candidate/baseline. Descriptive cost only.','']
    for w in reports:
        lines.append(w['workload']+': parity '+str(w['passed']))
        for metric,result in w['performance'].items():
            a,b,r=result['A'],result['B'],result['pairedBOverA']
            lines.append(f'  {metric}: A median {a["median"]:.6g} [{a["min"]:.6g}, {a["max"]:.6g}]; B median {b["median"]:.6g} [{b["min"]:.6g}, {b["max"]:.6g}]; paired B/A {r}')
    lines.extend(['','No scientific correctness, publication readiness, or speed significance claim. Existing NO-GO remains.'])
    summary_path=destination/'comparison-summary.txt'
    text='\n'.join(lines)+'\n'
    if summary_path.exists():
        require(summary_path.read_text()==text,'Saved text summary differs')
    else:
        summary_path.write_text(text)
    manifest={str(p.relative_to(HERE)):record_file(p) for p in sorted(HERE.rglob('*')) if p.is_file() and p.name not in {'evidence-sha256.json'} and '__pycache__' not in p.parts}
    evidence=HERE/'evidence-sha256.json'
    if evidence.exists():
        require(read_json(evidence)==manifest,'Evidence inventory differs')
    else:
        dump_new(evidence,manifest)
    print(json.dumps({'passed':report['passed'],'invocations':len(all_records),'report':str(target),'errors':errors}),flush=True)
    return 0 if report['passed'] else 2


def self_test(args):
    raw=b'{\n  "CreatedUtc": "2026-10-16T00:00:00Z",\n  "x": [1.00, 1e-20, null, "a\\u0027b"],\n  "PayloadHash": ""\n}'
    signed=replace_tokens(raw,{'/PayloadHash':digest(raw)})
    second=replace_tokens(raw,{'/CreatedUtc':'2026-10-17T00:00:00Z'})
    second=replace_tokens(second,{'/PayloadHash':digest(second)})
    require(canonical_state(signed)==canonical_state(second),'Timestamp canonicalization failed')
    changed=replace_tokens(raw,{'/x/0':1})
    changed=replace_tokens(changed,{'/PayloadHash':digest(changed)})
    require(canonical_state(signed)!=canonical_state(changed),'Numeric lexeme change was hidden')
    require(replace_tokens(raw,{'/CreatedUtc':'X'}).count(b'1.00')==1,'Numeric byte spelling was changed')
    for invalid in [b'{"x":1,"x":2}',b'{"x":NaN}',b'{"x":Infinity}']:
        try:
            strict_json(invalid)
        except (ValueError,AssertionError):
            pass
        else:
            raise AssertionError('Invalid JSON accepted')
    require(summary([3,1,2])=={'values':[3,1,2],'median':2,'min':1,'max':3},'Summary arithmetic failed')
    check_inputs(read_json(PLAN))
    print('PASS pure normalization, numerical-lexeme sensitivity, strict JSON, summary and frozen-input tests; no CLI process launched.')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    subs=parser.add_subparsers(dest='mode',required=True)
    p=subs.add_parser('freeze')
    p.add_argument('--dotnet',default='/workspace/scratch/8105054a3211/mvs_r22_baseline/sdk/dotnet')
    p.add_argument('--baseline-binary')
    p.add_argument('--candidate-binary')
    p.set_defaults(func=freeze)
    p=subs.add_parser('run')
    p.add_argument('--approved-exclusive-window',action='store_true')
    p.set_defaults(func=execute_all)
    subs.add_parser('verify').set_defaults(func=verify)
    subs.add_parser('self-test').set_defaults(func=self_test)
    args=parser.parse_args()
    return args.func(args) or 0

if __name__=='__main__':
    raise SystemExit(main())
