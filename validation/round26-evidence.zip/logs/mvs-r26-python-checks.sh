set -eu
source /workspace/scratch/8105054a3211/mvs_r22_baseline/env.sh
cd /workspace/scratch/8105054a3211/mvs_round26/MVS-analyzer-main
export PYTHONPATH="$PWD/python/src"
export MVS_MCP_TEST_ENGINE="$PWD/MvsAnalyzer.Cli/bin/Release/net8.0/mvs"
export MVS_MCP_TEST_DATA="$PWD/examples/demo_three_groups.csv"
export MVS_MCP_TEST_CALIBRATION=/workspace/scratch/8105054a3211/mvs_r22_baseline/artifacts/calibration/calibration_state.json
PY=/workspace/scratch/8105054a3211/mvs_mcp_venv/bin/python
$PY -m unittest discover -s python/tests -v
$PY tools/test_backups.py
$PY tools/test_source.py
$PY tools/test_paper_benchmark.py
$PY tools/test_paper_benchmark_runner.py
$PY tools/test_release_bundle.py
$PY tools/test_round2.py
python -m unittest discover -s validation -p 'test_*.py' -v
