# Independent Kendall tau-b mathematical oracle

## Result

All 66,420 ordered array pairs over {0,1,2}, lengths 2–5, passed independent exact pair classification and a secondary SciPy statistic crosscheck. There were 64,296 defined and 2,124 undefined outcomes, zero crosscheck mismatches, and 199,260 successful metamorphic checks (swap inputs, reverse shared index order, negate the second input). These are bounded arithmetic tests, not scientific samples or evidence about benchmark performance.

Twenty-five explicit fixtures cover joint and exclusive ties, mixed concordance/discordance, zero tau, constants, signed zeros, invalid lengths, NaN, infinity, maximal finite values, subnormals, and reversal. Exact expected outputs reside in fixtures.expected.json, with binary64 inputs encoded as hexadecimal strings to preserve signed zero and subnormals. All finite-domain fixture statistics agree with the secondary reference within relative 1e-14 / absolute 1e-15 tolerance.

## Frozen specification and independence

The oracle classifies each unordered pair using direct value ordering, retaining C, D, ties only in A, ties only in B, and joint ties separately. Its exact result is signed integer numerator C−D and integer denominator squared (C+D+TA)(C+D+TB), supplemented by reduced rational tau². Joint ties do not enter either factor. A zero factor is undefined. Both input arrays must be finite, equally long, and contain at least two entries. NaN/infinity are rejected rather than deleted.

The oracle, specification, 25 explicit fixtures, and canonical exhaustive expected-results digest were frozen before any candidate implementation was evaluated. freeze.manifest.json records the original SHA-256 hashes; verification rechecked them without modification. No candidate source was imported or evaluated by this work. The legacy BenchmarkMath.cs was read to identify the requested regression surface; production files were never modified.

Key exact expectations:
- [1,1,2] against itself: C=2, J=1, denominator²=4, tau=1.
- [0,0,1] against [0,1,2]: C=2, TA=1, denominator²=6, tau²=2/3.
- [0,0,1,1] against [0,0,0,1]: C=2, TA=1, TB=2, J=1, denominator²=12, tau²=1/3.
- Any constant ranking: undefined, including identical constant arrays and signed-zero-only arrays.
- [-MaxValue,0,MaxValue] against itself and [0,minSubnormal,2*minSubnormal] against itself: tau=1; reversed partners: tau=−1.

## Secondary reference and its limitations

Python 3.12.14; SciPy 1.17.0, scipy.stats.kendalltau, variant='b', method='asymptotic', nan_policy='propagate', alternative='two-sided'. No package installations or dependency changes were made.

SciPy's asymptotic p-value calculation raises ZeroDivisionError for nonconstant length-two inputs. The original frozen verify command therefore records that failure; the separate run_crosscheck.py adapter retries only these secondary calls with method='exact'. It logs all 38 fallbacks: 36 exhaustive cases and two infinity fixtures. The mathematical oracle and frozen expectations were not changed. P-values were not used as evidence.

SciPy can rank positive/negative infinity and returns tau=1 for the two one-infinite-input fixtures. This deliberately differs from the finite-only MVS contract; it is not an oracle failure. SciPy propagates NaN. It returned correct statistics for all tested extreme-finite and subnormal cases. No broader guarantee about untested floating-point inputs follows from those checks. SciPy produces tiny rounding differences (e.g. 0.9999999999999999 for identical tied rankings), so exact rational evidence is primary.

## Reproduction and artifacts

Run: python /workspace/scratch/8105054a3211/mvs-r42-oracle/run_crosscheck.py

- oracle.py: frozen standalone exact-count specification, fixtures, exhaustive generator and tests
- spec.json: frozen machine-readable contract/settings
- fixtures.expected.json: frozen exact expected fixture outputs
- exhaustive.expected.sha256: frozen canonical exhaustive-output digest
- freeze.manifest.json: hashes proving frozen artifacts unchanged
- run_crosscheck.py: isolated SciPy length-two workaround
- verification.report.json: full fixture/reference outputs, totals, settings, and logged fallbacks
- verify.stdout.txt / verify.stderr.txt: captured run output; small-sample warnings are expected for explicit empty/singleton fixtures

All artifacts are outside the production project under /workspace/scratch/8105054a3211/mvs-r42-oracle. No scientific data, external-service actions, production dependencies, or production edits were introduced.
