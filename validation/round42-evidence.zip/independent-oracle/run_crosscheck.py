#!/usr/bin/env python3
"""Secondary SciPy adapter; frozen mathematical oracle/spec remain unmodified.
SciPy 1.17.0 asymptotic p-value calculation raises ZeroDivisionError for
nonconstant length-two arrays. Retry only that secondary call with method=exact.
"""
import json, sys
import scipy.stats
import oracle
original = scipy.stats.kendalltau
fallbacks=[]
def secondary(a,b,**kwargs):
 try: return original(a,b,**kwargs)
 except ZeroDivisionError:
  if len(a)!=2 or len(b)!=2: raise
  fallbacks.append({'a_hex':oracle.encode(a),'b_hex':oracle.encode(b),'from':'asymptotic','to':'exact','reason':'SciPy asymptotic p-value zero division at length 2'})
  return original(a,b,**dict(kwargs,method='exact'))
scipy.stats.kendalltau=secondary
sys.argv=['oracle.py','verify']
oracle.main()
p=oracle.ROOT/'verification.report.json'
r=json.loads(p.read_text()); r['scipy_length_two_fallbacks']=fallbacks
r['secondary_adapter']='run_crosscheck.py; frozen oracle script and fixture/spec hashes unchanged'
p.write_text(oracle.canonical(r))
print('Secondary length-two fallbacks:',len(fallbacks))
