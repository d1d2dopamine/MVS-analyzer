#!/usr/bin/env python3
"""Independent exact-count Kendall tau-b oracle. No project imports or mutations.
Freeze mode writes fixtures/spec before candidate evaluation. Verify mode is read-only
on frozen expected files and writes only a separate crosscheck report.
"""
import argparse, hashlib, itertools, json, math, pathlib, sys
from fractions import Fraction
ROOT = pathlib.Path(__file__).resolve().parent
SPEC = {
 'version': 1,
 'domain': 'Equal-length finite IEEE-754 binary64 arrays, length >= 2; reject any NaN/infinity. Signed zero values compare equal.',
 'classification': 'For each unordered index pair compare values directly (no subtraction or multiplication); count concordance C, discordance D, ties only in A TA, ties only in B TB, and joint ties J separately.',
 'formula': '(C-D)/sqrt((C+D+TA)*(C+D+TB)); joint ties excluded from both factors. Zero denominator means undefined (NaN).',
 'exact_representation': 'Signed numerator integer and denominator_squared integer; reduced rational tau_squared plus sign. Floating tau is presentation only.',
 'invalid': 'Length mismatch, length less than two, any nonfinite input, or zero denominator is undefined. No pairwise deletion.',
 'exhaustive': {'alphabet': [0,1,2], 'lengths': [2,3,4,5], 'ordered_array_pairs': 66420},
 'metamorphic': ['swap A/B preserves tau', 'reverse index order in both preserves tau', 'negate B reverses tau sign'],
 'scipy_secondary': {'variant':'b', 'method':'asymptotic', 'nan_policy':'propagate', 'alternative':'two-sided'},
 'comparison_tolerance': {'relative': 1e-14, 'absolute': 1e-15},
 'scope': 'Arithmetic fixtures only. No scientific data generation or scientific conclusions. No candidate implementation imported or evaluated.'
}
M = sys.float_info.max
S = float.fromhex('0x0.0000000000001p-1022')
FIXTURES = [
 ('identical_joint_ties',[1,1,2],[1,1,2]),
 ('reversed_joint_ties',[1,1,2],[2,2,1]),
 ('one_sided_a',[0,0,1],[0,1,2]),
 ('one_sided_b',[0,1,2],[0,0,1]),
 ('joint_and_exclusive',[0,0,1,1],[0,0,0,1]),
 ('mixed_concordant_discordant',[0,1,2,3],[0,2,1,3]),
 ('balanced_zero',[0,1,2,3],[1,3,0,2]),
 ('constant_a',[1,1,1],[0,1,2]),
 ('constant_b',[0,1,2],[1,1,1]),
 ('both_constant',[1,1,1],[1,1,1]),
 ('signed_zero_joint',[-0.0,0.0,1],[0.0,-0.0,1]),
 ('signed_zero_constant',[-0.0,0.0],[0.0,-0.0]),
 ('extreme_finite',[-M,0,M],[-M,0,M]),
 ('extreme_finite_reverse',[-M,0,M],[M,0,-M]),
 ('subnormal',[0,S,2*S],[0,S,2*S]),
 ('subnormal_reverse',[0,S,2*S],[2*S,S,0]),
 ('mixed_extreme_subnormal',[-M,0,M],[0,S,2*S]),
 ('nan_a',[float('nan'),1],[0,1]),
 ('nan_b',[0,1],[0,float('nan')]),
 ('positive_infinity',[0,float('inf')],[0,1]),
 ('negative_infinity',[float('-inf'),0],[0,1]),
 ('joint_infinity',[float('inf'),float('inf')],[0,1]),
 ('empty',[],[]), ('singleton',[1],[1]), ('length_mismatch',[0,1],[0,1,2])]
def oracle(a,b):
 if len(a)!=len(b) or len(a)<2 or not all(math.isfinite(x) for x in (*a,*b)):
  return {'status':'undefined','reason':'invalid_input'}
 c=d=ta=tb=j=0
 # Total ordering comparisons are independent of floating subtraction/product.
 for i,k in itertools.combinations(range(len(a)),2):
  sa=(a[i]>a[k])-(a[i]<a[k]); sb=(b[i]>b[k])-(b[i]<b[k])
  if sa==0 and sb==0: j+=1
  elif sa==0: ta+=1
  elif sb==0: tb+=1
  elif sa==sb: c+=1
  else: d+=1
 den=(c+d+ta)*(c+d+tb); num=c-d
 out={'counts':{'C':c,'D':d,'TA':ta,'TB':tb,'J':j},'numerator':num,'denominator_squared':den}
 if not den: return dict(out,status='undefined',reason='zero_denominator')
 rat=Fraction(num*num,den)
 return dict(out,status='defined',sign=(num>0)-(num<0),tau_squared=f'{rat.numerator}/{rat.denominator}',tau=num/math.sqrt(den))
def encode(a): return [float(x).hex() for x in a]
def fixtures(): return [{'name':n,'a_hex':encode(a),'b_hex':encode(b),'expected':oracle(a,b)} for n,a,b in FIXTURES]
def canonical(o): return json.dumps(o,sort_keys=True,indent=2,allow_nan=False)+'\n'
def exhaustive():
 for n in SPEC['exhaustive']['lengths']:
  arrays=list(itertools.product(SPEC['exhaustive']['alphabet'],repeat=n))
  for a,b in itertools.product(arrays,repeat=2): yield a,b

def same(x,y,neg=False):
 if x['status']!=y['status']: return False
 if x['status']=='undefined': return True
 return x['tau_squared']==y['tau_squared'] and x['sign']==((-1 if neg else 1)*y['sign'])
def main():
 p=argparse.ArgumentParser(); p.add_argument('mode',choices=['freeze','verify']); args=p.parse_args()
 if args.mode=='freeze':
  for name,obj in [('spec.json',SPEC),('fixtures.expected.json',fixtures())]:
   with (ROOT/name).open('x') as f: f.write(canonical(obj))
  # Exact exhaustive expectations are frozen as a canonical streaming digest.
  h=hashlib.sha256()
  for a,b in exhaustive(): h.update(canonical({'a':a,'b':b,'expected':oracle(a,b)}).encode())
  (ROOT/'exhaustive.expected.sha256').write_text(h.hexdigest()+'\n')
  hashes={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ['oracle.py','spec.json','fixtures.expected.json','exhaustive.expected.sha256']}
  (ROOT/'freeze.manifest.json').write_text(canonical(hashes)); print(canonical(hashes)); return
 manifest=json.loads((ROOT/'freeze.manifest.json').read_text())
 for n,h in manifest.items(): assert hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h, n+' changed since freeze'
 assert fixtures()==json.loads((ROOT/'fixtures.expected.json').read_text())
 import scipy
 from scipy.stats import kendalltau
 report={'python':sys.version,'scipy':scipy.__version__,'settings':SPEC['scipy_secondary'],'fixture_results':[],'exhaustive_count':0,'exhaustive_defined':0,'exhaustive_undefined':0,'scipy_exhaustive_mismatches':0,'metamorphic_checks':0}
 for n,a,b in FIXTURES:
  if len(a)!=len(b): result='not called: unequal lengths'
  else:
   try:
    z=float(kendalltau(a,b,**SPEC['scipy_secondary']).statistic); result=z if math.isfinite(z) else 'NaN'
   except Exception as e: result=type(e).__name__+': '+str(e)
  expected=oracle(a,b); report['fixture_results'].append({'name':n,'oracle':expected,'scipy_statistic':result})
 h=hashlib.sha256()
 for a,b in exhaustive():
  x=oracle(a,b); h.update(canonical({'a':a,'b':b,'expected':x}).encode())
  assert same(x,oracle(b,a)); assert same(x,oracle(a[::-1],b[::-1])); assert same(x,oracle(a,tuple(-v for v in b)),neg=True)
  report['metamorphic_checks']+=3; report['exhaustive_count']+=1
  z=float(kendalltau(a,b,**SPEC['scipy_secondary']).statistic)
  if x['status']=='undefined': report['exhaustive_undefined']+=1; match=math.isnan(z)
  else: report['exhaustive_defined']+=1; match=math.isclose(z,x['tau'],rel_tol=1e-14,abs_tol=1e-15)
  if not match: report['scipy_exhaustive_mismatches']+=1
 assert h.hexdigest()==(ROOT/'exhaustive.expected.sha256').read_text().strip()
 assert report['scipy_exhaustive_mismatches']==0
 (ROOT/'verification.report.json').write_text(canonical(report)); print(canonical(report))
if __name__=='__main__': main()
