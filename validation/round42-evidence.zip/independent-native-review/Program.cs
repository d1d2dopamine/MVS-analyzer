using System.Reflection;
using System.Text.Json;
using System.Security.Cryptography;
using System.Text;
var asm=Assembly.LoadFrom("/tmp/mvs-r42-native/bin/MvsAnalyzer.Core/release/MvsAnalyzer.Core.dll");
var math=asm.GetType("MvsAnalyzer.Benchmarking.BenchmarkMath")!;
var tau=math.GetMethod("KendallTau")!;
var old=math.GetMethod("LegacyKendallTau")!;
double Call(MethodInfo m,double[] a,double[] b)=>(double)m.Invoke(null,new object[]{a,b})!;
void Near(double x,double y,string label){if(!(double.IsNaN(x)&&double.IsNaN(y))&&!(Math.Abs(x-y)<1e-14))throw new Exception($"{label}: {x} != {y}");}
double Oracle(double[] a,double[] b){if(a.Length!=b.Length||a.Length<2||a.Concat(b).Any(x=>!double.IsFinite(x)))return double.NaN; double n=a.Length*(a.Length-1)/2d,ta=a.GroupBy(x=>x).Sum(g=>g.Count()*(g.Count()-1)/2d),tb=b.GroupBy(x=>x).Sum(g=>g.Count()*(g.Count()-1)/2d),s=0;for(int i=0;i<a.Length;i++)for(int j=i+1;j<a.Length;j++){bool upa=a[i]>a[j],dna=a[i]<a[j],upb=b[i]>b[j],dnb=b[i]<b[j];s+=(upa&&upb||dna&&dnb)?1:(upa&&dnb||dna&&upb)?-1:0;}return (n-ta)*(n-tb)==0?double.NaN:s/Math.Sqrt((n-ta)*(n-tb));}
var vectors=Enumerable.Range(0,243).Select(n=>Enumerable.Range(0,5).Select(i=>(double)(n/(int)Math.Pow(3,i)%3)).ToArray()).ToArray();
int count=0;foreach(var a in vectors)foreach(var b in vectors){Near(Oracle(a,b),Call(tau,a,b),"exhaustive");count++;}
var extremes=new[]{new[]{-double.MaxValue,0d,double.MaxValue},new[]{0d,double.Epsilon,2*double.Epsilon},new[]{0d,-0d,1d},new[]{1d,1d,1d},new[]{1d,double.PositiveInfinity,2d},new[]{double.NaN,1d,2d}};
foreach(var a in extremes)foreach(var b in extremes){Near(Oracle(a,b),Call(tau,a,b),"extreme");count++;}
Near(2d/3,Call(old,new[]{1d,1,2},new[]{1d,1,2}),"legacy joint tie");Near(-1,Call(old,new[]{0d,double.Epsilon},new[]{0d,double.Epsilon}),"legacy underflow");Near(0,Call(old,new[]{1d,1},new[]{1d,1}),"legacy constant");
var flags=BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic;
var bs=asm.GetType("MvsAnalyzer.BackupSession")!;var json=(JsonSerializerOptions)bs.GetField("Json",flags)!.GetValue(null)!;
var rt=asm.GetType("MvsAnalyzer.BackupRequest")!;var dt=asm.GetType("MvsAnalyzer.BackupDocument")!;
var rq=Activator.CreateInstance(rt)!;rt.GetProperty("Kind")!.SetValue(rq,"benchmark");rt.GetProperty("BenchmarkStabilityMethod")!.SetValue(rq,"kendall-tau-b-v2");
var doc=Activator.CreateInstance(dt)!;dt.GetProperty("Request")!.SetValue(doc,rq);var reqjson=JsonSerializer.Serialize(rq,rt,json);dt.GetProperty("RequestHash")!.SetValue(doc,Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(reqjson))).ToLowerInvariant());
var units=(Dictionary<string,JsonElement>)dt.GetProperty("Units")!.GetValue(doc)!;
var validate=bs.GetMethod("Validate",flags)!;validate.Invoke(null,new[]{doc});
string folder="/tmp/mvs-r42-review-should-not-exist";Environment.SetEnvironmentVariable("MVS_BACKUP_DIR",folder);Environment.SetEnvironmentVariable("MVS_DISABLE_BACKUPS",null);
var run=asm.GetType("MvsAnalyzer.BackupRunner")!.GetMethod("Run",flags)!;
int rejected=0;
foreach(var marker in new string?[]{null,"future","kendall-legacy-v1"}){
var record=new Dictionary<string,object?>{{"Tau",0.5},{"Matched",true},{"Top",0},{"Failed",false},{"StabilityMethod",marker}};
units["stability/0"]=JsonSerializer.SerializeToElement(record);
string before=JsonSerializer.Serialize(doc,dt,json);
try{run.Invoke(null,new object?[]{doc,folder,null,default(CancellationToken),false});throw new Exception("Mismatch accepted");}catch(TargetInvocationException ex)when(ex.InnerException is InvalidDataException){rejected++;}
if(Directory.Exists(folder)||before!=JsonSerializer.Serialize(doc,dt,json))throw new Exception("Failed validation mutated document or disk");
}
Console.WriteLine($"PASS independent compiled oracle: {count} pairs; legacy edge behavior retained; {rejected} BackupRunner mismatch cases reject with zero disk/document mutation.");
