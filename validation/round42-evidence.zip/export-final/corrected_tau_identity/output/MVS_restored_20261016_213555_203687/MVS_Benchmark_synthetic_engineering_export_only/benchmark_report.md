# MVS benchmark report

Run synthetic_engineering_export_only, profile Quick — sanity check, seed 20260904, duration 0 min.

| Item | Value |
|---|---|
| Protocol | MVS-BENCH-1.2.0 |
| Protocol hash | `b81be4a1a86e8ba4b013eb63b75256d16e439fb824e7fa68efae5f28e48de268` |
| Protocol unchanged | yes |
| Stability method | kendall-tau-b-v2 |
| Composite comparison key | `b81be4a1a86e8ba4b013eb63b75256d16e439fb824e7fa68efae5f28e48de268/kendall-tau-b-v2/408d7cf64a8910cd90a423d7f995eaf756d1f687310cb7f1ea0ecf362b619a4f` |
| Engine | 1.6.2 |
| Formula | MVS-1.4.0 (`10a1e72218bd65ec024fc981aab9b9d0a9de8ac00db9188f9d80d54e1170598c`) |
| Application | 1.4.0 |
| Environment | 340965b398b70264 |
| Threads | 0 |

Protocol unchanged means the declared text is unchanged, not identical diagnostic arithmetic. Tau affects hypothesis C and Overall. Corrected tau-b method explicitly recorded.

## Verdict

**AT LEAST ONE THRESHOLD WAS MISSED.**

| Hypothesis | Question | Threshold | Observed | Result |
|---|---|---|---|---|
| C | synthetic, "quoted"
question | retained threshold | 0.5 | **fail** |

## Headline: data with no effect in it

## Power

| Condition | Cherry-pick | Bonferroni | Fixed median | MVS gated | Oracle |
|---|---|---|---|---|---|

## Dirty data, other shapes, real recordings

| Condition | Cherry-pick | MVS gated | Repetitions |
|---|---|---|---|

## Stability of the choice

Median Kendall tau 0.500, lower quartile 0.500, the same metric came first in 100.0% of 1 splits.

## Reproducibility

First pass: `not_executed_synthetic`

Replay: `not_executed_synthetic`

To repeat this entire run:

```
MVS_Analyzer.exe --benchmark --profile quick --seed 20260904 --out <folder>
```

## Notes

- SYNTHETIC ENGINEERING EXPORT FIXTURE. No model, simulation, RNG, replication, or scientific validation was executed. Empty fabricated cached outcome.

## What this benchmark does not prove

- The synthetic conditions are built from the same family of shapes the engine expects. That is a home advantage, and it is stated here on purpose.
- Two groups, one variable, independent entities. Paired designs, covariates and time series are outside this protocol.
- The plasmode stage reuses real recordings only if a folder of them was supplied. Without it, nothing here has touched measured data.
- Error control is a property of the procedure, not a promise about any single study.

