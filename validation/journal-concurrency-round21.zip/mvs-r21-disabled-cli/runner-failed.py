from pathlib import Path
import os,sys,json,subprocess,hashlib
root=Path('/workspace/scratch/8105054a3211/mvs-r21-disabled-cli');root.mkdir()
source=Path('/workspace/scratch/8105054a3211/mvs_stage21/MVS-analyzer-main')
sys.path[:0]=[str(source/'python/src'),str(source/'tools')]
import mvs
from test_journal_warning import WARNING
from test_python_cli import compare_analysis
os.sched_setaffinity(0,set(sorted(os.sched_getaffinity(0))[:2]))
os.environ.update(DOTNET_ROOT='/tmp/mvs-dotnet',DOTNET_PROCESSOR_COUNT='2',DOTNET_SYSTEM_IO_DISABLEFILELOCKING='1',XDG_DATA_HOME=str(root/'data'),MVS_DISABLE_BACKUPS='1')
calibration=Path('/workspace/scratch/8105054a3211/mvs-r19-canonical/calibration')
before=hashlib.sha256((calibration/'calibration_state.json').read_bytes()).hexdigest()
engine=mvs.Engine(source/'MvsAnalyzer.Cli/bin/Release/net8.0/mvs',timeout=60)
result=engine.analyze(source/'examples/demo_three_groups.csv',calibration=calibration,output=root/'output',allow_diagnostic=False)
(root/'response.json').write_text(json.dumps(dict(result.raw),indent=2))
result.verify_artifacts()
assert result.status=='completed' and result.exit_code==0 and result.raw['error'] is None
assert [d for d in result.raw['diagnostics'] if d['code']=='journal_write_failed']==[WARNING]
assert not (root/'data/MVS_Analyzer/run_journal.jsonl').exists()
normal=json.loads(Path('/workspace/scratch/8105054a3211/mvs-r21-warning-final/cli-normal/record.json').read_text())
compare_analysis(Path(normal['outputDirectory']),Path(result.raw['outputDirectory']),1e-12,1e-10)
assert before==hashlib.sha256((calibration/'calibration_state.json').read_bytes()).hexdigest()
(root/'result.json').write_text(json.dumps(dict(status='passed',pythonPolicy='allow_diagnostic=False',completed=True,exitCode=0,warning=WARNING,artifactsVerified=True,scientificParity=True,journalCreated=False),indent=2))
(root/'runner.py').write_bytes(Path(__file__).read_bytes())
print('Disabled-lock real CLI/Python completed-warning and scientific parity: PASS')
