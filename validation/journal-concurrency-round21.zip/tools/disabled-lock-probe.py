import json,os,subprocess,pathlib,hashlib,sys
root=pathlib.Path(sys.argv[1]);root.mkdir()
probe=pathlib.Path('/workspace/scratch/8105054a3211/mvs_stage21/MVS-analyzer-main/MvsAnalyzer.Core.Tests/bin/Release/net8.0/MvsAnalyzer.Core.Tests.dll')
(root/'RunAuditor.cs').write_bytes(pathlib.Path('/workspace/scratch/8105054a3211/mvs_stage21/MVS-analyzer-main/Infrastructure/RunAuditor.cs').read_bytes())
results=[]
for value in ['1','true']:
 d=root/value;d.mkdir();(d/'gate').touch();(d/'reports').mkdir()
 req=dict(mode='append',output=str(d/'result.json'),ready=str(d/'ready'),gate=str(d/'gate'),auditRoot=str(d/'reports'),writer='disabled',count=1,payloadChars=0)
 (d/'request.json').write_text(json.dumps(req))
 env=os.environ.copy();env.update(DOTNET_ROOT='/tmp/mvs-dotnet',DOTNET_PROCESSOR_COUNT='1',DOTNET_SYSTEM_IO_DISABLEFILELOCKING=value,XDG_DATA_HOME=str(d/'data'))
 p=subprocess.run(['/tmp/mvs-dotnet/dotnet',str(probe),'--journal-process-probe',str(d/'request.json')],env=env,capture_output=True,timeout=15)
 (d/'stdout.txt').write_bytes(p.stdout);(d/'stderr.txt').write_bytes(p.stderr)
 results.append(dict(value=value,exit=p.returncode,result=json.loads((d/'result.json').read_text()),journalCreated=(d/'data/MVS_Analyzer/run_journal.jsonl').exists()))
(root/'summary.json').write_text(json.dumps(results,indent=2));print(json.dumps(results))
