set -e
for file in tools/test_backups.py tools/test_source.py tools/test_paper_benchmark.py tools/test_paper_benchmark_runner.py tools/test_release_bundle.py; do python "$file"; done
PYTHONPATH=python/src python -m unittest discover -s python/tests -v
python tools/test_round2.py
python -m unittest discover -s validation -v
python validation/rank_test_reference.py
python tools/check_source.py
python tools/check_cli_contract.py
