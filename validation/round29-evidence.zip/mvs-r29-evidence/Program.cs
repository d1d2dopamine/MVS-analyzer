using MvsAnalyzer;using System.Text.Json;
string root=Path.Combine(Path.GetTempPath(),"mvs-restart-fixture-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);
Environment.SetEnvironmentVariable("MVS_DISABLE_BACKUPS",null);Environment.SetEnvironmentVariable("MVS_BACKUP_DIR",root);
try{
var request=new BackupRequest{Kind="melsm",Melsm=new()};var saved=new BackupDocument{Request=request,RequestHash=ScientificMath.Hash(BackupSession.Pack(request))};saved.Environments.Add("foreign-runtime");saved.Units["simplex"]=JsonSerializer.SerializeToElement(new NumericalMethods.SimplexCheckpoint(new[]{new[]{1d},new[]{2d}},new[]{-999d,-998d},0),BackupSession.Json);
var obstruction=Path.Combine(root,"MVS_Backups.zip");Directory.CreateDirectory(obstruction);
using(BackupSession.Restore(saved)){try{using var session=BackupSession.Begin(request);}catch(IOException){Console.WriteLine("initial publication failed as intended");}}
var disk=BackupSession.Decode(File.ReadAllBytes(Directory.GetFiles(root,"*.mvsbackup").Single()));Directory.Delete(obstruction);
using(BackupSession.Restore(disk))using(var session=BackupSession.Begin(request)){
int calls=0;var result=NumericalMethods.Minimize(x=>{calls++;return x[0]*x[0];},new[]{1d},new[]{-10d},new[]{10d},maximumIterations:0,backup:session,checkpointKey:"simplex");Console.WriteLine(JsonSerializer.Serialize(new{session.EnvironmentChanged,calls,result.Value,history=disk.Environments}));
}
}finally{Directory.Delete(root,true);}
