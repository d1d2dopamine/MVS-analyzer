using MvsAnalyzer;
using System.Text.Json;
var root=Path.Combine(Path.GetTempPath(),"mvs-restore-retry-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);
var blocker=Path.Combine(root,"blocked");File.WriteAllText(blocker,"own test fixture");
var oldDir=Environment.GetEnvironmentVariable("MVS_BACKUP_DIR");var oldDisable=Environment.GetEnvironmentVariable("MVS_DISABLE_BACKUPS");
var request=new BackupRequest{Kind="estimation",Estimation=new()};
var saved=new BackupDocument{Request=request,RequestHash=ScientificMath.Hash(BackupSession.Pack(request))};
saved.Units["retained-unit"]=JsonSerializer.SerializeToElement(new[]{7,11,19});
string? error=null;bool pendingSurvived=false,restored=false,unitSurvived=false;string? retryId=null;
try{
 Environment.SetEnvironmentVariable("MVS_DISABLE_BACKUPS",null);Environment.SetEnvironmentVariable("MVS_BACKUP_DIR",blocker);
 using(BackupSession.Restore(saved)){
  try{using var unexpected=BackupSession.Begin(request);}catch(IOException e){error=e.GetType().Name;}
  pendingSurvived=ReferenceEquals(BackupSession.Pending,saved);
  Environment.SetEnvironmentVariable("MVS_BACKUP_DIR",Path.Combine(root,"repaired"));
  using(var retry=BackupSession.Begin(request)){restored=retry.WasRestored;unitSurvived=retry.Try<int[]>("retained-unit",out var values)&&values.SequenceEqual(new[]{7,11,19});}
  var docs=Directory.GetFiles(Path.Combine(root,"repaired"),"*.mvsbackup").Select(p=>BackupSession.Decode(File.ReadAllBytes(p))).ToArray();retryId=docs.First().Id;
 }
 Console.WriteLine(JsonSerializer.Serialize(new{initialError=error,pendingSurvived,restored,unitSurvived,idPreserved=retryId==saved.Id,originalUnitsStillInMemory=saved.Units.ContainsKey("retained-unit")}));
}finally{Environment.SetEnvironmentVariable("MVS_BACKUP_DIR",oldDir);Environment.SetEnvironmentVariable("MVS_DISABLE_BACKUPS",oldDisable);Directory.Delete(root,true);}
