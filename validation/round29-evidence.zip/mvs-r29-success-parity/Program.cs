using MvsAnalyzer;
using System.Text.Json.Nodes;
using System.Text.Json;
var folder=Path.Combine(Path.GetTempPath(),"mvs-parity-"+Guid.NewGuid().ToString("N"));
var old=Environment.GetEnvironmentVariable("MVS_BACKUP_DIR");var disabled=Environment.GetEnvironmentVariable("MVS_DISABLE_BACKUPS");
try{Environment.SetEnvironmentVariable("MVS_BACKUP_DIR",folder);Environment.SetEnvironmentVariable("MVS_DISABLE_BACKUPS",null);
var request=new BackupRequest{Kind="estimation",Estimation=new()};int evaluations=0;
using(var b=BackupSession.Begin(request)){b.Cached("unit",()=>++evaluations);b.Cached("unit",()=>++evaluations);b.Finish(new[]{2d,3d});}
var saved=Directory.GetFiles(folder,"*.mvsbackup").Select(p=>BackupSession.Decode(File.ReadAllBytes(p))).First(d=>d.CalculationComplete);
var initial=JsonNode.Parse(BackupSession.Pack(saved))!.AsObject();initial.Remove("Id");initial.Remove("SavedUtc");
bool restored=false;using(BackupSession.Restore(saved)){using var b=BackupSession.Begin(request);restored=b.WasRestored;b.Cached("unit",()=>++evaluations);b.Finish(new[]{2d,3d});}
var final=JsonNode.Parse(BackupSession.Pack(saved))!.AsObject();final.Remove("Id");final.Remove("SavedUtc");
Console.WriteLine(JsonSerializer.Serialize(new{evaluations,restored,initial,final}));
}finally{Environment.SetEnvironmentVariable("MVS_BACKUP_DIR",old);Environment.SetEnvironmentVariable("MVS_DISABLE_BACKUPS",disabled);if(Directory.Exists(folder))Directory.Delete(folder,true);}
