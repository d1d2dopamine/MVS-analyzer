set -eu
cd /workspace/scratch/8105054a3211/mvs_round36/MVS-analyzer-main
python tools/test_backups.py
python tools/test_source.py
python tools/test_paper_benchmark.py
python tools/test_paper_benchmark_runner.py
python tools/test_release_bundle.py
python tools/test_round2.py
