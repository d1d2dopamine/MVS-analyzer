set -eu
source /workspace/scratch/8105054a3211/mvs_r22_baseline/env.sh
cd /workspace/scratch/8105054a3211/mvs_round36/MVS-analyzer-main
dotnet run --project MvsAnalyzer.Core.Tests/MvsAnalyzer.Core.Tests.csproj -c Release
dotnet run --project validation/partial_output_harness/PartialOutputHarness.csproj -c Release -- --candidate "$PWD/MvsAnalyzer.Cli/bin/Release/net8.0/mvs.dll" --out /workspace/scratch/8105054a3211/mvs-r36-old-partial
dotnet run --project validation/resume_output_harness/ResumeOutputHarness.csproj -c Release -- --candidate "$PWD/MvsAnalyzer.Cli/bin/Release/net8.0/mvs.dll" --out /workspace/scratch/8105054a3211/mvs-r36-old-resume
