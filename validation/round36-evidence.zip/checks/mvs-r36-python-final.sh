set -eu
source /workspace/scratch/8105054a3211/mvs_r22_baseline/env.sh
cd /workspace/scratch/8105054a3211/mvs_round36/MVS-analyzer-main
export PYTHONPATH="$PWD/python/src"
export PYTHONDONTWRITEBYTECODE=1
export MVS_MCP_TEST_ENGINE="$PWD/MvsAnalyzer.Cli/bin/Release/net8.0/mvs"
export MVS_MCP_TEST_DATA="$PWD/examples/demo_three_groups.csv"
export MVS_MCP_TEST_CALIBRATION=/workspace/scratch/8105054a3211/mvs_r22_baseline/artifacts/calibration/calibration_state.json
/workspace/scratch/8105054a3211/mvs_mcp_venv/bin/python -m unittest discover -s python/tests -v
