# Round36 independent provenance review

## Conclusion and executed checks

No blocking finding remains in the final reviewed candidate. The correction is limited to current-invocation output attribution and its Python consumers, with an explicit successor source-pin record. Numerical/scientific source and acceptance limits remain unchanged.

Independently executed:

- Source-pin contract: 43/43 tests.
- Broader Colab connection contract: 48/48 tests.
- UI source contract: 18/18 tests.
- Final saved native overwrite evidence, corruption validator and CI routing guard: 44/44 tests against the retained 21-case native report. The earlier 43-test run is also preserved.
- Final Python scoped-artifact tests: 34/34 tests.

All five executions passed without skips. Their raw logs are retained beside this report. The saved-evidence check did not rerun native calculations; it independently checked retained files, hashes, identities and outcomes from the explicitly executed native harness. No timing or scientific-performance claim is made.

## Native production boundary

ScientificCommands now supplies each command's exact three produced filenames to the manifest helper. Those lists match all direct output writes for variance, estimation and MELSM. There is no post-hoc directory enumeration in this helper. Human-mode manifests receive the same correction. Scientific computation calls and their parameters are unchanged.

MachineProtocol uses the successful-write ledger whenever tracking has started, on completed, diagnostic and failed exits. The additive artifactScope marker appears only on tracked responses. Existing unrelated files are not deleted or adopted. Manifest identity is selected only from a verified current manifest. Thus a successful calibration-like invocation with no current manifest cannot inherit an old manifest or run ID. Explicit current analysis run IDs retain precedence. Partial-error semantics remain equivalent apart from the additive marker.

Observed output coverage was inspected for calibrate, analyze, direct scientific commands and non-benchmark resume: fixed writes, exporter callbacks and successfully returned plugin reports already enter the ledger. Untracked benchmark and state-check retain their documented listing/read-existing semantics.

Limits remain material:

- A file changed, deleted or unreadable after observation can be omitted after re-verification. Completion is not a permanently complete or atomic multi-file snapshot.
- Resumed ScientificTables manifests still enumerate their freshly generated child folder. This change does not redesign that producer against concurrent file injection.
- Plugin output attribution remains limited to successfully returned paths; hidden writes before plugin failure are not retrospectively discovered.
- The marker is a native provenance assertion, not cryptographic authentication or proof of scientific adequacy.

## Retained native evidence

The reviewed harness distinguishes actual CLI subprocesses from protocol-only fixtures. The retained report contains 21 cases, all passing, including two baseline counterexamples.

Independent validation confirms:

- Actual clean/contaminated variance, estimation and MELSM runs preserve exact scientific output bytes and exit semantics.
- Stale canaries remain byte-identical while current manifests/artifact lists exclude them.
- Actual capped MELSM retains diagnostic exit 2.
- Human estimation uses the scoped manifest and the same scientific bytes.
- Current manifest/run-ID binding holds; stale identity is absent when no current manifest exists.
- Changed, deleted, locked and failed-rewrite targets are excluded without directory fallback.
- The untracked benchmark fixture is protocol-only and retains baseline payload behavior.
- Baseline estimation still exhibits stale adoption; baseline/candidate clean estimation scientific files are byte-identical.

No statistical benchmark model was executed by the overwrite harness. Minimum-budget deterministic fixtures test engineering behavior, not numerical adequacy. Recorded elapsed times are not a performance comparison.

## Python consumer review

Marked results enforce the explicit current-invocation list for lookup, manifest access, verification and copying. Unknown or malformed markers fail closed; absent markers preserve the legacy contract. Scoped metadata requires safe unique single filenames, complete sizes/hashes and paths matching the declared output directory. Copy preflights all identities before creating its destination, copies only listed files, verifies copied bytes and refuses existing destinations. Failed-result copying remains prohibited; listed partial artifacts remain readable under identity checks.

One API bypass was found during review and corrected before acceptance: Engine.analyze formerly consumed Calibration.output_directory directly. A marked Calibration now resolves and verifies its listed calibration_state.json before launching native analysis. Unlisted, missing, modified or unsupported-scope state raises InputError without launching the child. Valid marked calibration passes the verified file path; unmarked legacy Calibration retains directory behavior.

The final policy rejects links/reparse points in scoped paths, including existing ancestors. This is deliberately stricter than legacy behavior and requires real/canonical paths for scoped lookup, copying, manifest access and calibration reuse. Ordinary macOS /tmp or /var aliases can be affected; no macOS/Windows acceptance is established by these Linux checks. The checks are static and do not promise a race-proof namespace sandbox. Copy failures or concurrent changes can leave a partial destination, which is documented rather than reported as success.

The MCP workflow already validates receipt artifact paths, names, sizes and hashes, and read_artifact serves only verified listed entries. It does not use the Python whole-directory copy/fallback path. Additive native scope metadata can remain in the receipt without granting independent authenticity or weakening existing immutable request binding.

## Versioned source-pin successor

The original UI manifest, checkpoint revision manifest and complete Round35 v2 manifest remain byte-identical. V3 is mandatory and loaded only after v2 is fully validated. It binds the exact raw v2 hash, original anchor and v2 effective ScientificCommands hash, then supplies the new literal reviewed hash. It never derives an expected hash from current production bytes.

Exactly one effective protected-source pin changes: ScientificCommands.cs. Tests preserve the exact v2 17-entry scope and four historical-gap labels, assert literal old-manifest identities, and require exactly the one-path v3 transition. The successor explicitly preserves ScientificCommands' inherited historical gap while labeling only the new Round35-to-Round36 transition complete. Missing layers, broken predecessor/raw bindings, duplicate or malformed entries, unsupported schema/stage, path errors, drift and optimized-Python behavior are covered by negative tests.

No historical source gap was erased, and no scientific readiness was promoted.

## CI routing issue found and resolved

The first integration put deliberate negative fixtures below the canonical artifacts tree. The later recursive check_outputs.py scan therefore tried to validate seeded stale manifests and obstruction directories as successful output. Independent read-only reproductions failed on the new overwrite evidence (missing sha256) and on both existing partial/resume evidence trees (run_manifest.json directories). All three failure logs are retained.

The final workflow routes all three harnesses to sibling regression-evidence directories and explicitly uploads that tree. The canonical check_outputs, check_cli_contract and score-validation commands remain unchanged. A regression guard requires this separation and upload; the final saved-evidence/guard suite passes 44/44. The parent also retained a local canonical-validator proof with the negative fixtures in a sibling tree. This is a reviewed local routing correction, not a claim that remote CI was dispatched or every remote job ran.
