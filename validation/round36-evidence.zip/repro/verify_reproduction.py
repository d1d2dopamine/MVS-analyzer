from pathlib import Path
import hashlib, json
root = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda p: json.loads(p.read_text())
canary = read(root / 'evidence/canary_before.json')
expected = (root / 'input/stale_previous_report.txt').read_bytes()
actual = (root / 'output/contaminated/stale_previous_report.txt').read_bytes()
summary = {'fixture': 'Minimum supported seeded engineering estimation fixture; not scientific validation', 'sourceParity': read(root / 'evidence/source_parity.json'), 'projectWriteCheck': read(root / 'evidence/project_write_check.json'), 'canary': {'name':canary['file'], 'sizeBytes':len(actual), 'beforeSha256':canary['sha256'], 'afterSha256':sha(actual), 'unchanged':actual == expected}, 'runs': {}, 'scientificOutputs': []}
assert actual == expected
assert sha(actual) == canary['sha256']
for label in ('contaminated', 'clean'):
    payload = read(root / f'evidence/{label}.stdout.json')
    manifest = read(root / f'output/{label}/run_manifest.json')
    process_exit = int((root / f'evidence/{label}.exit.txt').read_text())
    rows_m = [row for row in manifest['files'] if row['FileName'] == canary['file']]
    rows_p = [row for row in payload['artifacts'] if row['name'] == canary['file']]
    summary['runs'][label] = {'processExitCode':process_exit, 'protocolExitCode':payload['exitCode'], 'status':payload['status'], 'execution':payload['execution'], 'scientificReadiness':payload['scientificReadiness'], 'manifestFileCount':len(manifest['files']), 'machineArtifactCount':len(payload['artifacts']), 'staleManifestEntries':rows_m, 'staleMachineArtifactEntries':rows_p, 'configuration':manifest['configuration']}
    assert process_exit == payload['exitCode'] == 0
    assert payload['status'] == 'completed' and payload['execution']['completed'] is True
    assert payload['scientificReadiness']['status'] == 'no_go'
    if label == 'contaminated':
        assert len(rows_m) == len(rows_p) == 1
        assert rows_m[0]['sha256'] == rows_p[0]['sha256'] == canary['sha256']
        assert rows_m[0]['SizeBytes'] == rows_p[0]['sizeBytes'] == canary['sizeBytes']
    else:
        assert rows_m == rows_p == []
for name in ('estimation_report.json','estimation_performance.csv','estimation_draws.csv'):
    a = (root / f'output/contaminated/{name}').read_bytes()
    b = (root / f'output/clean/{name}').read_bytes()
    summary['scientificOutputs'].append({'name':name, 'sizeBytes':len(a), 'byteIdentical':a == b, 'contaminatedSha256':sha(a), 'cleanSha256':sha(b), 'normalization':'none'})
    assert a == b
assert summary['runs']['clean']['configuration'] == summary['runs']['contaminated']['configuration']
for record in summary['sourceParity']: assert record['equal']
for record in summary['projectWriteCheck'].values(): assert not record['changed'] and not record['added'] and not record['removed']
summary['result'] = 'CONFIRMED: successful overwrite adopts unrelated unchanged old file into current run manifest and machine artifacts'
(root / 'evidence/comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
print(summary['result'])
print('Both exits 0; 3 scientific files byte-identical; stale canary unchanged and listed twice; source trees unchanged.')
