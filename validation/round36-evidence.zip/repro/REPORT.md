# Round36: successful --overwrite stale-file adoption

## Result

CONFIRMED using the actual CLI. A seeded estimation invocation with `--overwrite --json` exited 0 and reported `status: completed` and `execution.completed: true`, while both the newly written `run_manifest.json.files` and machine-result `artifacts` included a pre-existing, unrelated report that the invocation did not write.

The 164-byte `stale_previous_report.txt` was byte-for-byte unchanged. Its pre-run, post-run, manifest-listed, and machine-listed SHA-256 values all equal:

`65d4f30deb2c453c0c11a692e9a651da52ec4147c15cd659412cdb0df357fde5`

The clean-output control ran the same arguments except `--out`, also exited 0, and did not contain or list the canary. The contaminated manifest listed four files versus the clean manifest's three; machine results listed five artifacts versus four, including the respective manifest.

All three current scientific files are byte-identical across the two runs. No normalization was applied:

- `estimation_report.json`: 67,523 bytes; SHA-256 `1a0138203097a816bea54dd0af47d6fee70dfa06792224610dcde608f1e32f38`
- `estimation_performance.csv`: 1,085 bytes; SHA-256 `135462edd8b95142a0b580385044c9d8176872f828d86c8148de0711d301b89b`
- `estimation_draws.csv`: 28,070 bytes; SHA-256 `c3fbcb28a2dc1272650b3a4d3c81c9b02d2ae16319c696a7181ffcf59c7a92b8`

Both machine payloads retain `scientificReadiness.status: no_go` and `independentConfirmatoryValidation: false`.

## Fixture and commands

The CLI requires at least four entities, three measurements, 100 repetitions, and 99 bootstrap draws. This reproduction uses exactly those minimum budgets as a deterministic engineering fixture, with no real data or new scientific-validation claims.

Runtime: existing round34 `MvsAnalyzer.Cli/bin/Release/net8.0/mvs.dll`, .NET SDK 8.0.425, .NET host/runtime 8.0.31, Linux x64. The six directly relevant source files (including the four requested comparison files) have identical hashes in round34 and round35. No rebuild or source edit was performed.

Common arguments:

`estimation --target mean --shape normal --entities 4 --measurements 3 --repetitions 100 --bootstrap 99 --seed 20260719 --location 100 --within-sd 10 --between-sd 5 --overwrite --json`

The `--out` paths are `output/contaminated` and `output/clean` underneath this reproduction directory. Full absolute commands, process exits, stdout, stderr, and output files are retained. `run_reproduction.sh` is the executed harness; `verify_reproduction.py` independently verifies the retained evidence without re-running the CLI.

The authorized SDK environment was sourced with its final `mkdir` side effect removed, then HOME, CLI home, application-data roots, caches, temporary folders, and backup destination were redirected under `isolation/`. No user input data was used. Both invocations create distinct backup sessions; they are ordinary estimation calls, not resume calls.

## Mechanism and impact

- `MvsAnalyzer.Cli/OutputSafety.cs:38-39`: the nonempty-output-directory rejection is disabled by `--overwrite`.
- `MvsAnalyzer.Cli/ScientificCommands.cs:39-44`: estimation writes its three known scientific outputs and a manifest, then records the output directory.
- `MvsAnalyzer.Cli/ScientificCommands.cs:88-95`, particularly line 90: manifest construction enumerates every top-level file except `run_manifest.json`, including old unrelated files.
- `MvsAnalyzer.Cli/MachineProtocol.cs:94-96` and `176-193`, particularly lines 181-188: the successful machine-result path independently enumerates every top-level file rather than the current invocation's successful-write ledger.

This is a provenance/attribution error: a successful current run reports old unrelated files as its output artifacts with valid content hashes. Consumers that package, display, or trust the current artifact lists can consequently treat stale content as belonging to the new run. The demonstrated defect does not alter current scientific calculations or promote release/scientific readiness.

## Retained evidence and safety checks

- `evidence/comparison.json`: machine-checkable outcome, exact canary entries, source parity, full fixture configuration, and scientific byte comparison.
- `evidence/contaminated.stdout.json`, `evidence/clean.stdout.json`: actual machine output, with matching `.stderr.txt` and `.exit.txt` files.
- `output/contaminated/`, `output/clean/`: actual generated artifacts; `input/` preserves the preseeded canary bytes.
- `evidence/commands.log`: shell trace of actual execution.
- `evidence/source_parity.json`, `evidence/runtime_hashes.sha256`, `evidence/dotnet-info.txt`, and `evidence/effective_environment.txt`: source/runtime identities and execution settings.
- `evidence/round34_files_before.json` / `_after.json` and corresponding round35 snapshots: complete regular-file hash inventories excluding `.git` metadata.
- `evidence/project_write_check.json`: all 739 round34 and 510 round35 files unchanged, with no added or removed files.
- `isolation/backups/`: backup artifacts were confined to the reproduction directory.

No source fix, commit, CI dispatch, or project-file mutation was performed. Work stops after this read-only-to-project reproduction.
