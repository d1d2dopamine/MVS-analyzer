"""Independent read-only Round43 saved-evidence audit; no calibration or dataset generation."""
import csv, hashlib, json, math, statistics, struct, time
from pathlib import Path
OUT=Path('/workspace/scratch/8105054a3211/mvs-r43-evidence/independent-review')
RUN=Path('/workspace/scratch/8105054a3211/mvs-r43-replay')
load=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
bits=lambda x:struct.pack('>d',x)
M=(1<<64)-1; G=0x9E3779B97F4A7C15

def mix(x):
 z=(x+G)&M;z=((z^(z>>30))*0xBF58476D1CE4E5B9)&M;z=((z^(z>>27))*0x94D049BB133111EB)&M
 return z^(z>>31)
def derive(i):
 x=20260904
 for v,k in [(5,G),(1,0xC2B2AE3D27D4EB4F),(i,0x165667B19E3779F9)]: x=mix((x+v*k)&M)
 return x
def rot(x,n):
 x &= M
 return ((x<<n)|(x>>(64-n)))&M
class Consume:
 def __init__(self,seed):self.s=[mix((seed+i*G)&M) for i in range(4)];self.spare=False
 def raw(self):
  a,b,c,d=self.s;r=(rot(b*5,7)*9)&M;t=(b<<17)&M;c^=a;d^=b;b^=c;a^=d;c^=t;self.s=[a,b,c,rot(d,45)];return r
 def uniform(self):return (self.raw()>>11)/9007199254740992
 def gaussian(self):
  if self.spare:self.spare=False;return
  while True:
   u=self.uniform()*2-1;v=self.uniform()*2-1;r=u*u+v*v
   if r>1e-300 and r<1:break
  self.spare=True
 def consumed_seeds(self):
  # Consume precisely the historical gait-heavy generator RNG calls, without producing data.
  for _ in range(32):
   self.gaussian();self.gaussian()
   for _ in range(40):
    for _ in range(6):self.gaussian()
    self.uniform();self.uniform()
  return [self.raw()%50000000+1 for _ in range(3)]

def tau(a,b,legacy=False):
 c=d=ta=tb=joint=0
 for i in range(len(a)):
  for j in range(i+1,len(a)):
   if legacy:
    da=a[i]-a[j];db=b[i]-b[j]
    if da==0 and db==0:ta+=1;tb+=1;joint+=1
    elif da==0:ta+=1
    elif db==0:tb+=1
    elif da*db>0:c+=1
    else:d+=1
   else:
    da=(a[i]>a[j])-(a[i]<a[j]);db=(b[i]>b[j])-(b[i]<b[j])
    if not da and not db:joint+=1
    elif not da:ta+=1
    elif not db:tb+=1
    elif da==db:c+=1
    else:d+=1
 den=math.sqrt((c+d+ta)*(c+d+tb))
 return ((c-d)/den if den>0 else None), dict(concordant=c,discordant=d,left_only_ties=ta,right_only_ties=tb,joint_ties=joint)

def quant(v,q):
 v=sorted(v);p=q*(len(v)-1);i=math.floor(p);return v[i]+(v[min(i+1,len(v)-1)]-v[i])*(p-i)
start=time.monotonic();m=load(RUN/'bind.json');report=load(RUN/'report.json');finished=load(RUN/'run-finished.json')
assert sha(RUN/'bind.json')=='36912dcc45f2d2d1d27c0ace940ed2c63125b892088455f9f3d420cca6182eea'
for p,h in m['pins'].items():assert sha(p)==h,('pin',p)
assert len(finished['attempts'])==120 and not finished['stop_reasons'] and finished['end_hash_verification']=='passed'
assert [a['index'] for a in finished['attempts']]==list(range(120))
history=list(csv.DictReader(open(m['history'],encoding='utf-8-sig')))
historic=load(Path(m['history']).with_name('benchmark_manifest.json'))
metrics=['median','standard_deviation','coefficient_of_variation','mad','iqr','normalized_mad','normalized_iqr','mean','rms','range','geometric_mean','trimmed_mean_20']
checks=[];oldtaus=[];newtaus=[];matches=0;cpu=0.;native_peaks=[]
for i,attempt in enumerate(finished['attempts']):
 assert attempt['started'] and attempt['returncode']==0 and not attempt.get('error')
 for p,h in attempt['files'].items():assert sha(p)==h,('artifact',p)
 p=RUN/f'case-{i:03d}'/'native.json';case=load(p);h=history[i]
 assert case['index']==i and h['split_index']==str(i)
 assert (case['status'],case['diagnostics_status'],case['error'])==('completed','retained','')
 assert case['metric_order']==metrics
 s=case['seeds'];assert s['run_seed']==20260904 and s['derived_seed']==derive(i)
 assert [s[k] for k in ['split_seed','calibration_left_seed','calibration_right_seed']]==Consume(derive(i)).consumed_seeds()
 ident=case['identity'];assert ident['processor_count']==1 and ident['runtime']=='.NET 8.0.31' and ident['architecture']=='X64'
 assert ident['environment_sha256']==historic['environmentHash']==hashlib.sha256(ident['environment_fingerprint'].encode()).hexdigest()
 assert ident['harness_sha256']==m['pins'][m['command'][1]]
 assert ident['core_sha256']==m['pins'][str(Path(m['native_dir'])/'MvsAnalyzer.Core.dll')]
 for key,bound in case['data'].items():
  assert hashlib.sha256(bound['canonical_json'].encode()).hexdigest()==bound['sha256']
  assert json.loads(bound['canonical_json'])==bound['values']
 data={k:v['values'] for k,v in case['data'].items()}
 assert len(data['generated'])==1280 and data['generated']==data['built']['observations']
 assert data['built']['group_counts']==[16,16]
 built={(r['group'],r['entity'],r['sequence']):r for r in data['generated']}
 left={(r['group'],r['entity'],r['sequence']):r for r in data['left']['observations']}
 right={(r['group'],r['entity'],r['sequence']):r for r in data['right']['observations']}
 assert len(left)==len(right)==640 and not(left.keys()&right.keys()) and left|right==built
 for side in ['left','right']:
  assert data[side]['group_counts']==[8,8]
  cal=case['calibration_'+side];scores=case['scores_'+side]
  assert len(cal)==len(scores)==12 and [r['metric'] for r in cal]==metrics
  for row,value in zip(cal,scores):
   expected=row['score'] if row['score'] is not None else 0.
   assert bits(expected)==bits(value)
   assert row['repetitions']==1000 and row['alpha']==.05
  top=max(range(12),key=lambda k:scores[k])
  for method in ['legacy','corrected']:
   assert case[method]['top_'+side+'_index']==top and case[method]['top_'+side]==metrics[top]
 a=case['scores_left'];b=case['scores_right'];old,oc=tau(a,b,True);new,nc=tau(a,b)
 assert bits(old)==bits(case['legacy']['kendall_tau'])==bits(float(h['kendall_tau']))
 assert bits(new)==bits(case['corrected']['kendall_tau'])
 for k in ['top_left','top_right']:assert case['legacy'][k]==h[k]==case['corrected'][k]
 matched=case['legacy']['top_left']==case['legacy']['top_right']
 assert matched==case['legacy']['matched']==case['corrected']['matched']==(h['matched']=='true')
 assert case['legacy']['defined'] and case['corrected']['defined']
 matches+=matched;oldtaus.append(old);newtaus.append(new);cpu+=case['resources']['cpu_seconds'];native_peaks.append(case['resources']['peak_working_set_bytes'])
 vectorhash=hashlib.sha256(b''.join(bits(v) for v in a+b)).hexdigest()
 checks.append(dict(index=i,native_sha256=sha(p),vector_binary64_big_endian_sha256=vectorhash,derived_seed=s['derived_seed'],consumed_seeds=[s[k] for k in ['split_seed','calibration_left_seed','calibration_right_seed']],legacy_tau=old,corrected_tau=new,corrected_integer_pair_counts=nc,matched=matched))
assert matches==27
assert statistics.median(oldtaus)==report['original_tau_summary']['median']
assert statistics.median(newtaus)==report['corrected_median_tau']
assert quant(newtaus,.25)==report['corrected_lower_quartile_tau']
assert report['corrected_finite_count']==120 and report['corrected_undefined_count']==0 and report['execution_failed_count']==0 and report['not_started_count']==0
assert report['corrected_top_one_agreement']==matches/120==report['corrected_matched_over_requested']
assert report['same_recipe_replay_matching_retained_diagnostics'] and report['scientific_go'] is False
summary=dict(status='passed',calibration_executed=False,new_datasets_generated=False,case_count=120,pin_count=len(m['pins']),binary64_legacy_matches=120,binary64_corrected_oracle_matches=120,derived_and_consumed_seed_matches=120,canonical_data_hashes_verified=480,projected_vectors_verified=240,legacy_median=statistics.median(oldtaus),corrected_median=statistics.median(newtaus),legacy_lower_quartile=quant(oldtaus,.25),corrected_lower_quartile=quant(newtaus,.25),requested=120,usable=120,undefined=0,execution_failed=0,top_one_matched=27,top_one_agreement=.225,corrected_greater_count=sum(n>o for n,o in zip(newtaus,oldtaus)),corrected_equal_count=sum(n==o for n,o in zip(newtaus,oldtaus)),summed_native_cpu_seconds=cpu,max_native_peak_working_set_bytes=max(native_peaks),run_elapsed_seconds=finished['elapsed_seconds'],sampled_aggregate_peak_rss_bytes=finished['peak_aggregate_rss_bytes'],audit_wall_seconds=time.monotonic()-start,bind_sha256=sha(RUN/'bind.json'),report_sha256=sha(RUN/'report.json'),limitations=['Same-recipe replay matching all retained diagnostics; original score vectors were not retained, so exact identity to original vectors is unproved.','Seed audit independently replays RNG consumption only; no new generated data or calibration.','Data hash audit establishes internal recorded-byte consistency and complete disjoint split partition; it does not recover historical data bytes.','Scientific NO-GO unchanged; no power deficit repaired.'],cases=checks)
with (OUT/'audit-result.json').open('x') as f:json.dump(summary,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in summary.items() if k!='cases'},indent=2))
