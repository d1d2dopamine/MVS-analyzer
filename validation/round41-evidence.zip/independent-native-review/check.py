from decimal import Decimal, localcontext
import hashlib,json,pathlib,subprocess,sys
out=pathlib.Path(sys.argv[1]); work=pathlib.Path('/tmp/mvs-round41-focused-family-artifacts')
source=work/'self-test.json'; evidence=json.loads(source.read_text()); fixture=evidence['measurementFixture']
assert evidence['status']=='passed' and evidence['totalChecks']==171
assert fixture['measurements']==[1,2,4,8,16,32,64,128] and fixture['shift']==100 and fixture['scale']==2 and fixture['relativeTolerance']==1e-12
keys=['median','standard_deviation','coefficient_of_variation','mad','iqr','normalized_mad','normalized_iqr','mean','rms','range','geometric_mean','trimmed_mean_20']
def q(v,p):
 v=sorted(v); t=Decimal(len(v)-1)*p; k=int(t); return v[k]+(t-k)*(v[min(k+1,len(v)-1)]-v[k])
def oracle(values):
 x=list(map(Decimal,values)); n=Decimal(len(x)); mean=sum(x)/n; median=q(x,Decimal('.5'))
 # Independently use second-moment identity for the sample variance.
 sd=((sum(v*v for v in x)-sum(x)**2/n)/(n-1)).sqrt()
 mad=q([abs(v-median) for v in x],Decimal('.5')); iqr=q(x,Decimal('.75'))-q(x,Decimal('.25'))
 prod=Decimal(1)
 for v in x: prod*=v
 k=len(x)//5; trim=sorted(x)[k:len(x)-k]
 return dict(zip(keys,[median,sd,sd/abs(mean),mad,iqr,mad/abs(median),iqr/abs(median),mean,(sum(v*v for v in x)/n).sqrt(),max(x)-min(x),(prod.ln()/n).exp(),sum(trim)/len(trim)]))
checks=[]
with localcontext() as ctx:
 ctx.prec=80
 for name,values in [('original',fixture['measurements']),('shifted',[x+100 for x in fixture['measurements']]),('scaled',[2*x for x in fixture['measurements']])]:
  expect=oracle(values); assert list(fixture[name])==keys
  for key,value in expect.items():
   actual=Decimal.from_float(float(fixture[name][key])); error=abs(actual-value)/max(abs(actual),abs(value)); passed=error<=Decimal('1e-12')
   checks.append(dict(transform=name,metric=key,native=fixture[name][key],decimal80Expected=str(value),relativeError=str(error),passed=passed))
   assert passed,(name,key,actual,value,error)
transform=dict(status='passed',count=len(checks),method='Decimal80 second-moment variance, type-7 quantiles, product-root geometric mean; fixed literal transformations',tolerance='relative 1e-12',selfTestSha256=hashlib.sha256(source.read_bytes()).hexdigest(),maximumRelativeError=str(max(Decimal(c['relativeError']) for c in checks)),checks=checks)
(out/'transform-check.json').write_text(json.dumps(transform,indent=2)+'\n')
cases=[]
for name,index,p in [('all-unavailable',None,None),('sparse-mad',3,.003),('sparse-rms',8,.02)]:
 values=[None]*12; available=[False]*12
 if index is not None: values[index]=p; available[index]=True
 cases.append(dict(id=name,pValues=values,available=available))
raw=(json.dumps(dict(schemaVersion='mvs-focused-family-input/v1',cases=cases),separators=(',',':'))+'\n').encode()
dll=work/'bin/FocusedFamilyExperiment/release/MvsAnalyzer.Core.Tests.dll'; core=dll.with_name('MvsAnalyzer.Core.dll')
command=['/workspace/scratch/8105054a3211/mvs_r22_baseline/sdk/dotnet',str(dll),'--input','-']
run=subprocess.run(command,input=raw,capture_output=True,timeout=120)
(out/'synthetic-input.json').write_bytes(raw); (out/'synthetic-native.json').write_bytes(run.stdout); (out/'synthetic-stderr.txt').write_bytes(run.stderr)
assert run.returncode==0 and not run.stderr
native=json.loads(run.stdout); assert native['status']=='isolated-development-diagnostic' and native['decisionStatus']=='no-go'
assert native['provenance']==dict(harnessSha256=hashlib.sha256(dll.read_bytes()).hexdigest(),coreSha256=hashlib.sha256(core.read_bytes()).hexdigest(),inputSha256=hashlib.sha256(raw).hexdigest())
assert [r['id'] for r in native['cases']]==[c['id'] for c in cases]
for result,case in zip(native['cases'],cases):
 for name,fam in result['families'].items():
  for m in fam['members']:
   p=case['pValues'][m['index']]; expected=None if p is None else min(1,p*fam['fullDenominator'])
   assert m['rawP']==p and m['adjustedP']==expected and m['rejected']==(expected is not None and expected<.05)
  assert fam['anyRejected']==any(m['rejected'] for m in fam['members'])
  values=[m['adjustedP'] for m in fam['members'] if m['available']]
  assert fam['minAdjustedP']==(min(values) if values else None)
 for name,fam in result['simultaneousPartition']['families'].items():
  assert fam['multiplier']==4*fam['fullDenominator']
  for m in fam['members']:
   p=case['pValues'][m['index']]; expected=None if p is None else min(1,p*(4*fam['fullDenominator']))
   assert m['adjustedP']==expected and m['rejected']==(expected is not None and expected<.05)
assert native['cases'][0]['availabilityStatus']=='all-unavailable'
assert native['cases'][0]['simultaneousPartition']['minAdjustedP'] is None
assert native['cases'][1]['simultaneousPartition']['families']['absolute4']['minAdjustedP']==.048
assert native['cases'][2]['naiveFocusedUnion']['anyRejected'] and not native['cases'][2]['simultaneousPartition']['anyRejected']
result=dict(status='passed',transformChecks=36,maximumTransformRelativeError=transform['maximumRelativeError'],syntheticCases=3,stdinJsonClean=True,exactInputAndAssemblyHashes=True,harnessSha256=native['provenance']['harnessSha256'],coreSha256=native['provenance']['coreSha256'],noArchivedCandidateEvaluations=True)
(out/'review-summary.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result,indent=2)); print('EVIDENCE_DIR='+str(out))
