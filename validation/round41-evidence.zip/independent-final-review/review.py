import collections,csv,hashlib,json,math,pathlib,sys
from fractions import Fraction
root=pathlib.Path('/workspace/scratch/8105054a3211');repo=root/'mvs_round41/MVS-analyzer-main';out=root/'mvs-r41-retained-analysis';dest=pathlib.Path(sys.argv[1]);archive=repo/'benchmark_history/1.4.0-engine-1.6.2-MVS-BENCH-1.2.0';ev=root/'mvs-r41-evidence'
def digest(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads(pathlib.Path(p).read_text(encoding='utf-8-sig'))
def rows(p):
 with pathlib.Path(p).open(encoding='utf-8-sig',newline='') as f: yield from csv.DictReader(f)
def key(r):return (r['condition'],r['phase'],r['replication_index'])
checksums={}
for line in (out/'SHA256SUMS.txt').read_text().splitlines():
 h,name=line.split('  '); assert name not in checksums and pathlib.Path(name).name==name; assert digest(out/name)==h;checksums[name]=h
assert len(checksums)==6
summary=read(out/'focused-family-summary.json'); comparison=read(out/'focused-family-comparison.json');provenance=read(out/'provenance.json');protocol=read(repo/'validation/focused-family-protocol-v1.json')
assert digest(repo/'validation/focused-family-protocol-v1.json')=='bc4841a2ca56bbc375a2a9b73659125388b38c9a428d960d057cb21917421563'
bindings=0
for b in summary['bindings'].values():
 if 'path' in b: assert digest(b['path'])==b['sha256'];bindings+=1
 else:
  for p,h in b.items():assert digest(p)==h;bindings+=1
for kind in ['fileBindings','protocolSourceBindings']:
 for b in provenance['source'][kind].values():assert digest(b['path'])==b['sha256'];bindings+=1
for name,h in protocol['inputSha256'].items():assert digest(archive/name)==h;bindings+=1
for name,h in protocol['sourceSha256'].items():assert digest(repo/name)==h;bindings+=1
assert summary['bindings']==comparison['bindings']
assert summary['newScientificVerdict'] is None and summary['candidateSelected'] is None and summary['scientificReadiness']=='NO-GO unchanged'
metrics=['median','standard_deviation','coefficient_of_variation','mad','iqr','normalized_mad','normalized_iqr','mean','rms','range','geometric_mean','trimmed_mean_20']
families={'all12':list(range(12)),'location4':[0,7,10,11],'variability7':[1,2,3,4,5,6,9],'absolute4':[1,3,4,9],'relative3':[2,5,6],'magnitude1':[8]};partition=['location4','absolute4','relative3','magnitude1']
reps={}
for r in rows(archive/'benchmark_replications.csv'):
 k=key(r);assert k not in reps;assert r['status']=='completed' and r['diagnostics_status']=='retained';reps[k]=r
assert len(reps)==5370
vectors=collections.defaultdict(list)
for r in rows(archive/'benchmark_replication_metrics.csv'):
 k=key(r);assert k in reps;v=vectors[k];assert r['metric']==metrics[len(v)]
 p=None if r['p_value']=='' else float(r['p_value']);available=r['observed_available']=='true'
 assert (p is not None)==available and (p is None or math.isfinite(p) and 0<=p<=1)
 v.append(p)
assert set(vectors)==set(reps) and all(len(v)==12 for v in vectors.values())
native=read(out/'focused-family-native.json');assert len(native['cases'])==5370
nativeMap={r['id']:r for r in native['cases']};assert len(nativeMap)==5370
caseEvents={};memberChecks=0
for k,pv in vectors.items():
 ident=json.dumps(k,separators=(',',':'));nr=nativeMap[ident];events={}
 def checkfamily(name,mult,actual):
  global memberChecks
  indices=families[name];expected=[]
  for i in indices:
   p=pv[i];a=None if p is None else min(1.,p*mult);r=a is not None and a<.05
   expected.append(dict(index=i,name=metrics[i],available=p is not None,rawP=p,adjustedP=a,rejected=r));memberChecks+=1
  assert actual['members']==expected and actual['fullDenominator']==len(indices) and actual['multiplier']==mult
  rej=[m['name'] for m in expected if m['rejected']];a=[m['adjustedP'] for m in expected if m['available']]
  assert actual['rejectedMembers']==rej and actual['anyRejected']==bool(rej) and actual['availableCount']==len(a) and actual['minAdjustedP']==(min(a) if a else None)
  return bool(rej)
 for name,idx in families.items():events[name]=checkfamily(name,len(idx),nr['families'][name])
 for name in partition:events['partition4.'+name]=checkfamily(name,4*len(families[name]),nr['simultaneousPartition']['families'][name])
 events['partition4.union']=any(events['partition4.'+n] for n in partition);assert events['partition4.union']==nr['simultaneousPartition']['anyRejected']
 events['uncontrolledFocusedUnion']=any(events[n] for n in partition);assert events['uncontrolledFocusedUnion']==nr['naiveFocusedUnion']['anyRejected']
 caseEvents[k]=events
assert memberChecks==230910
baselineChecks=0
for r in rows(archive/'benchmark_replication_procedures.csv'):
 if r['procedure'] in ['bonferroni','mvs_registry_corrected']:
  assert caseEvents[key(r)]['all12']==(r['rejected']=='true');baselineChecks+=1
assert baselineChecks==10740
bygroup=collections.defaultdict(list)
for k,e in caseEvents.items():bygroup[k[:2]].append(e)
assert len(bygroup)==20
reported={(r['condition'],r['phase']):r for r in summary['conditionPhaseSummaries']};assert set(bygroup)==set(reported)
methodComparisons=0;groups=[]
for group,events in bygroup.items():
 n=len(events);r=reported[group];assert r['requested']==n==r['completed']==r['analyzedCompleted'];assert r['failed']==r['notAnalyzed']==r['missingDiagnostics']==0
 counts={}
 for name in events[0]:
  s=sum(e[name] for e in events);g=sum(e[name] and not e['all12'] for e in events);l=sum(e['all12'] and not e[name] for e in events);counts[name]=s;mr=r['methods'][name]
  for ratekey in ['allRequested','completedOnly']:
   ar=mr[ratekey];assert ar['count']==s and ar['denominator']==n and ar['rate']==s/n
   z=1.959963984540054;ph=s/n;den=1+z*z/n;center=(ph+z*z/(2*n))/den;half=z/den*math.sqrt(ph*(1-ph)/n+z*z/(4*n*n));oracle=[max(0,center-half),min(1,center+half)]
   assert all(abs(a-b)<=2e-15 for a,b in zip(ar['wilson95'],oracle))
  pair=mr['pairedVersusAll12'];assert pair['candidateOnly']==g and pair['baselineOnly']==l and pair['requestedRateDelta']==(g-l)/n and pair['completedRateDelta']==(g-l)/n
  assert pair['bothRejected']==sum(e[name] and e['all12'] for e in events) and pair['neitherRejected']==sum(not e[name] and not e['all12'] for e in events)
  methodComparisons+=1
 groups.append(dict(condition=group[0],phase=group[1],requested=n,counts=counts))
assert methodComparisons==240
splits=list(rows(archive/'benchmark_stability_replications.csv'));assert len(splits)==120 and all(r['status']=='completed' for r in splits)
lookup={'exactMetric':{m:m for m in metrics},'registeredFamilyCoarsening':{metrics[i]:name for name in ['location4','variability7','magnitude1'] for i in families[name]},'partition4Coarsening':{metrics[i]:name for name in partition for i in families[name]}}
stability=[]
for label,mapping in lookup.items():
 r=summary['stability'][label];labels=r['labels'];index={m:i for i,m in enumerate(labels)};matrix=[[0]*len(labels) for _ in labels]
 for row in splits:matrix[index[mapping[row['top_left']]]][index[mapping[row['top_right']]]]+=1
 left=list(map(sum,matrix));right=[sum(row[i] for row in matrix) for i in range(len(labels))];matched=sum(matrix[i][i] for i in range(len(labels)));chance=Fraction(sum(a*b for a,b in zip(left,right)),120**2);obs=Fraction(matched,120);kappa=(obs-chance)/(1-chance)
 assert r['confusionMatrix']==matrix and r['agreement']['count']==matched and r['agreement']['denominator']==120
 assert abs(r['independentMarginalChanceAgreement']-float(chance))<1e-15 and abs(r['cohenKappa']-float(kappa))<1e-15
 stability.append(dict(method=label,matches=matched,total=120,exactExpectedAgreement=str(chance),expectedAgreement=float(chance),exactKappa=str(kappa),kappa=float(kappa)))
assert (ev/'native.stderr').stat().st_size==0
attempt1=(ev/'compare-attempt1.log').read_text();assert 'Unexpected files before comparison' in attempt1
assert comparison['status']=='passed' and comparison['nativeArithmeticAgreement'] and comparison['archivedBaselineAgreement'] and not comparison['failures']
headlines={g['condition']:g for g in groups if g['condition'] in ['primary_null','power_location_105','power_dispersion_130']}
result=dict(schemaVersion='mvs-focused-family-independent-final-review/v1',status='passed',scientificReadiness='NO-GO unchanged',scope='Read-only independent recomputation from archived CSV p-values and winner IDs; no native rerun, new observations or random draws',counts=dict(cases=5370,conditionPhases=20,memberResults=memberChecks,baselineDecisions=baselineChecks,aggregateMethodRows=methodComparisons,stabilitySplits=120),evidenceChecksumFilesVerified=len(checksums),additionalHashBindingsVerified=bindings,outputFileHashes=checksums,headlines=headlines,stability=stability,allConditionCounts=groups,retainedAttempt1=dict(reason='Extra empty stderr file caused the strict output-inventory gate to reject comparison; later comparison passed on retained native bytes',logSha256=digest(ev/'compare-attempt1.log'),nativeOutputSha256=digest(out/'focused-family-native.json'),nativeStderrBytes=0),limitations=['Posthoc development arithmetic, not confirmatory validation or scientific GO','Focused comparisons change the hypothesis family; weighted comparison changes alpha allocation','Family agreement is coarsened global winner agreement, not within-family ranking or candidate-set stability','Original archived stability statistic remains known-defective for joint ties and cannot be corrected from retained winner records alone'])
(dest/'review.json').write_text(json.dumps(result,indent=2)+'\n')
report='Independent R41 final review: PASS for engineering and diagnostic claims only.\n\n5370 archived cases, 230910 member calculations, 10740 baseline decisions and all240 condition/method summaries independently reconcile. All120 stability splits reconcile; registered-family agreement97/120, independent-marginal expected agreement61/75, kappa−3/112.\n\nPrimary-null counts: baseline18/1000; equal-family-budget union28/1000; uncontrolled union83/1000. Location1.05: location4 focused66/250; weighted union64/250; baseline35/250. Dispersion1.30: absolute4 focused109/250; weighted union71/250; baseline72/250. No scientific GO, production activation, or general error-control/power guarantee follows.\n\nThe initial comparison refusal for an extra empty stderr file is retained. No new native run or scientific sampling was performed for this review.\n'
(dest/'review.txt').write_text(report)
print(report);print('EVIDENCE_DIR='+str(dest));print('REVIEW_SHA256='+digest(dest/'review.json'))
