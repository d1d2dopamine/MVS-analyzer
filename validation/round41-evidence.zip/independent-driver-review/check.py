import hashlib,json,math,pathlib,subprocess,sys
repo=pathlib.Path('/workspace/scratch/8105054a3211/mvs_round41/MVS-analyzer-main'); sys.path.insert(0,str(repo/'validation'))
import focused_family_diagnostics as d
out=pathlib.Path(sys.argv[1]); driverHash=d.sha256(repo/'validation/focused_family_diagnostics.py'); testsHash=d.sha256(repo/'validation/test_focused_family_diagnostics.py')
archive=repo/'benchmark_history/1.4.0-engine-1.6.2-MVS-BENCH-1.2.0'; protocol=repo/'validation/focused-family-protocol-v1.json'; expected='bc4841a2ca56bbc375a2a9b73659125388b38c9a428d960d057cb21917421563'
p=d.validate_protocol(protocol,expected,repo,d.archived.source_hashes(archive)); assert p['scientificReadiness'].startswith('NO-GO')
cases=[]
for m in (1,3,4,7,12,16):
 b=.05/m
 for label,value in [('below',math.nextafter(b,0)),('at',b),('above',math.nextafter(b,1))]:
  cases.append(dict(id=f'boundary-{m}-{label}',pValues=[value]*12,available=[True]*12))
for label,value in [('zero',0.),('one',1.)]: cases.append(dict(id=label,pValues=[value]*12,available=[True]*12))
cases.append(dict(id='none',pValues=[None]*12,available=[False]*12))
for label,index,value in [('mad-only',3,.003),('rms-only',8,.02)]:
 values=[None]*12; mask=[False]*12; values[index]=value; mask[index]=True; cases.append(dict(id=label,pValues=values,available=mask))
inputs=dict(schemaVersion='mvs-focused-family-input/v1',cases=cases); raw=d.json_bytes(inputs)
base=pathlib.Path('/tmp/mvs-round41-focused-family-artifacts/bin/FocusedFamilyExperiment/release'); dll=base/'MvsAnalyzer.Core.Tests.dll'; core=base/'MvsAnalyzer.Core.dll'
result=subprocess.run(['/workspace/scratch/8105054a3211/mvs_r22_baseline/sdk/dotnet',str(dll),'--input','-'],input=raw,capture_output=True,timeout=120)
assert result.returncode==0 and not result.stderr
native=json.loads(result.stdout); reference=d.native_reference(inputs,hashlib.sha256(raw).hexdigest(),d.sha256(core),d.sha256(dll)); errors=d.exact_compare(reference,native); assert not errors,errors
# Independently hand-specified asymmetric 3-pair confusion: observed 2/3, chance4/9, kappa2/5.
rows=[dict(topLeft='median',topRight='median'),dict(topLeft='median',topRight='mad'),dict(topLeft='mad',topRight='mad')]
agreement=d.agreement(rows,('L','A'),{'median':'L','mad':'A'})
assert agreement['confusionMatrix']==[[1,1],[0,1]]
assert agreement['independentMarginalChanceAgreement']==4/9 and abs(agreement['cohenKappa']-.4)<1e-15
# Fisher/Binomial Wilson limits independent closed form for x=0,n=10.
z=1.959963984540054; assert abs(d.wilson(0,10)['wilson95'][1]-z*z/(10+z*z))<1e-15
assert d.sha256(repo/'validation/focused_family_diagnostics.py')==driverHash
assert d.sha256(repo/'validation/test_focused_family_diagnostics.py')==testsHash
(out/'synthetic-input.json').write_bytes(raw);(out/'synthetic-native.json').write_bytes(result.stdout)
summary=dict(status='passed',nativeSyntheticCases=len(cases),exactFieldAgreement=True,sourceProtocolHash=expected,protocolPinnedArchiveHashesValidated=True,productionSourceHashesValidated=True,driverSha256=driverHash,testsSha256=testsHash,handCheckedKappa=.4,knownWilsonBoundaryChecked=True,archivedCandidateEvaluations=0)
(out/'review-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2));print('EVIDENCE_DIR='+str(out))
