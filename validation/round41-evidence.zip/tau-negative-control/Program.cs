using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
var path = args[0];
var a = Assembly.LoadFrom(path);
var t = a.GetType("MvsAnalyzer.Benchmarking.BenchmarkMath", true)!;
var method = t.GetMethod("KendallTau", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic)!;
var cases = new (string Id, double[] Left, double[] Right, double? StandardExpected)[] {
 ("identical_joint_ties", new double[]{1,1,2}, new double[]{1,1,2}, 1),
 ("reversed_joint_ties", new double[]{1,1,2}, new double[]{2,2,1}, -1),
 ("both_constant", new double[]{1,1,1}, new double[]{1,1,1}, null),
 ("identical_distinct_control", new double[]{1,2,3}, new double[]{1,2,3}, 1),
 ("identical_extreme_finite", new double[]{-double.MaxValue,0,double.MaxValue}, new double[]{-double.MaxValue,0,double.MaxValue}, 1),
 ("identical_subnormal", new double[]{0,double.Epsilon,2*double.Epsilon}, new double[]{0,double.Epsilon,2*double.Epsilon}, 1)
};
var rows = cases.Select(c => {
  double value = (double)method.Invoke(null, new object[]{c.Left,c.Right})!;
  return new {caseId=c.Id, left=c.Left, right=c.Right, nativeValue=double.IsFinite(value) ? (double?)value : null,
    nativeStatus=double.IsNaN(value) ? "NaN" : double.IsInfinity(value) ? "Infinity" : "finite",
    standardExpected=c.StandardExpected,
    matchesExpected=c.StandardExpected.HasValue ? value==c.StandardExpected.Value : double.IsNaN(value)};
}).ToArray();
Console.WriteLine(JsonSerializer.Serialize(new {
  purpose="Read-only deterministic reflection counterexamples; no scientific simulation or source change",
  assemblyPath=path, assemblySha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path))).ToLowerInvariant(),
  assemblyMvid=a.ManifestModule.ModuleVersionId.ToString(), runtime=System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,
  method=method.ToString(), cases=rows
}, new JsonSerializerOptions{WriteIndented=true}));
