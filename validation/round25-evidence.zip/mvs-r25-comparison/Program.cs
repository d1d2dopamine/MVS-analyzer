using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using MvsAnalyzer;

internal record Snapshot(List<Observation> Observations, string Summary, string EncodingName, bool SequenceWasProvided, string SourceSha256);
internal static class Program
{
 static string Hash(byte[] b)=>Convert.ToHexString(SHA256.HashData(b)).ToLowerInvariant();
 static Snapshot Import(string path, ImportProfile? profile=null, bool single=false)
 {
#if NEW_IMPORT
  var r=CsvImporter.Import(path,-10000,10000,profile,single);
  return new(r.Observations,r.Summary,r.EncodingName,r.SequenceWasProvided,r.SourceSha256);
#else
  var r=CsvImporter.Read(path,-10000,10000,profile,single);
  return new(r,CsvImporter.LastImportSummary,CsvImporter.LastEncodingName,CsvImporter.LastSequenceWasProvided,OutputExporter.HashFile(path));
#endif
 }
 static void Print(object value)=>Console.WriteLine(JsonSerializer.Serialize(value));
 static void Main(string[] args)
 {
  if(args[0]=="timing") {
   for(int i=0;i<2;i++) Import(args[1]);
   GC.Collect();GC.WaitForPendingFinalizers();GC.Collect();
   long allocated=GC.GetAllocatedBytesForCurrentThread(); int g0=GC.CollectionCount(0),g1=GC.CollectionCount(1),g2=GC.CollectionCount(2);
   var sw=Stopwatch.StartNew();var r=Import(args[1]);sw.Stop();
   Print(new{ElapsedMs=sw.Elapsed.TotalMilliseconds,AllocatedBytes=GC.GetAllocatedBytesForCurrentThread()-allocated,Gen0=GC.CollectionCount(0)-g0,Gen1=GC.CollectionCount(1)-g1,Gen2=GC.CollectionCount(2)-g2,Rows=r.Observations.Count,r.SourceSha256,Runtime=Environment.Version.ToString(),Processors=Environment.ProcessorCount});return;
  }
  var dir=args[1]; Directory.CreateDirectory(dir);
  if(args[0]=="probe") { Probe(dir);return; }
  var profile=new ImportProfile("comparison","comparison","external",';',true,new(){["entity"]=new[]{"who"},["group"]=new[]{"armname"},["value"]=new[]{"score"}});
  foreach(var path in Directory.GetFiles(dir,"*.csv").OrderBy(x=>x,StringComparer.Ordinal)) {
   try {Print(new{Fixture=Path.GetFileName(path),Result=Import(path,Path.GetFileName(path).StartsWith("profile")?profile:null,Path.GetFileName(path).StartsWith("single")),ExpectedRawHash=Hash(File.ReadAllBytes(path))});}
   catch(Exception e){Print(new{Fixture=Path.GetFileName(path),Error=e.GetType().Name,Message=e.Message});}
  }
 }
 static void Probe(string dir) {
  var path=Path.Combine(dir,"replace.csv"); var a=Encoding.UTF8.GetBytes("entity,group,value,sequence\nx,A,1,7\ny,B,2,8\n"); var b=Encoding.Unicode.GetPreamble().Concat(Encoding.Unicode.GetBytes("entity,group,value,sequence\nx,A,9,bad\ny,B,8,bad\nz,B,7,bad\n")).ToArray(); File.WriteAllBytes(path,a);
#if NEW_IMPORT
  var held=Import(path);var before=new{held.Summary,held.EncodingName,held.SequenceWasProvided};File.WriteAllBytes(path,b);var later=Import(path);var after=new{held.Summary,held.EncodingName,held.SequenceWasProvided};
  Print(new{Probe="replace-after-import",ConsumedHash=Hash(a),ReportedHash=held.SourceSha256,CurrentPathHash=OutputExporter.HashFile(path),Correct=held.SourceSha256==Hash(a)});
  Print(new{Probe="interleaved-metadata",Before=before,After=after,Other=new{later.Summary,later.EncodingName,later.SequenceWasProvided},Isolated=before.Equals(after)&&!before.Equals(new{later.Summary,later.EncodingName,later.SequenceWasProvided})});
#else
  var observations=CsvImporter.Read(path,-10000,10000);var before=new{Summary=CsvImporter.LastImportSummary,EncodingName=CsvImporter.LastEncodingName,SequenceWasProvided=CsvImporter.LastSequenceWasProvided};File.WriteAllBytes(path,b);var reported=OutputExporter.HashFile(path);
  Print(new{Probe="replace-after-import",ConsumedHash=Hash(a),ReportedHash=reported,CurrentPathHash=OutputExporter.HashFile(path),Correct=reported==Hash(a),ConsumedValues=observations.Select(x=>x.Value).ToArray()});
  CsvImporter.Read(path,-10000,10000);var after=new{Summary=CsvImporter.LastImportSummary,EncodingName=CsvImporter.LastEncodingName,SequenceWasProvided=CsvImporter.LastSequenceWasProvided};
  Print(new{Probe="interleaved-metadata",Before=before,After=after,Isolated=before.Equals(after)});
#endif
 }
}
