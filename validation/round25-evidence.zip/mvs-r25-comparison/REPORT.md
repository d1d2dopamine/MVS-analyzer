# Round 25: source-bound import evidence

## Result
All 17 frozen stable-file fixtures had exact old/new equality of every observation field and ordering, summary, selected encoding, sequence flag, raw-byte SHA-256, and exception type/message for rejected inputs. Candidate hashes also match independently hashed fixture bytes. No scientific formulas or decision thresholds are tested or changed here; this is an engineering boundary comparison, not a scientific power holdout or full BENCH.

Two deterministic baseline failures were reproduced and corrected:

- Path replacement after parsing: old import consumed A with values [1,2] and SHA-256 d0c2d097a84dd304b193cfc6230d7739af965fd3eeea3e85dab85461ed7ac802, then the separate pathname hash reported B's 1fea8644d4dabe5745546f4e52613ce2a1cbcee4120c042dced523b34cefa2b3. Candidate result retained A's hash after the same replacement, while independent current-path hash showed B. This models the old parse/rehash call boundary deterministically; it does not claim an atomic snapshot under writes during a read.
- Interleaved metadata: after A (UTF-8, 2 rows, supplied sequence) and B (UTF-16LE BOM, 3 rows, fallback sequence), baseline Last* metadata described B. Candidate A retained all its original metadata and B had distinct correct metadata. Result observations remain a mutable caller-owned List; metadata isolation is not a claim of deep immutability.

## Frozen timing results
Same Release net8.0 harness, .NET runtime 8.0.31, two CPUs, taskset affinity 0,1; two warmups and seven alternating AB/BA paired measurements per size, with two untimed imports inside each process. Baseline boundary includes Read + OutputExporter.HashFile; candidate includes Import. These measure the requested replaced boundary, not bare parser speed.

| Rows | Baseline median ms | Candidate median ms | Candidate / baseline | Baseline median allocated bytes | Candidate median allocated bytes |
|---:|---:|---:|---:|---:|---:|
| 4,500 | 27.8576 | 28.0906 | 1.0084 | 4,626,232 | 4,625,608 |
| 45,000 | 106.7160 | 127.7860 | 1.1974 | 45,788,128 | 45,787,496 |
| 150,000 | 341.5615 | 277.0545 | 0.8111 | 150,479,224 | 150,478,584 |

Median GC counts (generation 0/1/2): 4,500 baseline/candidate both 1/0/0; 45,000 both 7/4/2; 150,000 baseline 22/9/2, candidate 22/10/2. Full raw samples, including allocation and GC variation, are in timings.jsonl. Allocation is essentially unchanged. There is no >20% median slowdown at 150,000 rows requiring the protocol's regression investigation.

Timing was launched about 13:54:11 UTC on 2026-10-16 and completed by 13:54:55 UTC. The parent subsequently confirmed a separate native build was active until approximately 13:54:20, followed by the full native test harness from 13:54:21 through 13:55:00 UTC (interrupted with exit 130). Thus competing work overlapped essentially the entire comparison window, including the large-input measurements. Per-sample timestamps were not captured, so exact sample-to-contention attribution cannot be reconstructed; sample order is preserved. These are contended-host observations, not isolated performance estimates. The timing run was not repeated or filtered. The mixed size-dependent results and short-process/JIT/GC/host noise do not support a general speedup claim. The robust conclusion is corrected hash/metadata association with exact frozen fixture parity, and no observed large-input threshold regression in this run.

## Evidence and reproducibility
- PROTOCOL.md and PROTOCOL.sha256: frozen pre-timing specification; SHA-256 4aaba5d22d995d4d41785f4b958033d245365f1c715f309e8a8a1239559bb86f.
- Program.cs, Comparison.csproj, run_comparison.py, HARNESS.sha256: identical external harness compiled against old/new Core; pre-timing checksums verified immediately before execution.
- HARNESS-NOTES.md: disclosed pre-timing adapter and assertion corrections; protocol never rewritten.
- fixtures-sha256.json and fixtures/: frozen deterministic fixture bytes; timing fixtures are reproducible from run_comparison.py with seed 25023.
- old-correctness.jsonl, new-correctness.jsonl, old-probes.jsonl, new-probes.jsonl: actual correctness and counterexample records.
- timings.jsonl, summary.json, environment.json, affinity.txt: all 42 observations, medians, SDK/runtime metadata and CPU configuration.

To reproduce in a suitable SDK environment, build Comparison.csproj in Release with CoreProject pointing at the baseline Core csproj and output old-bin. Build again with CoreProject pointing at candidate Core, NewImport=true, and output new-bin. Run `taskset -c 0,1 python run_comparison.py` with DOTNET_PROCESSOR_COUNT=2. Do not rerun just to improve timing. Candidate uses flat result properties as confirmed by its implementation. A frozen protocol comparison is only valid against the recorded implementation version; later parser changes require explicit new evidence.
