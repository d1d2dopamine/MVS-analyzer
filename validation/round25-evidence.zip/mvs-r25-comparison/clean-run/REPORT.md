# Clean repetition: Round 25 import boundary

The single prospectively authorized clean repetition completed successfully. Its exact measured window was 2026-10-16 14:01:43.465–14:02:13.528 UTC, after the parent confirmed all native tests, CLI parity, Python checks, and CLI safety work had finished and reviewers would not launch builds/tests. No competing build/test work was reported during this window. CPU affinity remained 0,1 with DOTNET_PROCESSOR_COUNT=2.

All 17 stable-file fixture outputs again matched exactly, and both deterministic candidate provenance/metadata probes passed. The frozen harness, both implementation binaries, fixture inputs, protocol, warmups, sizes, seven alternating pairs, allocation/GC measurements, and thresholds were unchanged. All 42 clean samples were retained. This is an engineering import-boundary comparison, not a scientific power benchmark or full BENCH.

| Rows | Baseline median ms | Candidate median ms | Candidate / baseline | Baseline median allocated bytes | Candidate median allocated bytes |
|---:|---:|---:|---:|---:|---:|
| 4,500 | 28.0037 | 27.1021 | 0.9678 | 4,626,232 | 4,625,608 |
| 45,000 | 91.5200 | 89.8711 | 0.9820 | 45,788,128 | 45,787,512 |
| 150,000 | 239.3787 | 234.3617 | 0.9790 | 150,479,240 | 150,478,576 |

Median GC generation 0/1/2 counts: 4,500 both 1/0/0; 45,000 both 7/4/2; 150,000 baseline 22/9/2 and candidate 22/10/2. Allocation is essentially unchanged. Candidate medians were 1.8–3.2% lower in this one clean repetition; these small differences do not establish a general speedup. The supported interpretation is corrected provenance/metadata association, exact fixture parity, and no observed material import-boundary performance regression. The prespecified >20% median-slowdown trigger at 150,000 rows was not met.

## Repetition disclosure
The original frozen protocol prohibited rerunning to green. Its first full 42-sample execution overlapped a native build and full native test harness, contaminating essentially the whole window. That original execution, all its samples, and its corrected disclosure remain unchanged in the parent directory as exploratory evidence. Before this repetition began, the root explicitly required one complete clean repetition due to independently confirmed contention. RERUN-RATIONALE.md records this prospective amendment; the original protocol itself was not rewritten. No favorable samples were selected, no parameters were tuned, and no further repetition was run.

Use this clean repetition for primary timing interpretation while preserving both runs separately. The original contended medians were baseline/candidate 27.8576/28.0906 ms, 106.7160/127.7860 ms, and 341.5615/277.0545 ms for the three sizes. Differences between contaminated and clean results reinforce why strong speedup claims would be inappropriate.

## Evidence
- timings.jsonl: all 42 clean observations, allocation and GC deltas.
- summary.json: medians and exact-fixture-parity result.
- sample-observed-times.jsonl: external timestamps when each flushed measurement record was observed, with 25 ms polling. These are approximate completion observations, not exact import start/end times.
- clean-window.json: actual start/end, exclusive-window authorization, observed count, exit status, CPU affinity, and contention disclosure.
- environment.json: SDK/runtime and frozen source/protocol checksums.
- old/new correctness and probe JSONL: stable parity and deterministic defect evidence.
- HARNESS.sha256 and IMPLEMENTATION-BINARIES.sha256: exact source and binary identities, verified before execution.
- RERUN-RATIONALE.md: prospective repetition authorization and unchanged design.

No source edits were made to either project by this comparison worker. The candidate result metadata are isolated, while its observations remain a caller-owned mutable List; this does not promise a transactional filesystem snapshot during concurrent writes.
