# Prospective clean repetition rationale

Recorded 2026-10-16 13:58 UTC, before any clean-run measurement.

The first full 42-sample run is preserved in the parent directory. A separate native build and full native test harness overlapped essentially its entire measurement window. That run remains exploratory contended-host evidence; its values are neither discarded nor filtered.

At the root agent’s explicit request, perform one complete clean repetition after the parent signals an exclusive CPU window. This is a prospective amendment to the original no-rerun protocol, justified by confirmed execution contamination, not by obtaining a favorable timing result. The original frozen protocol remains unchanged and its no-rerun deviation is disclosed here. No measurements start before the exclusive-window signal.

Use identical binaries, harness source/checksums, deterministic fixture bytes, SDK, CPU affinity 0,1, DOTNET_PROCESSOR_COUNT=2, sizes 4,500/45,000/150,000, two warmups, seven alternating AB/BA pairs, and two untimed within-process imports. Keep all 42 clean samples regardless of outcome. No new tuning, sample selection, threshold adjustment, extra repetitions, or scientific-model changes. Report both runs separately; use the clean repetition for the primary performance interpretation and disclose any new contention. Correctness remains required before timing.
