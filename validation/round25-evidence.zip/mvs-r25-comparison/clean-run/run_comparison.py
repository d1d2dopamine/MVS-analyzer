#!/usr/bin/env python3
"""External frozen comparison driver; run after both binaries are built."""
import hashlib,json,pathlib,random,statistics,subprocess,sys,platform,os
ROOT=pathlib.Path(__file__).resolve().parent
FIX=ROOT/'fixtures'; FIX.mkdir(exist_ok=True)
base='entity,group,value,sequence\nx,A,1.25,7\ny,B,2.5,8\n'
fixtures={'utf8-lf':base.encode(),'utf8-crlf':base.replace('\n','\r\n').encode(),'utf8-bom':base.encode('utf-8-sig'),'utf16le-bom':b'\xff\xfe'+base.encode('utf-16le'),'utf16be-bom':b'\xfe\xff'+base.encode('utf-16be'),'utf16le':base.encode('utf-16le'),'utf16be':base.encode('utf-16be'),'cp1251':base.replace('x,A','прибор,первая').replace('y,B','датчик,вторая').encode('cp1251'),'profile-decimal':'who;armname;score\nx;A;1.234,56\ny;B;2,5\n'.encode(),'mixed-invalid':'entity,group,value,sequence\nx,A,1,1\ny,B,2,2\nz\nz,A,NaN,4\nz,A,20000,5\n,A,3,6\nz,A,4,bad\n'.encode(),'sequence-absent':'entity,group,value\nx,A,1\nx,A,2\ny,B,3\n'.encode(),'sequence-fallback':base.replace('2.5,8','2.5,bad').encode(),'empty':b'','malformed-header':b'id,foo,bar\nx,A,1\n','unterminated':b'entity,group,value\n"x,A,1\n','quoted-multiline':b'entity,group,value\n"x,1",A,1\n"y\n2",B,2\n','single-group':b'entity,group,value\nx,A,1\ny,A,2\n'}
for name,data in fixtures.items():(FIX/(name+'.csv')).write_bytes(data)
for size in (4500,45000,150000):
 rng=random.Random(25023); p=ROOT/f'timing-{size}.csv'
 with p.open('w',newline='') as f:
  f.write('entity,group,value,sequence\n')
  for i in range(size):f.write(f'e{i//3},g{i%3},{rng.randrange(1000000)/1000:.3f},{i//3+1}\n')
manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(list(FIX.glob('*.csv'))+list(ROOT.glob('timing-*.csv')))}
(ROOT/'fixtures-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
if len(sys.argv)>1 and sys.argv[1]=='prepare':sys.exit(0)
def run(side,*args):
 return subprocess.check_output(['dotnet',str(ROOT/(side+'-bin')/'MvsAnalyzer.Core.Tests.dll'),*map(str,args)],text=True)
for side in ('old','new'):
 (ROOT/(side+'-correctness.jsonl')).write_text(run(side,'correctness',FIX))
 (ROOT/(side+'-probes.jsonl')).write_text(run(side,'probe',ROOT/('probe-'+side)))
old=[json.loads(l) for l in (ROOT/'old-correctness.jsonl').read_text().splitlines()];new=[json.loads(l) for l in (ROOT/'new-correctness.jsonl').read_text().splitlines()]
assert old==new, 'Stable-fixture correctness mismatch; timing stopped'
assert all(r['Result']['SourceSha256']==r['ExpectedRawHash'] for r in new if 'Result' in r)
assert all(r.get('Correct',r.get('Isolated')) for r in map(json.loads,(ROOT/'new-probes.jsonl').read_text().splitlines()))
metadata={'platform':platform.platform(),'dotnet':subprocess.check_output(['dotnet','--info'],text=True),'cpuBudget':os.environ.get('DOTNET_PROCESSOR_COUNT'),'protocolSha256':hashlib.sha256((ROOT/'PROTOCOL.md').read_bytes()).hexdigest(),'harnessSha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ('Program.cs','Comparison.csproj','run_comparison.py')}}
(ROOT/'environment.json').write_text(json.dumps(metadata,indent=2)+'\n')
records=[]
with (ROOT/'timings.jsonl').open('w') as out:
 for size in (4500,45000,150000):
  p=ROOT/f'timing-{size}.csv'
  for side in ('old','new'):
   for warmup in range(2):run(side,'timing',p)
  for pair in range(7):
   for side in (('old','new') if pair%2==0 else ('new','old')):
    r=json.loads(run(side,'timing',p)); r.update(Size=size,Pair=pair+1,Side=side);records.append(r);out.write(json.dumps(r)+'\n');out.flush()
summary=[]
for size in (4500,45000,150000):
 row={'Size':size}
 for side in ('old','new'):
  values=[r for r in records if r['Size']==size and r['Side']==side]
  row[side]={key:statistics.median(r[key] for r in values) for key in ('ElapsedMs','AllocatedBytes','Gen0','Gen1','Gen2')}
 row['candidateToBaselineTimeRatio']=row['new']['ElapsedMs']/row['old']['ElapsedMs'];summary.append(row)
(ROOT/'summary.json').write_text(json.dumps({'stableFixtures':len(old),'exactParity':True,'timingMedians':summary},indent=2)+'\n')
print(json.dumps(summary,indent=2))
