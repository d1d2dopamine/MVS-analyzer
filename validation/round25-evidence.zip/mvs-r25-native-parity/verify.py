import pathlib,json,hashlib,datetime,importlib.util
R=pathlib.Path(__file__).resolve().parent
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(),parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
spec=importlib.util.spec_from_file_location('parity',R.parent/'mvs_round25/MVS-analyzer-main/tools/test_scientific_cli_parity.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
checks=[]; failures=[]
def check(label,fn):
 try:fn();checks.append(label)
 except Exception as e:failures.append({'check':label,'error':str(e)})
def equal(a,b):m.compare_value(a,b,0,0)
def artifact(p,size,sha):m.verify_file(p,size,sha)
p=read(R/'frozen_protocol.json')
for name,h in p['inputs'].items():check('frozen input '+name,lambda n=name,h=h:equal(H(R/'inputs'/n),h))
for x in read(R/'runs.json'):check(f"expected exit {x['side']} {x['case']}",lambda x=x:equal(x['expected'],True))
for case in ['calibration','analysis','variance','melsm','negative_variance','negative_sequence']:
 payloads=[read(R/'logs'/side/case/'stdout.json') for side in ['baseline23','candidate25']]
 for side,pay in zip(['baseline23','candidate25'],payloads):
  for item in pay['artifacts']:
   path=pathlib.Path(item['path']);check(f'{side} {case} own hash/size {item["name"]}',lambda p=path,i=item:artifact(p,i['sizeBytes'],i['sha256']))
  if pay['manifestPath']:
   man=read(pathlib.Path(pay['manifestPath']));out=pathlib.Path(pay['outputDirectory'])
   for item in man['files']:
    check(f'{side} {case} manifest hash/size {item["FileName"]}',lambda o=out,i=item:artifact(o/i['FileName'],i['SizeBytes'],i['sha256']))
   inp=next(x['cmd'][x['cmd'].index('--in')+1] for x in p['commands'] if x['side']==side and x['case']==case)
   check(f'{side} {case} manifest input hash',lambda man=man,inp=inp:equal(man['inputData']['sha256'],H(pathlib.Path(inp))))
   check(f'{side} {case} manifest runId',lambda man=man,pay=pay:equal(man['runId'],pay['runId']))
   check(f'{side} {case} manifest timestamp',lambda man=man:datetime.datetime.fromisoformat(man['created'].replace('Z','+00:00')))
 check(case+' machine scientific/status fields',lambda:equal(*[{k:v for k,v in pay.items() if k not in ['outputDirectory','manifestPath','runId','artifacts']} for pay in payloads]))
 check(case+' artifact names',lambda:equal(*[[i['name'] for i in pay['artifacts']] for pay in payloads]))
 if case.startswith('negative'):
  for pay in payloads:check(case+' no output',lambda pay=pay:equal([pay['outputDirectory'],pay['manifestPath'],pay['artifacts']],[None,None,[]]))
  continue
 dirs=[pathlib.Path(pay['outputDirectory']) for pay in payloads]
 for name in [i['name'] for i in payloads[0]['artifacts']]:
  paths=[d/name for d in dirs]
  if name=='calibration_state.json':
   for path in paths:
    state=read(path); raw=path.read_text(); expected=state['PayloadHash']
    check(str(path.relative_to(R))+' payload checksum',lambda raw=raw,expected=expected:equal(hashlib.sha256(raw.replace('\"PayloadHash\": \"'+expected+'\"','\"PayloadHash\": \"\"').encode()).hexdigest(),expected))
   check(case+' state all scientific fields',lambda paths=paths:equal(*[{k:v for k,v in read(p).items() if k not in ['CreatedUtc','PayloadHash']} for p in paths]))
  elif name=='run_manifest.json':
   check(case+' manifest scientific fields',lambda paths=paths:equal(*[{k:v for k,v in read(p).items() if k not in ['created','runId','files']} for p in paths]))
  else:check(case+' exact artifact bytes '+name,lambda paths=paths:equal(*[H(p) for p in paths]))
 if case in ['variance','melsm']:
  for side,d in zip(['baseline23','candidate25'],dirs):
   report=read(d/f'{case}_report.json')
   for name,key in m.TABLES[case]:check(f'{side} {case} CSV/report {name}',lambda d=d,name=name,key=key,report=report:m.read_table(d/name,report[key],**({'expected_columns':m.RANDOM_COLUMNS} if key=='RandomEffects' else {})))
result={'passed':len(checks),'failed':len(failures),'failures':failures,'checks':checks,'tolerance':0,'scope':'Actual same-native-engine baseline23/candidate25 bounded consistency, not scientific validity','protocolSha256':H(R/'frozen_protocol.json')}
(R/'verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
