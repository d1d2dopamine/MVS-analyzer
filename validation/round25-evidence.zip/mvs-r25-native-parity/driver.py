import pathlib,json,hashlib,subprocess,time,csv,os,shutil,sys
R=pathlib.Path(__file__).resolve().parent; W=R.parent
H=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def write(p,o):p.write_text(json.dumps(o,indent=2)+'\n')
def freeze():
 (R/'inputs').mkdir()
 src=W/'mvs_round25/MVS-analyzer-main/examples'
 shutil.copyfile(src/'demo_three_groups.csv',R/'inputs/demo_three_groups.csv')
 with (R/'inputs/small.csv').open('w') as f:
  w=csv.writer(f,lineterminator='\n');w.writerow(['entity','group','value','sequence','variable','unit'])
  for g in range(2):
   for e in range(8):
    for t in range(6):w.writerow([f'G{g}E{e}',f'G{g}',10+g*2+e*.31+((e*7+t*3)%11)*.17+t*.07,t+1,'outcome','unit'])
 with (R/'inputs/no_sequence.csv').open('w') as f:
  w=csv.writer(f,lineterminator='\n')
  for row in csv.reader((R/'inputs/small.csv').open()):w.writerow(row[:3]+row[4:])
 cases=[('calibration','calibrate','demo_three_groups.csv',['--repetitions','100','--seed','20260719'],[0],300),('analysis','analyze','demo_three_groups.csv',['--calibration','{side}/calibration'],[0],120),('variance','variance','small.csv',['--repetitions','100','--bootstrap','99','--seed','20260719'],[0,2],180),('melsm','melsm','small.csv',['--no-random-scale','--mean-time','--scale-time','--quadrature','7','--max-iterations','400'],[0,2],90),('negative_variance','variance','small.csv',['--repetitions','99'],[1],20),('negative_sequence','melsm','no_sequence.csv',['--mean-time'],[1],20)]
 commands=[]
 for label,round in [('baseline23',23),('candidate25',25)]:
  cli=W/f'mvs_round{round}/MVS-analyzer-main/MvsAnalyzer.Cli/bin/Release/net8.0/mvs'
  for name,verb,inp,opts,exits,timeout in cases:
   out=R/label/name
   cmd=[str(cli),verb,'--in',str(R/'inputs'/inp),'--out',str(out),'--json','--quiet']+[x.replace('{side}',str(R/label)) for x in opts]
   commands.append(dict(side=label,case=name,cmd=cmd,expectedExit=exits,timeout=timeout))
 write(R/'frozen_protocol.json',dict(scope='Bounded same-engine unchanged-science comparison; no scientific validity claim',commands=commands,inputs={p.name:H(p) for p in (R/'inputs').iterdir()},binaries={x['side']:H(pathlib.Path(x['cmd'][0]).with_name('MvsAnalyzer.Core.dll')) for x in commands},exclusions={'calibration_state.json':['CreatedUtc'],'run_manifest.json':['created','runId','files (separately hash/size validated)'],'machine_stdout':['outputDirectory','manifestPath','runId','artifacts (separately hash/size validated)']},numericTolerance=0,cpus=2))
def run():
 p=json.loads((R/'frozen_protocol.json').read_text());results=[]
 if (R/'logs').exists():raise FileExistsError('Retain existing evidence; reproduce by copying driver.py and verify.py into a fresh sibling directory then freeze/run.')
 for name,h in p['inputs'].items():assert H(R/'inputs'/name)==h
 for x in p['commands']:assert H(pathlib.Path(x['cmd'][0]).with_name('MvsAnalyzer.Core.dll'))==p['binaries'][x['side']]
 for x in p['commands']:
  logs=R/'logs'/x['side']/x['case'];logs.mkdir(parents=True)
  env=os.environ.copy();env.update(DOTNET_PROCESSOR_COUNT='2',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2',MVS_BACKUP_DIR=str(R/'backups'/x['side']),XDG_DATA_HOME=str(R/'data'/x['side']),XDG_CONFIG_HOME=str(R/'config'/x['side']))
  start=time.monotonic()
  with (logs/'stdout.json').open('w') as out,(logs/'stderr.txt').open('w') as err:
   try:code=subprocess.run(x['cmd'],stdout=out,stderr=err,env=env,timeout=x['timeout']).returncode
   except subprocess.TimeoutExpired:code='TIMEOUT'
  row=dict(side=x['side'],case=x['case'],exit=code,seconds=time.monotonic()-start,expected=code in x['expectedExit']);results.append(row);write(R/'runs.json',results);print(json.dumps(row),flush=True)
 print('COMPUTE FINISHED',flush=True)
if __name__=='__main__':globals()[sys.argv[1]]()
