Actual baseline23/candidate25 native CLI parity

Result: 152 verification checks pass, zero fail; numeric tolerance zero.
12 actual serial CLI runs: each side calibration (100 repetitions, seed 20260719), analyze using its newly generated calibration, variance (100 repetitions, bootstrap 99, seed 20260719), analytic MELSM (no random scale; explicit sequence; mean/scale time; quadrature 7; max iterations 400), invalid variance repetitions 99, and MELSM time without sequence. First four exit 0, negatives exit 1, on both sides. CPU-related environment limits all 2. Full stdout/stderr and artifacts retained. Runs took about 15 seconds total; timings are operational records, not controlled performance comparisons.

Inputs and exact commands were frozen in frozen_protocol.json before execution. Demo source bytes copied unchanged; small.csv deterministically generated as 2 groups x 8 globally unique entities x 6 repeats (96 observations); no_sequence.csv drops only the sequence column. Source binaries/core checksums retained in protocol. No project files changed.

Exact comparisons: 16 corresponding nonvolatile export files byte-identical, including calibration CSVs, results JSON/CSV, metric availability, data quality, variance report and CSVs, MELSM report and CSVs. All scientific manifest fields, formula/input/settings/environment hashes, machine result statuses/diagnostics, nulls, arrays/order, numbers exact. 42 machine artifact hash/size entries and 28 manifest artifact hash/size entries independently validated. Variance/MELSM CSV fields reconciled with their raw JSON reports. Four calibration-state PayloadHash values independently recomputed and validated.

Volatile exclusions: machine stdout root outputDirectory, manifestPath, runId and artifacts (artifact names compared and hashes/sizes independently validated); run_manifest.json root created, runId, files (files independently verified); calibration_state.json root CreatedUtc and its derived PayloadHash (independently verified). No scientific number tolerance or blanket recursive exclusions.

Transparency: initial verification_initial.json retained with 146 pass / 2 fail because PayloadHash includes CreatedUtc. comparison_amendment.json explains the source-verified dependency. No reruns, input changes, seed tuning, convergence tuning, or scientific-field exclusions followed this finding.

Recheck without models:
  PYTHONDONTWRITEBYTECODE=1 python /workspace/scratch/8105054a3211/mvs-r25-native-parity/verify.py

Reproduce (fresh sibling evidence directory; never overwrite retained runs):
  source /workspace/scratch/8105054a3211/mvs_r22_baseline/env.sh
  mkdir /workspace/scratch/8105054a3211/mvs-r25-native-parity-reproduction
  cp /workspace/scratch/8105054a3211/mvs-r25-native-parity/{driver.py,verify.py} /workspace/scratch/8105054a3211/mvs-r25-native-parity-reproduction/
  python /workspace/scratch/8105054a3211/mvs-r25-native-parity-reproduction/driver.py freeze
  python /workspace/scratch/8105054a3211/mvs-r25-native-parity-reproduction/driver.py run
  python /workspace/scratch/8105054a3211/mvs-r25-native-parity-reproduction/verify.py

Scope: bounded same-engine unchanged-science consistency evidence only. One seed/input/options set, low simulation budget, analytic MELSM only. Not full benchmark, not independent scientific validation, no change to NO-GO scientific-release status.
