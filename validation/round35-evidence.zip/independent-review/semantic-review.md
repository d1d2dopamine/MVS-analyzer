# Round35 independent bounded source-pin review

## Conclusion

No blocking contradiction was found in the reviewed current contract or the five requested current-source roles. The final candidate independently passed 24 focused source-pin tests, 48 Colab connection tests, and 18 UI source tests, with no skips and Node v24.19.0. Raw command output and machine-readable checks are retained beside this report.

This supports a new, explicitly reviewed current-source baseline. It does not reconstruct four missing older transitions, authenticate historical approvals, or establish scientific validity. Scientific NO-GO and platform/runtime acceptance limits are unchanged. No production source was edited, native computation executed, or scientific benchmark rerun by this reviewer.

## Validation contract review

- Both older manifests are byte-identical to Round34 and independently pinned by literal test hashes.
- The new overlay contains exactly 17 named revisions. Exactly four known historical gaps remain machine-visible: CliArguments, HeadlessRun, CLI csproj, ScientificCommands. Thirteen records trace from the effective legacy expected hash, without claiming to re-prove older original-to-checkpoint changes.
- All three manifests and every record are loaded and validated before any result is returned, including requests for an untouched source.
- Duplicate JSON keys, missing manifests, malformed JSON/encoding/hashes, noncanonical or unknown paths, control characters, malformed schema/review data, caller/original-anchor mismatches, and broken prior-effective chains are rejected.
- Explicit SourcePinError checks remain active under optimized Python. The helper reads manifest bytes but never derives expected values from production source bytes.
- Existing consumers still compare actual source bytes for all 30 protected files. Synthetic mutation tests reject revised and untouched source drift; removing source cannot manufacture a new expected hash.
- Evidence path existence is checked by repository tests. The validator checks provenance record structure, not historical truth. A local owner controlling code, tests and manifests can rewrite all three; these are integrity/review gates, not cryptographic attestation.

## Current semantic review

Line references below refer to the Round34 source, byte-identical to the final candidate.

### Infrastructure/CliArguments.cs

Observed invariants:

- Lines 46–55 select the structured error channel for malformed explicit JSON flags while respecting valid false.
- Lines 57–69 scan option positions and skip single-dash named values, so values such as `--project -h` do not become standalone help flags.
- Lines 95–114 parse integers and finite doubles using invariant culture and reject malformed explicit values.
- Lines 118–135 reject unknown/duplicate named options and missing values on commands invoking Validate.

Documentation: ROUND13_CLI_INPUT_PRESERVATION.md lines 37–42 and 60–63; CLI_MACHINE_PROTOCOL.md lines 38–50.

Limits: this does not prove all callers invoke Validate. Version/environment unknown-option handling and human help rendering remain documented exceptions. The prior effective source at b530ca5b… was not recovered; a Round13 hash record and retained Round21 current bytes do not replace the missing diff.

### MvsAnalyzer.Cli/MvsAnalyzer.Cli.csproj

Lines 1–21 define a net8 executable, version 1.4.0, with default compile discovery disabled. Five CLI files are explicitly included; a compiled Core project is referenced. There is no PackageReference or duplicated scientific source list in this project.

Documentation: CLI_PYTHON_ROADMAP.md lines 59–72 supports the compiled-Core boundary. The complete current file exists in retained Round21 bytes and is unchanged afterward.

Limits: source inspection is not a new compile or dependency/runtime certification. OutputSafety inclusion is consistent with Round13's role, but the exact introducing stage and prior effective 587f7159… source transition remain unproven.

### Infrastructure/RunAuditor.cs

Observed invariants:

- Lines 22–31 use the application-data resolver with DoNotVerify and reject unresolved/relative journal roots.
- Lines 42–74 acquire the shared coordination lease before reading the last entry or appending.
- Lines 80–128 retain the legacy session mutex plus persistent exclusive file handle, test second-open exclusion, apply a bounded wait, and fail rather than proceed unlocked.
- Lines 139–164 lock journal reads and detect malformed JSON/chain disagreement.
- Lines 195–245 compare listed file hashes and retain missing-file/input-identity/formula/version diagnostics.
- Lines 8–12 explicitly state that an owner can rewrite the journal and chain; local hashes do not authenticate history or prove complete reporting.

Documentation: ROUND19_JOURNAL_PATH_REPAIR.md lines 18–44; ROUND21_JOURNAL_CONCURRENCY.md lines 22–45 and 86–105; ROUND23_WINDOWS_MCP.md lines 59–68.

The provenance audit recovered the prior-effective→Round19→Round21→Round23 chain. Limits include cooperative local-filesystem locking, read/write lock-file permissions, no hostile path alias protection, possible incomplete crash tails, and no cross-platform/runtime or power-loss certification from this review.

### MvsAnalyzer.Cli/HeadlessRun.cs

Current SHA256: 272cccf6014a80f872ef8c3126be3d0715691cbc68f86a1a57875229c350d535.

Observed invariants:

- Lines 29–37 validate calibration options/budget and preflight actual input, job, applicable profile, reserved outputs and overwrite policy before import/computation/export.
- Lines 39–50 and 93–109 derive observations, summary, encoding and input digest from the same CsvImportResult. The captured identity feeds job matching, calibration reuse, backup context, state and final export.
- Lines 79–104 reject statistical overrides for saved calibration, warn on arithmetic-environment mismatch, apply persisted settings, and require force for changed input bytes with an exploratory-reuse warning.
- Lines 60–66 and 108–113 preserve source split, settings, seed, tracks, formula/engine/environment identities and fingerprint. The retained later diffs do not change engine calls or parameter selection.
- Lines 67–73 and 120–129 begin output tracking immediately before export, wrap fixed writes, pass the exporter observer, and separately observe returned plugin reports.
- Lines 130–140 retain stderr detail plus privacy-minimal journal_write_failed metadata, preserve successful artifact reporting and return 0 after journal-append failure.
- Lines 142–162 retain independent-ID collision protection and explicit local-settings opt-in. Lines 178–201 intentionally perform a fresh path hash for state-check rather than confusing it with captured import identity.

Documentation: ROUND13_CLI_INPUT_PRESERVATION.md lines 48–58, 65–78, 94–97; ROUND25_IMPORT_BOUNDARY.md lines 12–24 and 42–46; ROUND33_PARTIAL_OUTPUT_REPORTING.md lines 7–29; ROUND20_JOURNAL_WARNING.md lines 11–31 and 35–41; ROUND21_JOURNAL_CONCURRENCY.md lines 40–42.

Limits: journal path/locking belong to RunAuditor. Preflight is not transactional or race-safe and does not cover every implicit settings/plugin input. Plugin writes that throw before returning remain outside successful-write attribution. Completed analysis with a warning does not mean provenance append succeeded. In particular, the explicitly unexplained 608db779…→679369121… interval documented in Rounds4/8 remains unexplained; current acceptance does not retroactively approve or resolve it.

### MvsAnalyzer.Cli/ScientificCommands.cs

Current SHA256: e12037cf7b6dcc9229f13642344126f3f0ef50075c4daca0834a4a882e198663.

Observed invariants:

- Lines 10–15, 52–57 and 72–77 pass exact input and explicit profile to shared preflight and retain nonempty-directory/overwrite policy.
- Lines 13–18 and 54–59 use owned import observations; MELSM supplied-sequence metadata comes from that same import result.
- Lines 23, 65 and 88–95 require captured real-input hashes without a pathname-rehash fallback; synthetic estimation retains canonical configuration identity.
- Lines 19–24, 39–44 and 61–66 route all four per-command output writes, including manifests, through observation after computation.
- Lines 27–29, 46–48 and 68–70 preserve explicit scientific diagnostics and exit 2. Saving output does not establish model adequacy.
- Line 60 preserves deterministic entity pseudonyms unless explicitly included. Lines 79–86 preserve invariant numerics, nonfinite blanks, CSV quoting and formula-prefix protection.

Documentation: ROUND13_CLI_INPUT_PRESERVATION.md lines 48–58 and 94–97; ROUND25_IMPORT_BOUNDARY.md lines 19–24 and 35–46; ROUND33_PARTIAL_OUTPUT_REPORTING.md lines 7–23 and 50–53.

Limits: deterministic pseudonyms are not anonymity. Successful manifests still enumerate the directory and may include existing overwrite leftovers; current-invocation-only attribution applies to partial-error evidence. Prepare can create the output directory before later failure, and tracking begins only at export. Captured import results do not guarantee a filesystem snapshot under concurrent in-place writes. The prior-effective 95e42af1… source/transition was not recovered.

## Independently inspected later CLI diffs

Read directly from retained Round21 ZIP and Round23/25/33/34 trees:

- HeadlessRun Round21 = Round23: 59a199a9081e0582c907bf4f7c712d8ccbd64f945c00c15587ff32b6f3040326. Round25: a5725776f16bed9839aff3d249a9b2cc51ad05c3e43692ebd0539943611d32f0. Round33 = Round34 = current.
- ScientificCommands Round21 = Round23: da7f382f580109b1e186a686732cc515c9be83991b09bafd2a7534db38c7a965. Round25: 5d231b9957691142555bf2881a603e19dd4a5f9eca3919799e04fbc0cf33717b. Round33 = Round34 = current.
- Round23→25 hunks concern captured-input provenance/metadata. Round25→33 hunks concern output observation, plus HeadlessRun exporter/plugin observer wiring.

These comparisons cover retained later deltas only. Documents corroborate intended repairs but cannot substitute for missing earlier source bytes or exact diffs. No old history was silently rewritten by accepting the new baseline.
