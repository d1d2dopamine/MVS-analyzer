# Proposed MVS source-pin reconciliation

## Finding

All **17 mismatching current hashes predate Round34** and are byte-identical to the delivered Round33 and Round34 full-source archives. No new Round34 drift was found. **13** files have a recovered, reviewed diff chain from the **effective legacy expected hash** to current bytes. **4** have reviewed current content and retained stage/hash anchors, but an incomplete older transition. This does not newly prove the original UI-pin-to-checkpoint revisions already recorded in the existing contract.

This assessment only read files, ZIP entries, hashes and diffs. No source edits, builds, tests, external downloads or remote operations were performed. The earlier 47/48 Colab result is prior execution evidence, not a rerun here.

## Per-file mapping

Full hashes, original anchors, previous effective expectations, source/archive/doc identities and diff metadata are in `mvs-source-pin-reconciliation-proposed.json`. “First” is the earliest exact current byte snapshot retained here, except where a still-earlier hash record is explicitly identified.

| File | First current evidence | Current SHA256 prefix | Status | Reviewed change |
|---|---|---|---|---|
| `Benchmark/BenchmarkDatasets.cs` | R25 | `51600284f461` | Trace complete | Real-data benchmark imports one CsvImportResult and records its captured SourceSha256 instead of reopening the pathname. |
| `Benchmark/BenchmarkOptions.cs` | R23 | `7355cd2d9e4d` | Trace complete | Application-data folder resolution uses ApplicationDataPaths.GetLocalApplicationData; otherwise this file is byte-unchanged. |
| `Benchmark/BenchmarkReport.cs` | R23 | `1407ec587e59` | Trace complete | Benchmark journal root uses ApplicationDataPaths.GetLocalApplicationData; otherwise this file is byte-unchanged. |
| `Core/AnalysisEngine.cs` | R31 | `bc4caa760003` | Trace complete | Legacy calibration/results entrypoints forward to explicit WithRecording methods; acquisition uses the supplied factory. Computation bodies and ordering are retained. |
| `Core/EstimationStudy.cs` | R31 | `4b10cf9c1085` | Trace complete | Adds RunWithRecording forwarding boundary and substitutes supplied factory at existing acquisition point. |
| `Core/MelsmAnalysis.cs` | R31 | `7af9e4943909` | Trace complete | Adds RunWithRecording factory boundary; owned recording is passed to borrowed MinimizeWithRecording calls at existing three optimizer sites. |
| `Core/Models.cs` | R23 | `d4f51d62c597` | Trace complete | AppSettings storage root uses ApplicationDataPaths.GetLocalApplicationData; otherwise this file is byte-unchanged. |
| `Core/NumericalMethods.cs` | R31 | `bee20900e007` | Trace complete | Legacy Minimize forwards to MinimizeWithRecording; borrowed optional BackupSession parameter is generalized internally to IRunRecording. Optimizer body remains byte-identical. |
| `Core/VarianceAnalysis.cs` | R31 | `0dd3cb001510` | Trace complete | Adds RunWithRecording forwarding boundary and substitutes supplied factory at existing acquisition point. |
| `Infrastructure/CliArguments.cs` | R13 hash record; R21 bytes | `2ebf386f46fc` | Historical gap retained | Current parser behavior is explicitly supported by Round13 source-hash record and flag/input-safety documentation; exact current bytes occur in Round21 input archive. |
| `Infrastructure/CsvImporter.cs` | R25 | `093cf83527c3` | Trace complete | Adds source-bound CsvImportResult with hash of the captured raw bytes, instance metadata and cancellation checks; preserves legacy Read/ReadText global behavior for old callers. |
| `Infrastructure/OutputExporter.cs` | R33 | `b6d40a3eb66b` | Trace complete | Adds optional observeWrite and local Save wrapper around the existing export writes, preserving write order and content generation. |
| `Infrastructure/PluginManager.cs` | R23 | `e1802d5ea1d4` | Trace complete | Plugin root uses ApplicationDataPaths.GetLocalApplicationData; otherwise this file is byte-unchanged. |
| `Infrastructure/RunAuditor.cs` | R23 | `cb0550d1616a` | Trace complete | Round19 absolute app-data resolver/path capture; Round21 shared reader/writer lock with cross-session exclusive file capability check and bounded wait; Round23 application-data override. |
| `MvsAnalyzer.Cli/HeadlessRun.cs` | R33 | `272cccf6014a` | Historical gap retained | Retained Round20 journal-warning snapshot, Round25 captured import identity and Round33 per-invocation partial-output tracking. Current source roles reviewed; earlier exact history remains incomplete. |
| `MvsAnalyzer.Cli/MvsAnalyzer.Cli.csproj` | R21 | `3112a4eb5514` | Historical gap retained | Current explicit net8 CLI file list includes OutputSafety.cs and references compiled Core; the full current file is present in the Round21 input archive and unchanged afterward. |
| `MvsAnalyzer.Cli/ScientificCommands.cs` | R33 | `e12037cf7b6d` | Historical gap retained | Round13 input/output-safety source hash da7f382f... is retained in metadata and matching Round21 bytes; exact Round25 captured import hash and Round33 write-observation diffs are retained. |

## Evidence and remaining uncertainty

- R23’s four direct baseline-to-current storage-root changes are single substitutions to `ApplicationDataPaths`; RunAuditor also preserves `DoNotVerify`. `docs/ROUND23_WINDOWS_MCP.md` describes the child-only app-data override.
- R25 diffs match `docs/ROUND25_IMPORT_BOUNDARY.md`: captured import bytes/metadata, cancellation, and caller migration. R31 diffs match `docs/ROUND31_RUN_RECORDING_BOUNDARY.md`: factory/session seams with existing computation bodies preserved. R33 diffs match `docs/ROUND33_PARTIAL_OUTPUT_REPORTING.md`: output-write observation and partial-error evidence. No unrelated scientific formula, RNG draw, statistical threshold or method activation was found in these inspected deltas; this is source review, not new runtime/scientific validation.
- RunAuditor’s complete older chain is retained inside evidence: `journal-path-round19.zip!/source/RunAuditor-before.cs` (`944c4616…`, exactly legacy expected) → after (`1e121478…`) → `journal-concurrency-round21.zip!/source/RunAuditor.cs` (`24cef469…`) → R23 (`cb0550d1…`). Earlier Round21 intermediate diagnostic sources are not the final contract.
- CliArguments: `validation/cli-safety-round13-results.json` explicitly records the current `2ebf386f…`; `docs/ROUND13_CLI_INPUT_PRESERVATION.md` explains malformed-global-flag handling and option-position scanning. Current bytes are in the R21 input ZIP. The prior `b530ca5b…` source and exact transition were not recovered.
- ScientificCommands: the same R13 result record binds `da7f382f…`, matching recovered R21–23 source. R25 and R33 changes are exact reviewed diffs. The preceding `95e42af1…` source/transition is absent.
- CLI csproj: exact current `3112a4eb…` bytes are in R21 and every later snapshot. Its explicit net8 file list, `OutputSafety.cs` inclusion and compiled-Core reference have a coherent current role. R13 is a plausible reason for the OutputSafety inclusion, not proof of its introducing stage or a complete diff from `587f7159…`.
- HeadlessRun: `docs/ROUND4_BENCHMARK_DIAGNOSTICS.md` explicitly leaves `608db779…` → `67936912…` unexplained; `docs/ROUND8_BENCHMARK_EVIDENCE_AUDIT.md` states that observed stability does not establish correctness of that older change. R13 metadata records `fd4ea8e1…`; R20 evidence retains actual `59a199a9…` source; exact R25 (`a5725776…`) and R33/current (`272cccf6…`) deltas are reviewed. **The older gap remains unresolved.** A new current-source pin cannot honestly erase it.
- Retained documents describe past review/tests; local byte identity and this bounded review do not independently authenticate historical authorship or prove every former approval. Round24’s inaccessible documentation attachment is not needed for these source comparisons and was not accessed.

## Minimal versioned repair recommendation

1. Preserve `validation/ui-patch-baseline.json` and `validation/checkpoint-source-baseline.json` byte-for-byte. Do not replace the 30 original pins, historical revision chain or the original intentional connection exceptions.
2. Add one versioned **current-source review overlay**, restricted to the 17 enumerated paths. Each entry binds `originalAnchorSha256`, `previousExpectedSha256`, reviewed current SHA256, reason/stages, precise evidence references and provenance status. For the four incomplete histories, make “reviewed current source; incomplete historical transition” explicit and retain the older unresolved hashes. Acceptance of current bytes is a new validation-contract decision, not proof that those old transitions are now known.
3. Validate the full overlay before any lookup. Reject unsupported schemas, duplicate JSON keys/entries, unknown/missing/unexpected paths, unsafe path forms, malformed SHA256 values, mismatched original anchors or prior-hash chains, missing evidence and empty/inconsistent reasons. Do not derive an expected hash from the file currently being checked. Pin historical manifest file bytes in independent tests so accidental baseline rewrites fail.
4. Keep the actual-source SHA256 equality check for **all 30 files** in both UI and Colab callers. An unreviewed source mutation must fail, even for an overlay path. Do not broaden intentionally changed connection files, catch/ignore pin failures, or skip protected files. Describe these tests as compliance with the reviewed source contract rather than literal scientific-source byte immutability since the old UI patch.
5. Add mutation tests for original-anchor/prior-hash/current-hash changes, source mutation (revised and untouched paths), deleted/added/duplicate entries, unsafe paths, malformed/missing manifests and unsupported schema. Exercise every one of the 17 approved entries and all 13 unaffected paths, including both checkpoint-overridden and original-hash fallback routes. Keep the four historical-gap records machine-visible and asserted; do not let a later blanket refresh silently turn them into “fully traced.”

This proposal contains no contract implementation. It supports a narrow validation-only repair while retaining the project’s existing scientific and platform limitations.
