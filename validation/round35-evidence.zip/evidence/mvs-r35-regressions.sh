set -eu
cd /workspace/scratch/8105054a3211/mvs_round35/MVS-analyzer-main
python tools/test_backups.py
python tools/test_source.py
python tools/test_paper_benchmark.py
python tools/test_paper_benchmark_runner.py
python tools/test_release_bundle.py
python tools/test_round2.py
MVS_RESUME_OUTPUT_RESULTS=/workspace/scratch/8105054a3211/mvs-r34-repro/regression-baseline-candidate/report.json MVS_PARTIAL_OUTPUT_RESULTS=/workspace/scratch/8105054a3211/mvs-r34-old-partial-with-baseline/report.json python -m unittest discover -s validation -p 'test_*.py' -v
