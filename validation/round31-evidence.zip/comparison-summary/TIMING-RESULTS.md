# Round31 paired timing results

Completed all 72 fresh processes and 144 warm-up/measured workload executions in
fixed AB/BA/AB order, 2026-10-16 15:42:38–15:43:28 UTC. Exclusive execution window
was explicitly granted by parent after other native tests/reviews completed.
All 360 exact scientific/progress/checkpoint checks passed. No failed executions,
selective samples, altered fixtures or omitted timing observations.

Three pairs are descriptive evidence only. Results are mixed: several workloads
are slower and several faster. No broad speedup or performance-regression claim
is supported. Process/JIT/GC noise and short workloads limit interpretation.
Compare pair deltas as well as independent medians; they need not subtract alike.

| Mode | Workload | Baseline median ms | Target median ms | Median paired delta ms | Baseline allocated bytes | Target allocated bytes |
|---|---|---:|---:|---:|---:|---:|
| default | calibrate | 542.906 | 505.351 | -57.318 | 728954056 | 728953992 |
| default | results | 134.589 | 144.720 | +7.449 | 60038984 | 60038896 |
| default | variance | 308.817 | 328.644 | +21.509 | 210474032 | 210473960 |
| default | estimation | 90.752 | 93.693 | +11.556 | 46502672 | 46502648 |
| default | melsm | 47.368 | 41.060 | -6.308 | 3401480 | 3401448 |
| default | optimizer | 1.937 | 1.683 | -0.259 | 344184 | 344144 |
| disabled | calibrate | 522.652 | 515.616 | -11.828 | 728030880 | 728030880 |
| disabled | results | 140.289 | 131.189 | -29.921 | 59296968 | 59296968 |
| disabled | variance | 277.947 | 288.687 | +14.502 | 209391264 | 209391264 |
| disabled | estimation | 81.245 | 97.267 | +15.933 | 45640032 | 45640032 |
| disabled | melsm | 36.374 | 33.854 | -2.541 | 2512256 | 2487632 |
| disabled | optimizer | 0.193 | 0.167 | -0.027 | 60392 | 60392 |

Raw observations, ranges, pairwise ratios/deltas, CPU seconds, GC counts and peak
working set are in timing-summary.json; complete individual metrics remain in
timings/. Peak working set is process-wide, including warm-up, not isolated
measurement RSS. Allocated bytes use process-wide GC.GetTotalAllocatedBytes(true),
so runtime/background managed allocation is included. Warm-up occurs once per
fresh process; no claim that tiered JIT has fully stabilized is made.

This is an engineering seam comparison, not the scientific development pilot or
holdout. No inference method, fixture seed, registry or scientific threshold was
changed. The scientific NO-GO is unaffected.
