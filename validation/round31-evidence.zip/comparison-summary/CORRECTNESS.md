# Round31 external comparator evidence

Baseline: accepted Round30. Target: Round31 per-run recording seam.
Protocol: PROTOCOL-v2.md, frozen before baseline capture and target edits.
Six frozen workloads: five Core paths and bounded quadratic optimizer.

## Executed correctness checks

- External Release .NET8 builds: baseline and target, zero warnings/errors.
- Baseline capture completed before target edits; scientific objects, synchronous
  progress events, raw checkpoint archives and decoded documents retained.
- Default, globally disabled, interrupted, resumed and completed-replay scenarios
  were executed for all six workloads. Every expected cancellation was observed;
  every interrupted checkpoint contained incomplete work.
- Baseline/target scientific and progress serialized output matches byte-for-byte.
- Decoded checkpoint comparison retains every field except top-level Id, SavedUtc,
  Environments and OriginJob; numeric lexical tokens must match exactly. Request,
  RequestHash, Units, completion state and method/schema identity match, including
  the bounded interruption snapshots observed here.
- Resumed and completed replay scientific output matches uninterrupted output.
  Final checkpoint contents match too. Completed optimizer replay calls the
  objective zero times, checked with an external invocation counter.
- Explicit PortableRunRecordingFactory and test-owned disabled factory reproduce
  unchanged science/progress; explicit portable final checkpoints match default.
- Globally disabled and explicitly disabled runs produce no backup/archive file.
- No fabricated baseline storage trace: baseline has no injectable interface.
  Target ordered recording tests are separate production-test-worker evidence.

## Call-site source review

The five old public signatures forward their unchanged arguments/defaults to
factory-first internal methods. Validation remains before Begin. Existing request
initializers are unchanged, with only Begin's receiver replaced by the explicit
factory. Existing Try/Cached/Finish locations and cancellation/progress code remain
in place. MELSM's three optimizer sites pass the same borrowed session and keys to
MinimizeWithRecording. Old optimizer signature forwards to the same algorithm;
its loop, simplex serialization and EnvironmentChanged behavior are unchanged.
BackupSession implements the interface through explicit forwarding members.
PortableRunRecordingFactory is stateless and invokes the unchanged Begin path.
No storage-call ordering equivalence is inferred from nonexistent baseline traces.

## Instrumentation corrections retained honestly

The initial successful baseline harness used BackupSession.Disabled for the
optimizer's no-recording path. The frozen protocol specifies no session there;
the final harness passes null in that disabled optimizer path. All outputs and
checkpoints/progress were rechecked against original baseline capture and match.
The first added zero-objective-call assertion checked a mutable restored document
after execution, when a partial document had become complete, and incorrectly
failed on resumed optimizer work. The corrected assertion snapshots completion
state before invocation. Full baseline/target correctness was rerun successfully.
Original failed logs and original capture are retained; neither was overwritten.

## Evidence map

- baseline-correctness/: original pre-edit baseline capture
- baseline-verified-correctness/, target-verified-correctness/: final harness runs
- baseline-target-parity.json: exact cross-artifact comparison outcomes
- baseline-harness-verified-parity.json: original/final baseline output equivalence
- explicit-and-replay-parity.json: 54 explicit-factory/replay checks
- target-explicit-default/, target-explicit-disabled/: explicit factory evidence
- baseline-source-before.json, *-source-pre-timing.json: source manifests
- runtime.txt, cpu-proc.txt, os.txt: environment provenance

Timing subsequently completed under exclusive-window clearance; see
TIMING-RESULTS.md for all outcomes and limitations. These tiny engineering fixtures are not a development pilot, holdout evaluation, scientific validation,
or evidence of improved inferential performance.
