# Frozen recording-seam comparison protocol, revision 2

Frozen 2026-10-16 before baseline execution and Round31 seam implementation.
Supersedes revision 1 only for artifact identity, execution authorization and
trace observability; all fixtures, seeds, thresholds and AB/BA/AB timing unchanged.
Baseline A: /workspace/scratch/8105054a3211/mvs_round30/MVS-analyzer-main
Target B: /workspace/scratch/8105054a3211/mvs_round31/MVS-analyzer-main
External deliverables: /workspace/scratch/8105054a3211/mvs-r31-comparison
Original revision 1 remains untouched under mvs-r29-comparison.

Ordinary engineering fixtures and baseline correctness execution are approved.
Controlled timing requires the parent's exclusive CPU window. No production
source edits, development pilot, holdout study or scientific-method changes.
Baseline has no injectable interface: do not fabricate storage-call traces.
Capture real progress events and checkpoint documents for baseline parity;
source-callsite review plus target-only injected factory traces cover storage
ordering. Runtime provenance is recorded separately from scientific evidence.

Execution count: baseline correctness 6 workloads x (default + disabled +
interrupted/resumed + completed replay) = 24 top-level scenarios, with partial
interrupted calls additional. Target repeats these plus explicit seam tests.
Timing is 2 modes x 6 workloads x 3 pairs x 2 variants = 72 fresh processes,
each doing one warm-up and one measurement = 144 workload executions. Initial
5–20 minute estimate is unmeasured and not a claimed cost. Baseline wall times
will yield a precise projected total before timing; 20-minute initial budget
is a stopping/report boundary, not permission to silently shrink workloads.

## Frozen workloads

Shared observations, in g/e/i enumeration order: g=0..1, e=0..7, i=0..5;
Observation("G"+g+"E"+e, "G"+g, 100+g*3+e*.7+Math.Sin(i+e), i).
Use AnalysisEngine.Build with its unchanged defaults. 16 independent entity IDs,
96 observations; all positive; no randomized fixture generation.

1. Calibrate(data,100,1.15,54,reporter,token, scenario:"location",
   outlierRate:.02,missingRate:0,alpha:.05,tracks:AnalysisEngine.DefaultTracks).
2. Results(data, MetricKeys.Select(m=>new CalibrationRow(m,.01,.8,80)).ToList(),
   reporter,token,alpha:.05,equivalenceMargin:.147,seed:20260719).
   Synthetic calibration is an explicit API fixture, not an estimated calibration.
3. VarianceAnalysis.Run(data,100,99,1.3,1.3,54,.05,reporter,token).
4. EstimationStudy.Run(new EstimationOptions(Target:"mean",Shape:"normal",
   Entities:4,Measurements:3,Repetitions:100,BootstrapReplications:99,
   Seed:20260719,Location:100,WithinSd:10,BetweenSd:5),reporter,token).
5. MelsmAnalysis.Run(observations,new MelsmOptions(MeanTime:false,
   ScaleTime:false,Correlate:false,RandomScale:true,QuadraturePoints:7,
   MaxIterations:100),reporter,token). No random seed is consumed. Preserve
   nonconvergence, warnings and unavailable numerical fields exactly as returned.
6. NumericalMethods.Minimize(p=>p[0]*p[0]+2*p[1]*p[1], [8,-6],[-10,-10],
   [10,10],maximumIterations:3000,tolerance:1e-8,token,backup,"simplex").
   With recording: explicit BackupSession.Begin(new BackupRequest{Kind="melsm",
   Melsm=new()}); Finish(result) after optimization. Without recording: no session.

## Correctness before performance

For each workload on each artifact: one uninterrupted default-recording run;
one uninterrupted legacy MVS_DISABLE_BACKUPS=1 run; interrupt/resume run below.
After seam introduction, also run explicit disabled recorder with no environment
flag and explicit default recorder. The unchanged calls remain the primary legacy
contract. Do not route the default test through the new seam adapter.

Serialize returned objects using ScientificJson.Serialize, retaining the complete
raw string. Compare scientific output byte-for-byte. Decode final .mvsbackup with
BackupSession.Decode; serialize BackupDocument using BackupSession.Pack and retain
its complete raw JSON and raw backup bytes. Compare every field and every numeric
token, ignoring only top-level Id, SavedUtc, Environments, OriginJob. These four
fields are volatile ID/time/environment identity. RequestHash, Request, Units,
CalculationComplete, Schema, Implementation, Application, Engine, Formula and
Protocol must all match. Sort object keys only; preserve array order and numeric
tokens. Do not globally remove fields matching strings such as 'Time' or 'Path'.
The current BackupDocument contains no filesystem path field requiring omission.
Compare final completed snapshots; wall-clock-dependent intermediate Flush counts
and .previous snapshots cannot be expected to match. Retain them as diagnostics.
Disabled runs must create no backup/archive file. Every run gets a new directory.

Interrupt at synchronous progress fraction >= .20 for Calibrate, >= .25 Results,
>= .05 Variance, >= .23 Estimation. MELSM cancels at the first progress message
(likelihood evaluation 100); quadratic throws OperationCanceledException at
objective invocation 32, as in existing BackupChecks. Require cancellation and
nonempty incomplete checkpoint; no silent success if cancellation was not reached.
Resume through BackupSession.Restore in fresh scope, compare the full returned
scientific output and final decoded checkpoint against uninterrupted output.
Quadratic resume excludes the throwing callback; same pure objective thereafter.
Also replay a completed document; assert output identity and no objective calls
for the quadratic cache route. Report scientific and checkpoint parity separately.
Any discrepancy is retained, not normalized beyond the four approved fields.

## Build and runtime isolation

External console harness assembly name MvsAnalyzer.Core.Tests grants existing
friend access. Reference production Core project through an MvsSourceRoot build
property. A Directory.Build.props/explicit command property must redirect both
harness and referenced Core obj/bin to unique external variant/project paths;
never restore/build into either source tree. No package dependencies added.
Use .NET from ../mvs_r22_baseline/env.sh, Release net8.0, identical SDK/runtime.
Record dotnet --info, CPU model, OS/kernel, source-file hashes, harness/protocol
hashes, processor count, tiered compilation/GC variables, commands and timestamps.
Keep DOTNET_PROCESSOR_COUNT=2 and numerical-library thread counts=2, as env.sh.
Build both artifacts before timing; retain build logs and check source hashes
before and after. Source paths are provenance, not scientific comparison fields.

## Frozen timing design

Timing begins only after parent confirms other workers/builds are idle. No
concurrent research benchmark, native suite, archive build or CPU-heavy task.
Record host load/process diagnostics immediately before and after timing.
Compare A=accepted pre-seam baseline, B=post-seam target. Separate mode blocks:
legacy default recording, then legacy globally disabled recording. Explicit seam
modes are extra correctness tests, not substituted into those paired comparisons.
For each mode and workload, run 3 fresh-process pairs in fixed order AB, BA, AB.
Each process warms up that identical workload once, then measures once in another
fresh output directory; warm-up output/checkpoints cannot be reused. Preserve
warm-up metadata but do not count it as a timing observation. Fixed workload order
is 1..6 above. A process measures only scientific call + default checkpoint work,
excluding fixture preparation, JSON export, backup decoding and result comparison.
Use Stopwatch.GetTimestamp, GC.GetTotalAllocatedBytes(precise:true) delta, process
TotalProcessorTime delta, GC.CollectionCount deltas and peak working set. Force
full collection before the measured call in both variants, outside the stopwatch.
Report every raw observation and pair ratio; medians and ranges are descriptive.
No significance or broad speedup claim from three observations. Flag noisy/tiny
workloads and report inconclusive rather than omit unfavorable runs.

Estimated elapsed budget: 5–20 minutes, unmeasured; variance dominates. Start only
with clearance for this budget. If correctness or warm-up exceeds 20 minutes,
stop safely and report partial evidence and revised estimate before more work.
Do not shrink/change fixture parameters after seeing results to obtain a favorable
comparison. A necessary protocol amendment receives a new revision and reason.

## Deliverables and stopping condition

Protocol, executable harness/adapter source, comparator, exact build/run commands,
source/runtime manifest, raw scientific JSON and decoded/raw backups, checkpoint
replay evidence, raw timing/allocation JSON, concise pass/fail/inconclusive summary.
Stop when all frozen checks are accounted for, or a reproducible blocker requires
parent authorization. This design document itself is not executed evidence.
