set -e
export PYTHONPATH="$PWD/python/src"
export DOTNET_ROOT=/workspace/scratch/8105054a3211/mvs_r22_baseline/sdk
export MVS_MCP_TEST_ENGINE="$PWD/MvsAnalyzer.Cli/bin/Release/net8.0/mvs"
export MVS_MCP_TEST_DATA="$PWD/examples/demo_three_groups.csv"
export MVS_MCP_TEST_CALIBRATION=/workspace/scratch/8105054a3211/mvs_r22_baseline/artifacts/calibration/calibration_state.json
/workspace/scratch/8105054a3211/mvs_mcp_venv/bin/python -m unittest discover -s python/tests -v
for f in tools/test_backups.py tools/test_source.py tools/test_paper_benchmark.py tools/test_paper_benchmark_runner.py tools/test_release_bundle.py tools/test_round2.py; do python "$f"; done
python -m unittest discover -s validation -v
python validation/rank_test_reference.py
