using System.Reflection;
using System.Runtime.Loader;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

string assemblyPath = Path.GetFullPath(args.Single());
var assembly = AssemblyLoadContext.Default.LoadFromAssemblyPath(assemblyPath);
var reporter = assembly.GetType("TestReport", true)!.GetMethod("Run", BindingFlags.Static | BindingFlags.NonPublic)!;
int count = 0, failed = 0;
Console.WriteLine($"Independent reporter review: {RuntimeInformation.OSDescription}; {RuntimeInformation.FrameworkDescription}");
foreach (var test in (IEnumerable<(string Name, Action Run)>)assembly.GetType("TestReportChecks", true)!.GetProperty("All", BindingFlags.Static | BindingFlags.NonPublic)!.GetValue(null)!)
    Check(test.Name, test.Run);
Check("exact all-pass legacy output and status", () => {
    using var output = new StringWriter();
    int code = Run(new[]{("first", (Action)(() => {})), ("second", (Action)(() => {}))}, output);
    Require(code == 0 && output.ToString() == $"PASS  first{Environment.NewLine}PASS  second{Environment.NewLine}2/2 tests passed{Environment.NewLine}");
});
Check("exact empty legacy output and status", () => {
    using var output = new StringWriter();
    Require(Run(Array.Empty<(string, Action)>(), output) == 0 && output.ToString() == $"0/0 tests passed{Environment.NewLine}");
});
Check("full original nested exception representation is retained", () => {
    using var output = new StringWriter();
    Exception? seen = null;
    int code = Run(new[]{("nested", (Action)(() => { try { Outer(); } catch (Exception ex) { seen = ex; throw; } }))}, output);
    string expected = $"FAIL  nested: independent outer{Environment.NewLine}DETAIL {seen}{Environment.NewLine}0/1 tests passed{Environment.NewLine}";
    Require(code == 1 && seen != null && output.ToString() == expected);
    Require(output.ToString().Contains("System.IO.IOException") && output.ToString().Contains("System.UnauthorizedAccessException") && output.ToString().Contains("g__Inner|"));
});
Check("all failures count without suppressing later actions", () => {
    var calls = new List<int>(); using var output = new StringWriter();
    int code = Run(new[]{("a", (Action)(() => { calls.Add(1); throw new IOException("first"); })), ("b", (Action)(() => { calls.Add(2); throw new InvalidOperationException("second"); })), ("c", (Action)(() => calls.Add(3)))}, output);
    var lines = output.ToString().Split(Environment.NewLine);
    Require(code == 1 && calls.SequenceEqual(new[]{1,2,3}) && lines.Count(x => x.StartsWith("FAIL  ")) == 2 && lines.Count(x => x.StartsWith("PASS  ")) == 1 && output.ToString().EndsWith($"1/3 tests passed{Environment.NewLine}"));
    Require(output.ToString().IndexOf("FAIL  a:") < output.ToString().IndexOf("FAIL  b:") && output.ToString().IndexOf("FAIL  b:") < output.ToString().IndexOf("PASS  c"));
});
Check("outer and inner Data plus unrelated environment are omitted", () => {
    string? old = Environment.GetEnvironmentVariable("MVS_REVIEW_DIAGNOSTIC_CANARY");
    try {
        Environment.SetEnvironmentVariable("MVS_REVIEW_DIAGNOSTIC_CANARY", "ENV_CANARY_DO_NOT_REPORT");
        using var output = new StringWriter();
        var inner = new ArgumentException("inner"); inner.Data["INNER_CANARY_KEY"] = "INNER_CANARY_VALUE";
        var outer = new IOException("outer", inner); outer.Data["OUTER_CANARY_KEY"] = "OUTER_CANARY_VALUE";
        Require(Run(new[]{("privacy", (Action)(() => throw outer))}, output) == 1);
        Require(!output.ToString().Contains("CANARY"));
    } finally { Environment.SetEnvironmentVariable("MVS_REVIEW_DIAGNOSTIC_CANARY", old); }
});
Check("caller writer remains open after failure", () => {
    using var output = new StringWriter();
    Require(Run(new[]{("failure", (Action)(() => throw new Exception("controlled")))}, output) == 1);
    output.Write("after report"); Require(output.ToString().EndsWith("after report"));
});
Console.WriteLine($"RESULT {count-failed}/{count} independent reporter checks passed");
Console.WriteLine("Linux execution only. No native Windows acceptance or scientific claim is established.");
return failed == 0 ? 0 : 1;

int Run(IEnumerable<(string Name, Action Run)> tests, TextWriter output) => (int)reporter.Invoke(null, new object[]{tests, output})!;
void Check(string name, Action action) { count++; try { action(); Console.WriteLine("PASS " + name); } catch (Exception ex) { failed++; Console.WriteLine($"FAIL {name}: {ex}"); } }
static void Require(bool condition) { if (!condition) throw new Exception("Independent assertion failed"); }
[MethodImpl(MethodImplOptions.NoInlining)] static void Inner() => throw new UnauthorizedAccessException("independent inner");
[MethodImpl(MethodImplOptions.NoInlining)] static void Outer() { try { Inner(); } catch (Exception ex) { throw new IOException("independent outer", ex); } }
