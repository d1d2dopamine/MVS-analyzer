# Round 30 bounded provenance comparison

Source-only external friend-assembly harness, separate from source delivery. `baseline` references immutable Round 29 source; `fixed` references Round 30. Both link the same new provenance checks and existing Round 29 retry checks.

After execution approval, source `../mvs_r22_baseline/env.sh`, build each `Harness.csproj` in Release, run each DLL with `checks`, and run `python run_comparison.py`. The baseline targeted checks intentionally expose regressions; the comparison script explicitly expects baseline's stale-cache outcomes.

Producer persists an encoded fixture, decodes/restores it, and opens a session. It then exits its actual process normally without disposing the session. This models the post-publication/pre-evaluation process-loss window; it is not a forced-termination test. In the late-failure variant, the owned `MVS_Backups.zip` directory causes an IOException after installing the checkpoint, which the producer catches before exiting. A separately launched consumer removes only that empty obstruction and reloads the installed checkpoint. Three distinct consumer runs verify repeated restart behavior. Temporary directories contain synthetic data only and are deleted by Python after each case.

Objective: x[0]^2, points [[1],[2]], maximumIterations=0. Foreign/empty history has intentionally stale [-999,-998] values. All-current controls have valid [1,4] values. Expected fixed outcome is value 1, exactly two evaluations for foreign/unknown history and zero for all-current. Baseline's untrusted restart control is value -999, zero calls. No RNG or scientific inference is involved.

Five matched cost pairs run in A/B, B/A, A/B, B/A, A/B order per history. Elapsed ticks and allocated bytes describe only the Minimize call, excluding build, Begin, backup IO and Dispose. These cold-process observations may include JIT/runtime costs and are not speed comparisons. The decisive cost is exactly N+1=2 objective evaluations per foreign/unknown resume at N=1, and no additional evaluations in the same-environment fast path.

Native callback-exception/cancellation checks interrupt the second reevaluation; a separate precancelled-token test checks propagation after reevaluation at the optimizer's existing token boundary. They do not claim token cancellation interrupts reevaluation itself.
