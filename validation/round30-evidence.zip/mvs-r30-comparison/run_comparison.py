"""Bounded separate-process regression and descriptive matched-cost evidence.
Build each Harness.csproj first, with official env.sh sourced. No native full suite.
"""
import json, os, subprocess, tempfile, traceback
from datetime import datetime, timezone
from pathlib import Path
ROOT = Path(__file__).resolve().parent
DLL = {label: ROOT / label / 'bin/Release/net8.0/MvsAnalyzer.Core.Tests.dll' for label in ('baseline', 'fixed')}
rows = []
OUT = ROOT / ('run-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ'))
OUT.mkdir(exist_ok=False)
JOURNAL = OUT / 'invocations.jsonl'
invocations = 0
expected_observations = 66
expected_invocations = 108
def retain(record):
    with JOURNAL.open('a') as f:
        f.write(json.dumps(record) + '\n'); f.flush(); os.fsync(f.fileno())
def invoke(label, mode, folder, history, late):
    global invocations
    command = ['dotnet', str(DLL[label]), mode, str(folder), history, 'late' if late else 'normal']
    invocation = invocations + 1
    retain(dict(event='started', invocation=invocation, implementation=label, mode=mode, history=history, late=late, command=command))
    try:
        p = subprocess.run(command, text=True, capture_output=True, timeout=30)
    except subprocess.TimeoutExpired as e:
        retain(dict(event='timeout', invocation=invocation, stdout=str(e.stdout), stderr=str(e.stderr)))
        raise
    invocations += 1
    retain(dict(event='exited', invocation=invocation, exitCode=p.returncode, stdout=p.stdout, stderr=p.stderr))
    if p.returncode:
        raise RuntimeError(f'{label} {mode}: {p.stdout}\n{p.stderr}')
    decoded = json.loads(p.stdout.strip().splitlines()[-1])
    retain(dict(event='decoded', invocation=invocation, implementation=label, record=decoded))
    return decoded
failure = None
try:
    for history in ('foreign', 'empty', 'current'):
        for late in (False, True):
            for label in ('baseline', 'fixed'):
                with tempfile.TemporaryDirectory(prefix='mvs-r30-process-') as folder:
                    producer = invoke(label, 'produce', folder, history, late)
                    for reload in range(1, 4):
                        consumer = invoke(label, 'consume', folder, history, late)
                        retain(dict(event='pair', kind='restart', implementation=label, reload=reload, producer=producer, consumer=consumer))
                        expected_calls = 2 if label == 'fixed' and history != 'current' else 0
                        expected_value = 1 if label == 'fixed' or history == 'current' else -999
                        assert consumer['processId'] != producer['processId'], 'Producer and consumer must be distinct processes'
                        assert consumer['calls'] == expected_calls and consumer['Value'] == expected_value, (label, history, late, consumer)
                        assert not consumer['calculationComplete']
                        if label == 'fixed' and history == 'empty': assert consumer['environments'] == []
                        rows.append(dict(kind='restart', implementation=label, reload=reload, producer=producer, consumer=consumer))
    # Five matched pairs in frozen A/B, B/A, A/B, B/A, A/B order for each fixture.
    # Baseline foreign/unknown observations are intentionally incorrect stale-cache controls.
    for history in ('foreign', 'empty', 'current'):
        for pair, order in enumerate((('baseline','fixed'), ('fixed','baseline'), ('baseline','fixed'), ('fixed','baseline'), ('baseline','fixed')), 1):
            for label in order:
                with tempfile.TemporaryDirectory(prefix='mvs-r30-cost-') as folder:
                    producer = invoke(label, 'produce', folder, history, False)
                    consumer = invoke(label, 'cost', folder, history, False)
                    retain(dict(event='pair', kind='cost', implementation=label, pair=pair, producer=producer, consumer=consumer))
                    expected_calls = 2 if label == 'fixed' and history != 'current' else 0
                    assert consumer['calls'] == expected_calls
                    assert consumer['Value'] == (1 if label == 'fixed' or history == 'current' else -999)
                    rows.append(dict(kind='cost', implementation=label, pair=pair, order=list(order), producer=producer, consumer=consumer))
except Exception:
    failure = traceback.format_exc()
finally:
    summary = dict(status='failed' if failure else 'passed', expectedObservations=expected_observations, completedObservations=len(rows), incompleteOrNotStartedObservations=expected_observations-len(rows), completedInvocations=invocations, expectedInvocations=expected_invocations, error=failure)
    with (OUT / 'status.json').open('x') as f: json.dump(summary, f, indent=2)
result = dict(protocol='R30-SIMPLEX-ORIGIN-1', processModel='actual producer normal exit without Dispose; separate consumers; no forced OS kill', costScope='Minimize only, excluding build and backup IO; includes cold method/JIT effects; elapsed/allocations descriptive only', claims='N=1 foreign/unknown resume uses exactly 2 objective calls; all-current adds 0 calls; no speedup or general accuracy claim', rows=rows)
result['status'] = summary
out = OUT / 'comparison-results.json'
with out.open('x') as f: f.write(json.dumps(result, indent=2)+'\n')
print(f"{summary['status'].upper()} {len(rows)} observations; {out}")
if failure: raise SystemExit(failure)
