using System.Diagnostics;
using System.Text.Json;
using MvsAnalyzer;

if (args.Length == 0 || args[0] == "checks")
{
    int failures = 0;
    foreach (var test in BackupProvenanceChecks.All.Concat(BackupRetryChecks.All))
        try { test.Run(); Console.WriteLine("PASS " + test.Name); }
        catch (Exception e) { failures++; Console.WriteLine("FAIL " + test.Name + ": " + e.Message); }
    return failures == 0 ? 0 : 1;
}
string mode = args[0], folder = Path.GetFullPath(args[1]), history = args[2];
bool late = args[3] == "late";
Directory.CreateDirectory(folder);
Environment.SetEnvironmentVariable("MVS_BACKUP_DIR", folder);
Environment.SetEnvironmentVariable("MVS_DISABLE_BACKUPS", null);
if (mode == "produce")
{
    var d = BackupProvenanceChecks.Fixture(history);
    // First persist the original input checkpoint, then model opening a resumed job.
    File.WriteAllBytes(Path.Combine(folder, "input.fixture"), BackupSession.Encode(d));
    d = BackupSession.Decode(File.ReadAllBytes(Path.Combine(folder, "input.fixture")));
    if (late) Directory.CreateDirectory(Path.Combine(folder, "MVS_Backups.zip"));
    var scope = BackupSession.Restore(d); // deliberately no Dispose before actual process exit
    bool failed = false;
    try { _ = BackupSession.Begin(d.Request); } catch (IOException) when (late) { failed = true; }
    BackupProvenanceChecks.Assert(failed == late, "Producer publication result differs.");
    var disk = BackupProvenanceChecks.Load(folder);
    Console.WriteLine(JsonSerializer.Serialize(new { mode, history, late, processId = Environment.ProcessId, failed, disk.Id, disk.Environments, disk.CalculationComplete }));
    // This is a real process boundary, normal exit without Dispose, not an OS forced kill.
    Environment.Exit(0);
}
if (mode == "consume" || mode == "cost")
{
    if (late && Directory.Exists(Path.Combine(folder, "MVS_Backups.zip"))) Directory.Delete(Path.Combine(folder, "MVS_Backups.zip"));
    var d = BackupProvenanceChecks.Load(folder);
    using var scope = BackupSession.Restore(d);
    using var b = BackupSession.Begin(d.Request);
    // No file IO / Begin / Dispose is included in descriptive microcase measurements.
    int calls = 0;
    long allocated = GC.GetAllocatedBytesForCurrentThread(); var timer = Stopwatch.StartNew();
    var result = BackupProvenanceChecks.Minimize(b, x => { calls++; return x[0] * x[0]; });
    timer.Stop(); allocated = GC.GetAllocatedBytesForCurrentThread() - allocated;
    Console.WriteLine(JsonSerializer.Serialize(new { mode, history, late, processId = Environment.ProcessId, calls, result.Value, result.Parameters, result.Iterations, result.Converged, result.AtBoundary, b.EnvironmentChanged, environments = d.Environments, calculationComplete = d.CalculationComplete, elapsedTicks = timer.ElapsedTicks, stopwatchFrequency = Stopwatch.Frequency, allocatedBytes = allocated }));
    return 0;
}
throw new ArgumentException("Unknown mode " + mode);
