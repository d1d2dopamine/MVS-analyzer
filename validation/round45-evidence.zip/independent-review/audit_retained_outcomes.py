"""Round45 independent read-only outcome audit. No engine/driver imports or calibration."""
import gzip, hashlib, itertools, json, math, pathlib, struct
from collections import Counter, defaultdict
from fractions import Fraction as Q
ROOT=pathlib.Path('/workspace/scratch/8105054a3211/mvs-r45-replay')
OUT=pathlib.Path('/workspace/scratch/8105054a3211/mvs-r45-evidence/independent-review')
EXPECTED_BIND='5189f7d718c8ae74861b31ee0ce1244c68c5e93719f7ea88fd9a50534de23144'
KEYS='median standard_deviation coefficient_of_variation mad iqr normalized_mad normalized_iqr mean rms range geometric_mean trimmed_mean_20'.split()
TRACKS=['location','variability','heterogeneity']; GRID=[1.,1.02,1.05,1.1,1.2]
DOUBLE_FIELDS=set('fpr power score robustness repeatability coverage mde fpr_low fpr_high alpha'.split())
DOUBLE_ARRAYS=set('track_powers track_scores track_mdes track_power_low track_power_high'.split())
FIELDS=set('metric fpr power score robustness repeatability coverage applicable mde fpr_inflated power_curve tracks track_powers track_scores track_mdes track_curves repetitions fpr_low fpr_high track_power_low track_power_high track_failures track_mde_status alpha null_failures'.split())
PAIRS=[(s,i,j) for s,ix in [('location',[0,7,10,11]),('variability',[1,2,3,4,5,6,9]),('heterogeneity',[0,7,10,11]),('null',list(range(12)))] for i,j in itertools.combinations(ix,2)]
def sha(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
def parse(t):
 def obj(items):
  d={}
  for k,v in items:assert k not in d;d[k]=v
  return d
 def bad(t):raise AssertionError('Nonfinite JSON literal '+t)
 return json.loads(t,object_pairs_hook=obj,parse_int=lambda v:-0.0 if v=='-0' else int(v),parse_constant=bad)
def read(p):return parse(pathlib.Path(p).read_text())
def bits(v):assert type(v) in (int,float) and math.isfinite(v);return struct.pack('>d',v)
def exact(a,b):
 if type(a) in (int,float) and type(b) in (int,float):
  if type(a) is int and type(b) is int:return a==b
  return bits(a)==bits(b)
 if type(a)!=type(b):return False
 if isinstance(a,dict):return set(a)==set(b) and all(exact(a[k],b[k]) for k in a)
 if isinstance(a,list):return len(a)==len(b) and all(exact(x,y) for x,y in zip(a,b))
 return a==b
def rat(v):return {'numerator':v.numerator,'denominator':v.denominator,'value':float(v)}
def number_equal(a,b):return a is None and b is None or a is not None and b is not None and bits(a)==bits(b)
def row_parity(a,b,al,bl):
 assert len(a)==len(b)==12
 def labels(ls):
  z={}
  for v in ls:assert set(v)=={'path','value'} and v['path'] not in z and v['value'] in ('NaN','Infinity','-Infinity');z[v['path']]=v['value']
  return z
 am,bm=labels(al),labels(bl);assert am==bm
 nulls=set()
 for i,(x,y) in enumerate(zip(a,b)):
  assert set(x)==set(y)==FIELDS and x['metric']==KEYS[i]
  for k in FIELDS:
   if k in DOUBLE_FIELDS:
    assert number_equal(x[k],y[k]),(i,k)
    if x[k] is None:nulls.add(f'[{i}].{k}')
   elif k in DOUBLE_ARRAYS:
    assert type(x[k]) is list and type(y[k]) is list and len(x[k])==len(y[k])==3
    for t,(u,v) in enumerate(zip(x[k],y[k])):
     assert number_equal(u,v),(i,k,t)
     if u is None:nulls.add(f'[{i}].{k}[{t}]')
   else:assert type(x[k])==type(y[k]) and exact(x[k],y[k]),(i,k)
 assert nulls==set(am)
def wilson(k,n):
 z=1.959963984540054;p=k/n;den=1+z*z/n;cen=(p+z*z/(2*n))/den;rad=z*math.sqrt(p*(1-p)/n+z*z/(4.0*n*n))/den
 return max(0,cen-rad),min(1,cen+rad)
assert sha(ROOT/'bind.json')==EXPECTED_BIND==(ROOT/'bind.sha256').read_text().strip()
bind=read(ROOT/'bind.json')
for path,want in bind['pins'].items():assert sha(path)==want,path
assert bind['pairs']==[list(v) for v in PAIRS] and len(bind['inputs'])==120
run=read(ROOT/'run.json'); assert run['counts']['matched']==120 and run['counts']['failed']==0 and run['stop_reasons']==[] and run['remaining_or_zombie_groups']==[] and run['end_drift']=='passed'
assert [a['index'] for a in run['attempts']]==list(range(120))
assert all(a['started'] and a['matched'] and a['returncode']==0 and a['halves']=={'left':'completed','right':'completed'} for a in run['attempts'])
assert run['elapsed_seconds']<=900 and run['peak_aggregate_rss_bytes']<=4*1024**3
report=read(ROOT/'report.json');assert report['accepted'] and report['failures']==[]
for f in report['inventory']:
 p=ROOT/f['path'];assert p.stat().st_size==f['bytes'] and sha(p)==f['sha256'],f['path']
stat={s:{'n':0,'signs':Counter(),'values':defaultdict(list),'undefined':defaultdict(Counter),'rates':[]} for s in [*TRACKS,'null']}
raw_symbols=0;halves=0;rows_checked=0;missing=0;max_wilson=0.;max_score=0.;pair_count=0
with gzip.open(ROOT/'pairs.jsonl.gz','rt') as pair_file:
 for index,input_path in enumerate(bind['inputs']):
  x=read(input_path);assert x['index']==index
  for side in ['left','right']:
   folder=ROOT/f'case-{index:03d}'/'native';meta=read(folder/f'{side}.meta.json');payload=read(folder/f'{side}.rows.json');rows=payload['rows'];raw=(folder/f'{side}.codes.bin').read_bytes()
   assert len(raw)==21000 and hashlib.sha256(raw).hexdigest()==meta['sha256']
   assert meta['status']=='completed' and meta['all_field_match'] is True and meta['mismatches']==[] and meta['error'] is None
   assert meta['freeze_sha256']==EXPECTED_BIND and meta['source_input_sha256']==sha(input_path) and meta['rows_sha256']==sha(folder/f'{side}.rows.json')
   assert meta['seed']==x['seeds'][f'calibration_{side}_seed'] and meta['index']==index and meta['side']==side
   assert exact(meta['identity'],bind['identity']) and exact(meta['settings'],x['settings'])
   data=x['data'][side];assert hashlib.sha256(data['canonical_json'].encode()).hexdigest()==data['sha256']==meta['canonical_data_sha256'];assert exact(parse(data['canonical_json']),data['values'])
   row_parity(x[f'calibration_{side}'],rows,x['nonfinite_fields'][f'calibration_{side}'],payload['nonfinite_fields']);rows_checked+=12
   columns=[[] for _ in range(84)];counts=[[0]*3 for _ in range(84)];gc=[[[0]*3 for _ in range(84)] for _ in range(5)]
   for rep in range(1000):
    for pos in range(84):
     symbol=(raw[rep*21+pos//4]>>(2*(pos%4)))&3;assert symbol<3
     columns[pos].append(symbol-1);counts[pos][symbol]+=1;gc[rep%5][pos][symbol]+=1
   assert counts==meta['counts'] and gc==meta['grid_counts'];raw_symbols+=84000;missing+=sum(v[0] for v in counts)
   n=1000;nominal=.05/12
   for i,row in enumerate(rows):
    observed=all(sum(e['group'].casefold()==g.casefold() and e['metrics'][i] is not None and math.isfinite(e['metrics'][i]) for e in data['values']['entities'])>=4 for g in data['values']['group_names'])
    app=observed and n-counts[i][0]>=900;assert row['applicable']==app and row['null_failures']==counts[i][0]
    fpr=counts[i][2]/n if app else None;assert number_equal(row['fpr'],fpr)
    infl=fpr is not None and fpr>min(1,max(1.5*nominal,nominal+.02));assert row['fpr_inflated']==infl
    if app:
     for a,b in zip([row['fpr_low'],row['fpr_high']],wilson(counts[i][2],n)):max_wilson=max(max_wilson,abs(a-b));assert abs(a-b)<=1e-15
    for t in range(3):
     pos=12+12*t+i;power=counts[pos][2]/n if app and n-counts[pos][0]>=900 else None
     assert number_equal(row['track_powers'][t],power) and row['track_failures'][t]==counts[pos][0]
     if power is not None:
      for a,b in zip([row['track_power_low'][t],row['track_power_high'][t]],wilson(counts[pos][2],n)):max_wilson=max(max_wilson,abs(a-b));assert abs(a-b)<=1e-15
      score=100*math.sqrt(max(0,min(1,power))*max(0,min(1,math.exp(-max(0,fpr-nominal)/nominal))))
      max_score=max(max_score,abs(score-row['track_scores'][t]));assert abs(score-row['track_scores'][t])<=1e-12
     curve=[gc[j][48+12*t+i][2]/200 if app and gc[j][48+12*t+i][0]<=20 else None for j in range(5)]
     pieces=row['track_curves'][t].split('|');assert len(pieces)==5
     for j,piece in enumerate(pieces):
      e,v=piece.split(':');assert number_equal(float(e),GRID[j]) and number_equal(None if v=='NaN' else float(v),curve[j])
     estimate=None
     if app and not infl and all(v is not None for v in curve) and curve[0]<.8:
      for j in range(1,5):
       if curve[j]>=.8 and curve[j-1]<.8:estimate=GRID[j-1]+(GRID[j]-GRID[j-1])*(.8-curve[j-1])/(curve[j]-curve[j-1])-1;break
     assert number_equal(estimate,row['track_mdes'][t])
     status='not_applicable' if not app else 'fpr_inflated' if infl else 'estimated_on_grid' if estimate is not None else 'target_not_reached_or_invalid_curve'
     assert row['track_mde_status'][t]==status
   for stratum,i,j in PAIRS:
    result=parse(next(pair_file));assert (result['case'],result['side'],result['stratum'],result['metric_i'],result['metric_j'])==(index,side,stratum,KEYS[i],KEYS[j])
    off=0 if stratum=='null' else 12+12*TRACKS.index(stratum);a=columns[off+i];b=columns[off+j]
    cells=[[0]*3 for _ in range(3)]
    for u,v in zip(a,b):cells[u+1][v+1]+=1
    assert cells==result['joint_counts'] and result['n_observed']==result['expected_n']==1000
    ml=sum(cells[0]);mr=sum(c[0] for c in cells);both=cells[0][0];ra=sum(cells[2]);rb=sum(c[2] for c in cells)
    for key,val in [('missing_left',ml),('missing_right',mr),('both_missing',both),('missing_only_left',ml-both),('missing_only_right',mr-both),('jointly_valid',n-ml-mr+both),('rejections_left',ra),('rejections_right',rb)]:assert result[key]==val
    assert result['applicable_i']==rows[i]['applicable'] and result['applicable_j']==rows[j]['applicable']
    rates=[Q(ra,n),Q(rb,n)];assert exact(result['rates'],[rat(v) for v in rates]);s=stat[stratum];s['n']+=1;s['rates'].extend(rates)
    assert ml==mr==0 and result['reason'] is None
    # Independent centered-sample-moment calculation weighted by the four joint cells.
    centered_x=sum(cells[u+1][v+1]*(n*u-ra)**2 for u in (0,1) for v in (0,1))
    centered_y=sum(cells[u+1][v+1]*(n*v-rb)**2 for u in (0,1) for v in (0,1))
    centered_xy=sum(cells[u+1][v+1]*(n*u-ra)*(n*v-rb) for u in (0,1) for v in (0,1))
    centered_d=sum(cells[u+1][v+1]*(n*(u-v)-(ra-rb))**2 for u in (0,1) for v in (0,1))
    vx=Q(centered_x,n*n*(n-1));vy=Q(centered_y,n*n*(n-1));cov=Q(centered_xy,n*n*(n-1));vp=Q(centered_d,n*n*n*(n-1));vi=(vx+vy)/n
    assert vi-vp==2*cov/n
    values={'difference':Q(ra-rb,n),'variance_left':vx,'variance_right':vy,'covariance':cov,'paired_variance':vp,'independent_variance':vi,'variance_reduction':vi-vp,'correlation':float(cov)/math.sqrt(float(vx*vy)) if vx and vy else None,'variance_ratio':vp/vi if vi else None,'paired_mc_sd':math.sqrt(float(vp)),'independent_mc_sd':math.sqrt(float(vi))}
    undefined={}
    if not vx or not vy:undefined['correlation']='constant_marginal'
    if not vi:undefined['variance_ratio']='zero_independent_variance'
    assert result['undefined']==undefined and set(result['moments'])==set(values)
    for key,v in values.items():
     expected=rat(v) if isinstance(v,Q) else v;assert exact(result['moments'][key],expected),(index,side,stratum,i,j,key)
     if v is None:s['undefined'][key][undefined[key]]+=1
     else:s['values'][key].append(v)
    sign=(cov>0)-(cov<0);assert result['covariance_sign']==sign;s['signs'][sign]+=1;pair_count+=1
   halves+=1
 assert pair_file.read()==''
summary=read(ROOT/'summaries.json');report_summaries={}
for stratum,s in stat.items():
 actual=summary[stratum];planned=s['n'];assert planned==240*sum(v[0]==stratum for v in PAIRS)
 assert actual['covariance_sign_counts']=={'negative':s['signs'][-1],'zero':s['signs'][0],'positive':s['signs'][1]}
 assert actual['positive_covariance_fraction']=={'numerator':s['signs'][1],'denominator':planned}
 assert actual['defined_covariance_fraction']=={'numerator':planned,'denominator':planned}
 for field,vals in s['values'].items():
  vals.sort();n=len(vals);median=vals[n//2] if n%2 else (vals[n//2-1]+vals[n//2])/2;present=lambda v:rat(v) if isinstance(v,Q) else v
  expected={'planned_count':planned,'observed_valid_count':planned,'finite_count':n,'undefined_count':planned-n,'undefined_by_reason':dict(s['undefined'][field]),'minimum':present(vals[0]),'median':present(median),'maximum':present(vals[-1])}
  assert exact(actual['fields'][field],expected),(stratum,field)
 assert actual['marginal_rate_context']['planned_count']==2*planned and actual['marginal_rate_context']['finite_count']==2*planned and actual['marginal_rate_context']['undefined_count']==0
 assert exact(actual['marginal_rate_context']['minimum'],rat(min(s['rates']))) and exact(actual['marginal_rate_context']['maximum'],rat(max(s['rates'])))
 report_summaries[stratum]={'planned_pairs':planned,'covariance_signs':actual['covariance_sign_counts'],'variance_ratio':actual['fields']['variance_ratio'],'marginal_rate_context':actual['marginal_rate_context']}
result={'status':'passed','method':'Independent strict reader, raw bit decoder, all-field binary64/class comparison, direct centered sample moments with exact rational arithmetic; no driver statistical functions imported.','binding_sha256':EXPECTED_BIND,'pinned_files_verified':len(bind['pins']),'halves_audited':halves,'calibration_rows_exactly_matched':rows_checked,'top_level_row_properties_matched':rows_checked*25,'trace_symbols_audited':raw_symbols,'raw_trace_bytes_audited':raw_symbols//4,'nonfinite_trace_codes':missing,'pair_records_audited':pair_count,'max_wilson_reconstruction_absolute_error':max_wilson,'max_score_reconstruction_absolute_error':max_score,'all_mde_reconstructions_bit_exact':True,'summary_denominators_verified':True,'reviewer_calibrations_executed':0,'scientific_go':False,'findings':report_summaries}
with (OUT/'retained-outcome-audit.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in result.items() if k!='findings'},indent=2))
