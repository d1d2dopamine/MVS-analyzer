"""Independent direct-rational software fixtures only; never runs calibration."""
from fractions import Fraction as F
from itertools import product
import hashlib, json, pathlib, sys, types
root=pathlib.Path('/workspace/scratch/8105054a3211/mvs_round45/MVS-analyzer-main')
sys.path.insert(0,str(root/'validation'))
source=(root/'validation/paired_calibration_trace.py').read_bytes()
p=types.ModuleType('reviewed_paired_calibration_trace')
exec(compile(source,'reviewed_paired_calibration_trace.py','exec'),p.__dict__)
cases=0
for n in range(2,7):
 for x in product((0,1),repeat=n):
  for y in product((0,1),repeat=n):
   z=p.pair_moments(x,y,n); mx=F(sum(x),n);my=F(sum(y),n)
   cv=sum((F(a)-mx)*(F(b)-my) for a,b in zip(x,y))/(n-1)
   ds=[a-b for a,b in zip(x,y)];md=mx-my
   vp=sum((F(d)-md)**2 for d in ds)/(n-1)/n
   vn=(sum((F(a)-mx)**2 for a in x)+sum((F(b)-my)**2 for b in y))/(n-1)/n
   for name,e in [('covariance',cv),('paired_variance',vp),('independent_variance',vn)]:
    r=z['moments'][name];assert F(r['numerator'],r['denominator'])==e
   assert vn-vp==2*cv/n
   cases+=1
assert len(p.PAIRS)==99
for xs,ys in [([-1,0,1,1],[0,0,1,0]),([-1]*4,[-1]*4),([0]*4,[-1]*4)]:
 z=p.pair_moments(xs,ys,4);assert all(v is None for v in z['moments'].values())
assert p.encode([-1,0,1,-1])==bytes([0x24])
assert p.encode([1,0,-1,1])==bytes([0x86])
print(json.dumps({'status':'passed','reference_source_sha256':hashlib.sha256(source).hexdigest(),'independent_direct_rational_fixtures_passed':cases,'pair_count_per_half':len(p.PAIRS),'missing_policy_and_codec_examples':'passed','calibrations_executed':0},indent=2))
